-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 29, 2020 at 09:09 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `soft`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE `bank` (
  `b_id` int(11) NOT NULL,
  `b_name` varchar(50) NOT NULL,
  `address` varchar(255) NOT NULL,
  `ifsc_code` varchar(255) DEFAULT NULL,
  `account_no` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`b_id`, `b_name`, `address`, `ifsc_code`, `account_no`) VALUES
(1, 'hdfc', 'ssd', 'sdsd', '1212122121fddfdf'),
(2, 'sbi', 'ssd', 'sdsd', 'sdsd');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` int(2) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `created_at`, `updated_at`, `deleted_at`) VALUES
(17, 'admin', 'admin@admin.com', '25d55ad283aa400af464c76d713c07ad', 1, '2019-04-10 00:00:00', '2019-06-14 11:27:37', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE `vehicle` (
  `v_id` int(11) NOT NULL,
  `company_name` varchar(50) NOT NULL,
  `reg_no` varchar(100) NOT NULL,
  `reg_date` date NOT NULL,
  `permit_exp_date` date NOT NULL,
  `fitness_exp_date` date NOT NULL,
  `insu_exp_date` date NOT NULL,
  `insu_policy_no` varchar(100) NOT NULL,
  `tax_rcp_exp_date` date NOT NULL,
  `chasis_no` varchar(100) NOT NULL,
  `engine_no` varchar(100) NOT NULL,
  `mfg_date` varchar(100) NOT NULL,
  `puc_exp_date` date DEFAULT NULL,
  `d_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`v_id`, `company_name`, `reg_no`, `reg_date`, `permit_exp_date`, `fitness_exp_date`, `insu_exp_date`, `insu_policy_no`, `tax_rcp_exp_date`, `chasis_no`, `engine_no`, `mfg_date`, `puc_exp_date`, `d_id`) VALUES
(3, '0', 'MH43BG7235', '2019-05-15', '2019-05-15', '2019-05-15', '2019-05-15', '21352561', '2019-05-15', '23465453', '54566', '03-2019', '1970-01-01', 0),
(4, 'Own', 'Mh1236555555', '2019-05-01', '2021-05-16', '2021-05-01', '2021-05-01', '556455', '2021-05-16', '125454', '54566', '03-2019', NULL, NULL),
(5, 'Own', 'MH26BE3271', '2019-02-01', '2020-05-19', '2020-05-19', '2020-05-19', '85412', '2020-05-19', '2015', '025456', '06-2019', NULL, NULL),
(6, 'Own', 'as', '2019-06-04', '2019-05-28', '2019-05-27', '2019-07-03', '112', '2019-06-26', '32323', '212', '07-2019', '2019-08-14', NULL),
(7, 'Other', '2323', '2019-06-21', '2019-06-11', '2019-05-28', '2019-06-06', '112', '2019-06-26', '32323', '2323', '06-2019', '2019-08-23', NULL),
(8, 'Own', '2323', '2019-07-08', '2019-07-04', '2019-07-02', '2019-07-02', '112', '2019-08-05', '32323', '212', '11-2019', '2019-07-09', 6);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bank`
--
ALTER TABLE `bank`
  ADD PRIMARY KEY (`b_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`v_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bank`
--
ALTER TABLE `bank`
  MODIFY `b_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `vehicle`
--
ALTER TABLE `vehicle`
  MODIFY `v_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
