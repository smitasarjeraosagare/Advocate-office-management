<?php


function pr($object) {
	echo "<pre>";
	print_r($object);
	echo "</pre>";
}

function lq()
{
    $ci =& get_instance();
    echo "<pre>";
    echo $ci->db->last_query();
    echo "</pre>";
}

function upload_file($file, $dir, $updateFlag = false) {

	if ($updateFlag && is_dir($dir))
    	rrmdir($dir);

    if (!is_dir($dir))
        mkdir($dir);

    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $storage_name = uniqid('doc_').'.'.$ext;
    $upload_path = $dir.$storage_name;

    return move_uploaded_file($file['tmp_name'], $upload_path) ? $storage_name : false;
}

function rrmdir($dir) {
    $files = glob($dir . '*', GLOB_MARK);
    foreach ($files as $file) {
        if (is_dir($file)) {
            rrmdir($file);
        } else {
            unlink($file);
        }
    }
    rmdir($dir);
}

function authorize($role)
{
    $ci =& get_instance();
    return $ci->session->userdata('role') == $role;
}