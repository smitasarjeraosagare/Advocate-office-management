<?php
class Study_Model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
   function get_study($st_id)
    {
        return $this->db->get_where('study',array('st_id'=>$st_id))->row_array();
    
    }
  function get_all_study()
    {
         

     $this->db->select('study.* '
                       );
          return $this->db->get('study')->result_array();

 
    }
    function add_study($params)
    {
        $this->db->insert('study',$params);
        return $this->db->insert_id();
    }
    function update_Study($st_id,$params)
    {
        $this->db->where('st_id',$st_id);
        return $this->db->update('study',$params);
    }
     function delete_Study($st_id)
    {
        return $this->db->delete('study',array('st_id'=>$st_id));
    }
    function get_all_Study_count()
    {
        $this->db->from('study');
        return $this->db->count_all_results();
    }

}
?>