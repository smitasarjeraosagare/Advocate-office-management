<?php
class Star_Model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
   function get_star($sid)
    {
        return $this->db->get_where('star',array('sid'=>$sid))->row_array();
    
    }
  function get_all_stars()
    {
         

     $this->db->select('star.* '
                       );
          return $this->db->get('star')->result_array();

 
    }
  function add_star($params)
    {
        $sid = $this->insert_post();
    $data = array(
        'sid' => $sid,
        //  ........ other data
    );
    $this->db->insert('star', $data);
       /* $this->db->insert('star',$params);
        return $this->db->insert_id();*/
    } 

    function update_star($sid,$params)
    {
        $this->db->where('sid',$sid);
        return $this->db->update('star',$params);
    }
     function delete_star($sid)
    {
        return $this->db->delete('star',array('sid'=>$sid));
    }
    function get_all_star_count()
    {
        $this->db->from('star');
        return $this->db->count_all_results();
    }
}
?>
