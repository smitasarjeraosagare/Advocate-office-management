<?php
class Tax_Model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
   function get_tax($tax_id)
    {
        return $this->db->get_where('tax',array('tax_id'=>$tax_id))->row_array();
    
    }
  function get_all_tax()
    {
         

     $this->db->select('tax.* '
                       );
          return $this->db->get('tax')->result_array();

 
    }
    function add_tax($params)
    {
        $this->db->insert('tax',$params);
        return $this->db->insert_id();
    }
    function update_tax($tax_id,$params)
    {
        $this->db->where('tax_id',$tax_id);
        return $this->db->update('tax',$params);
    }
     function delete_tax($tax_id)
    {
        return $this->db->delete('tax',array('tax_id'=>$tax_id));
    }
    function get_all_tax_count()
    {
        $this->db->from('tax');
        return $this->db->count_all_results();
    }

}
?>