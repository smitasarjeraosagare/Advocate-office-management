<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Base_Controller extends CI_Controller {

    function __construct()
    {
        parent::__construct();
    }

    function authenticate() {
        if(!$this->session->userdata('user_id') || !$this->session->userdata('username')) {
            $this->session->set_flashdata('error', 'Session expired, try login again!');
            redirect('auth/login');
        }
    }

    function authorize($role) {
        $this->authenticate();

        if($this->session->userdata('role') != $role) {
            $this->session->set_flashdata('error', 'Invalid access.');
            redirect('dashboard');
        }
    }
}
