

 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
	<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
  <script>tinymce.init({ selector:'textarea' });</script>
<script type="text/javascript">
  $(document).ready(function() {
  $('#cno').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#due').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
<script type="text/javascript">
  $(document).ready(function() {
  $('#hdate').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
 <script type="text/javascript">
  $(document).ready(function() {
  $('#fitness_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#insu_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#tax_rcp_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#mfg_date').datetimepicker({
    format: 'MM-YYYY',
 }); 
});
 </script>

<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title"> Edit task</h3>
            </div>
			<?php echo form_open('task/edit/'.$task['task_id']); ?>
			<div class="box-body">
				<div class="row clearfix">

					<div class="col-md-6">
						<label for="task" class="control-label">Title
						<span class="text-danger">*</span></label>
						<div class="form-group">
							<input type="text" name="task" value="<?php echo ($this->input->post('task') ? $this->input->post('task') : $task['task']); ?>" class="form-control" id="task" />
							<span class="text-danger"><?php echo form_error('task');?></span>
						</div>
					</div>
					<!--  <?php echo ($this->input->post('too') ? $this->input->post('too') : $task['too']); ?> -->
					
 <div class="col-md-6">
                        <label for="c_id" class="control-label"> Case
                            <span class="text-danger">*</span></label>

   <div class="form-group">
                                   <select   name="ctitle" id="c_id" class="form-control">
                                         <option value="">Select case</option>
                                              <?php
                                                  foreach($all_cases as $cases)
                                                  {

                                                  $selected = ($cases['ctitle'] == $this->input->post('ctitle')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$cases['c_id'].'" '.$selected.'>'.$cases['ctitle'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
                               <span class="text-danger"><?php echo form_error('ctitle');?></span>
                             </div>
                           </div>
                    <div class="col-md-6">
                        <label for="e_id" class="control-label"> employee
                            <span class="text-danger">*</span></label>

   <div class="form-group">
                                   <select   name="ename" id="e_id" class="form-control">
                                         <option value="">Select case</option>
                                              <?php
                                                  foreach($all_employee as $employee)
                                                  {

                                                  $selected = ($employee['ename'] == $this->input->post('ename')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$employee['e_id'].'" '.$selected.'>'.$employee['ename'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
                               <span class="text-danger"><?php echo form_error('ename');?></span>
                             </div> </div>

					
							
					<div class="col-md-6">
				     	<label for="due" class="control-label"> Filling  Date
					     	<span class="text-danger">*</span></label>
						<div class="form-group">
					      	<input type="text" name="due" value="<?php echo ($this->input->post('due') ? date('d-m-Y', strtotime($this->input->post('due'))) : date('d-m-Y', strtotime($task['due']))); ?>" class="has-datetimepicker form-control" id="due" />
                              <span class="text-danger"><?php echo form_error('due');?></span>
						</div>
					</div>
					<div class="col-md-6">
                        <label for="priority" class="control-label">Priority
                            <span class="text-danger">*</span>
                        </label>
                        <div class="form-group">
                             <select name="priority" class="form-control">
                              <option value="0">Select</option>
                           <option value="High">High</option>
                  <option value="Medium">Medium</option>
                        <option value="Low">Low</option>
   
  </select>
                  </div>     </div> 
<div class="col-md-6">
            <label for="progress" class="control-label">Progress
              <span class="slidecontainer" role="progressbar"></span></label>
            <div class="slidecontainer">
              <input type="range" name="progress" value="<?php echo $this->input->post('progress'); ?>" class="slider" id="progress"/>
              <span class="text-danger"><?php echo form_error('progress');?></span>
            </div></div>
					

					<div class="col-md-6">
						<label for="des" class="control-label">Description
						<span class="text-danger">*</span></label>
						<div class="form-group">
						<textarea name="des" value="<?php echo ($this->input->post('des') ? $this->input->post('des') : $task['des']); ?>" class="form-control" id="des"></textarea>
							<span class="text-danger"><?php echo form_error('des');?></span>
						</div>
					</div>
					
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Update
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>
</div>
</div>