
<?php

//mysql_connect('localhost', 'root', "");
//mysql_select_db("garment_inventory");



//$link = mysqli_connect("localhost","root","","garment_inventory");


$link = mysqli_connect("localhost", "gstuser", "gstpassword2019*", "gst");

$id = $_GET['id'];
$query = "select * from demo where id='$id'";
$query1 = mysqli_query($link, $query);

while($ros = mysql_fetch_array($query1))
{
	$path = $ros['path'];
	header('content-Disposotion: attachment; filename = '.$path.'');
	header('content-type:application/octent-strem');
	header('content-length='.filesize($path));
	readfile($path);
}
?>

<html>
<head>
	</head>

	<body></body>
</html>