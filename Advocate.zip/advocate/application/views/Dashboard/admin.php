 
 <style>
 
.css-serial {
  counter-reset: serial-number;  /* Set the serial number counter to 0 */
}

.css-serial td:first-child:before {
  counter-increment: serial-number;  /* Increment the serial number counter */
  content: counter(serial-number);  /* Display the counter */
}
</style>
<div></div>
<div class="row">
   <div class="col-lg-3 col-sm-6 col-xs-12">
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3>7</h3>
                        <p>Clients</p>
                    </div>
                    <div class="icon"><i class="fa fa-group"></i></div>
                     <a href="http://localhost/programs/advocate/Clients" class="small-box-footer">
                       More Info <i class="fa fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
          
            <div class="col-lg-3 col-sm-6 col-xs-12">
                <div class="small-box bg-green">
                    <div class="inner">
                        <h3>7</h3>
                        <p>Cases</p>
                    </div>
                    <div class="icon"><i class="fa fa-list"></i></div>
                    <a href="http://localhost/programs/advocate/cases" class="small-box-footer">
                        More Info  <i class="fa fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 col-xs-12">
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3>1</h3>
                        <p>Starred Cases</p>
                    </div>
                    <div class="icon"><i class="fa fa-star"></i></div>
                    <a href="http://localhost/programs/advocate/star" class="small-box-footer">
                       More Info <i class="fa fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 col-xs-12">
                <div class="small-box bg-red">
                    <div class="inner">
                        <h3>2</h3>
                        <p>Archived Cases</p>
                    </div>
                    <div class="icon"><i class="fa fa-archive"></i></div>
                    <a href="http://localhost/programs/advocate/archived" class="small-box-footer">
                       More Info <i class="fa fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
        </div>
     <div class="row">
            <div class="col-lg-3 col-sm-6 col-xs-12">
                <div class="small-box bg-blue">
                    <div class="inner">
                        <h3>0</h3>
                        <p>Employees</p>
                    </div>
                    <div class="icon"><i class="fa fa-users"></i></div>
                    <a href="http://localhost/programs/advocate/employees" class="small-box-footer">
                        More Info <i class="fa fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 col-xs-12">
                <div class="small-box bg-red">
                    <div class="inner">
                        <h3>7</h3>
                        <p>Tasks</p>
                    </div>
                    <div class="icon"><i class="fa fa-tasks"></i></div>
                    <a href="http://localhost/programs/advocate/task" class="small-box-footer">
                        More Info  <i class="fa fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 col-xs-12">
                <div class="small-box bg-light-blue-gradient">
                    <div class="inner">
                        <h3>6</h3>
                        <p>Case Study</p>
                    </div>
                    <div class="icon"><i class="fa fa-book"></i></div>
                    <a href="http://localhost/programs/advocate/study" class="small-box-footer">
                       More Info <i class="fa fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 col-xs-12">
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3>2</h3>
                        <p>My Tasks</p>
                    </div>
                    <div class="icon"><i class="fa fa-inbox"></i></div>
                    <a href="http://localhost/programs/advocate/mytask" class="small-box-footer">
                       More Info <i class="fa fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
        </div>
  
<div class="row dashboard-box-widget">  
            
       <section class="col-lg-6 col-sm-12 col-xs-12">   
          <div class="box box-solid">
            <div class="box-header with-border">
                <i class="ion ion-clipboard"></i>
                <h3 class="box-title">Today's Cases</h3>
            </div>
            <div class="box-body">
                <ul class="todo-list">
                                                                    
                 </ul>
             </div>
             <div class="box-footer clearfix no-border">
                <button class="btn btn-default pull-right">
                    <a href="http://localhost/programs/advocate/cases"><i class="fa fa-plus"></i> View All</a>
                </button>
             </div>
          </div>        
    </section>
                
    <section class="col-lg-6 col-sm-12 col-xs-12">  
        <div class="box box-solid">
            <div class="box-header with-border">
                <i class="fa fa-tasks"></i>
                <h3 class="box-title">Today's To Do</h3>
            </div>
            <div class="box-body">
                <ul class="todo-list ">
                                                                  <li>
                          <span class="text">
                            <a href="http://localhost/programs/advocate/Todolist/">Name </a>
                          </span>
                          <div class="tools">
                            <i class="fa fa-eye"></i>
                          </div>
                       </li>
                                            
                </ul>
            </div>
            <div class="box-footer clearfix no-border">
                <button class="btn btn-default pull-right">
                    <a href="http://localhost/programs/advocate/todolist"><i class="fa fa-plus"></i> View All</a>
                </button>
            </div>
        </div>
    </section>
                        
    <section class="col-lg-6 col-sm-12 col-xs-12">  
        <div class="box box-solid">
            <div class="box-header with-border">
                <i class="ion ion-clipboard"></i>
                <h3 class="box-title">Notice Board</h3>
            </div>
            <div class="box-body">
           <table id="tb" class="table css-serial   table-bordered" cellspacing="0" width="100%">
        <thead>

                  
                </thead>
                    <?php foreach($notice as $c){ ?>
                    <tr>
                        <td></td>
                        <td><?php echo $c['title']; ?></td>

                        <td><?php echo $c['nodate']; ?></td>

                    </tr>
                    <?php } ?>
                </table>
            <div class="box-footer clearfix no-border">
                <button class="btn btn-default pull-right">
                    <i class="fa fa-plus"></i> <a href="http://localhost/programs/advocate/notice">View All</a>
                </button>
            </div>
        </div>
    </section>
            <section class="col-lg-6 col-sm-12 col-xs-12">  
    <div class="box box-solid">
            <div class="box-header with-border">
                <i class="fa fa-user"></i>
                <h3 class="box-title">Attendance</h3>
            </div>
            <div class="box-body">
            
                                        <a href="#mark_in" class="btn bg-olive btn-flat margin" data-toggle="modal"  > <i class="fa fa-sign-in"></i> Mark In</a>
                 <a href="<?php echo site_url('Aleave/add'); ?>" style="float: right; padding-bottom: 3px;" class="btn bg-purple btn-flat margin" ><i class="fa fa-arrow-circle-up"></i>  Apply Leave</a>      
            </div>
      <div class="box-footer clearfix no-border">
                <a href="http://localhost/programs/advocate/Attendence/index" style="padding-right:7px" class="btn btn-default"><i class="fa fa-user"></i> My Attendance</a>
        <a href="http://localhost/programs/advocate/Aleave"  class="btn btn-default pull-right"><i class="fa fa-plus"></i> My Leaves</a>  
            </div>
    </div>
    </section>
    
  
      </div>
  
  <div class="row full-calendar">
    <div class="col-md-3">
      <div class="box box-solid">
        <div class="box-header with-border">
          <h4 class="box-title">Events</h4>
        </div>
        <div class="box-body">
          <!-- the events -->
          <div id="external-events">
            <div class="form-group">
                <select id='lang-selector' class="form-control select2" style="width: 100%;">
                </select>
            </div>
            <div class="external-event bg-light-blue">Appointments</div>
            <div class="external-event bg-red">Cases</div>
          </div>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /. box -->
    </div>
    <!-- /.col -->
    <div class="col-md-9">
      <div class="box box-solid">
        <div class="box-body">
          <!-- THE CALENDAR -->
          <div id="calendar"></div>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /. box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
    
  
  <!-- Case Alert setting for client -->
  <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false">
      <div class="modal-dialog">
        <div class="modal-content">
          <form action="http://localhost/programs/advocate/my_cases/case_alert" method="post" accept-charset="utf-8" enctype="multipart/form-data">  
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="false">&times;</span></button>
            <h4 class="modal-title">Case Alert Days Settings</h4>
          </div>
          <div class="modal-body">
             <div class="form-group">
                  <label>Case Alert Days</label>
                  <input type="number" class="form-control" name="days" value="" />
             </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Save</button>
          </div>
          </form>        </div>
        <!-- /.modal-content -->
      </div>
      <!-- /.modal-dialog -->
  </div>
  <!-- /.modal -->
  
  
  <!-- Modal Box for Mark In ( Attendance ) -->
  <div class="modal fade" id="mark_in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false">
      <div class="modal-dialog">
        <div class="modal-content">
          <form action="http://localhost/programs/advocate/attendance/mark_in" method="post" accept-charset="utf-8" enctype="multipart/form-data">          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="false">&times;</span></button>
            <h4 class="modal-title">Mark In</h4>
          </div>
          <div class="modal-body">
            <div class="form-group">
                <label>Notes</label>
                <textarea class="form-control" rows="3" name="notes"></textarea>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Save</button>
          </div>
          </form>        </div>
        <!-- /.modal-content -->
      </div>
      <!-- /.modal-dialog -->
  </div>

  <!DOCTYPE html>
<html>
<head>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha.6/css/bootstrap.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.min.js"></script>
    <script><!-- 
    $(document).ready(function(){
        var calendar = $('#calendar').fullCalendar({
            editable:false,
            header:{
                left:'prev,next today',
                center:'title',
                right:'month,agendaWeek,agendaDay'
            },
            events:"<?php echo base_url(); ?>dashboard/load",
            selectable:false,
            selectHelper:false,
            select:function(start, end, allDay)
            {
                var title = prompt("Enter Event Title");
                if(title)
                {
                    var start = $.fullCalendar.formatDate(start, "Y-MM-DD HH:mm:ss");
                    var end = $.fullCalendar.formatDate(end, "Y-MM-DD HH:mm:ss");
                    $.ajax({
                        url:"<?php echo base_url(); ?>dashboard/insert",
                        type:"POST",
                        data:{title:title, start:start, end:end},
                        success:function()
                        {
                            calendar.fullCalendar('refetchEvents');
                            alert("Added Successfully");
                        }
                    })
                }
            },
            editable:false,
            eventResize:function(event)
            {
                var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD HH:mm:ss");
                var end = $.fullCalendar.formatDate(event.end, "Y-MM-DD HH:mm:ss");

                var title = event.title;

                var id = event.id;

                $.ajax({
                    url:"<?php echo base_url(); ?>dashboard/update",
                    type:"POST",
                    data:{title:title, start:start, end:end, id:id},
                    success:function()
                    {
                        calendar.fullCalendar('refetchEvents');
                        alert("Event Update");
                    }
                })
            },
            eventDrop:function(event)
            {
                var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD HH:mm:ss");
                //alert(start);
                var end = $.fullCalendar.formatDate(event.end, "Y-MM-DD HH:mm:ss");
                //alert(end);
                var title = event.title;
                var id = event.id;
                $.ajax({
                    url:"<?php echo base_url(); ?>dashboard/update",
                    type:"POST",
                    data:{title:title, start:start, end:end, id:id},
                    success:function()
                    {
                        calendar.fullCalendar('refetchEvents');
                        alert("Event Updated");
                    }
                })
            },
            eventClick:function(event)
            {
                if(confirm("Are you sure you want to remove it?"))
                {
                    var id = event.id;
                    $.ajax({
                        url:"<?php echo base_url(); ?>dashboard/delete",
                        type:"POST",
                        data:{id:id},
                        success:function()
                        {
                            calendar.fullCalendar('refetchEvents');
                            alert('Event Removed');
                        }
                    })
                }
            }
        });
    });
             
    </script>
</head>
    <body>
        <div class="container">
            <div id="calendar"></div>
        </div>
    </body>
</html>
  <!-- /.modal -->
  <!-- Morris.js charts -->
   -->
  <script src="http://advocate.webappsdemo.in/assets/plugins/morris/raphael-min.js"></script>
  <script src="http://advocate.webappsdemo.in/assets/plugins/morris/morris.min.js" type="text/javascript"></script>
  
  <!-- Sparkline -->
  <script src="http://advocate.webappsdemo.in/assets/plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>
  <!-- jvectormap -->
  <script src="http://advocate.webappsdemo.in/assets/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
  <script src="http://advocate.webappsdemo.in/assets/plugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
  <!-- fullCalendar -->
  <script src="http://advocate.webappsdemo.in/assets/plugins/fullcalendar/moment.min.js" type="text/javascript"></script>
  <script src="http://advocate.webappsdemo.in/assets/plugins/fullcalendar/fullcalendar.min.js" type="text/javascript"></script>
  <script src="http://advocate.webappsdemo.in/assets/plugins/fullcalendar/lang-all.js" type="text/javascript"></script>
  <!-- jQuery Knob Chart -->
  <script src="http://advocate.webappsdemo.in/assets/plugins/jqueryKnob/jquery.knob.js" type="text/javascript"></script>
  <script src="http://advocate.webappsdemo.in/assets/plugins/jquery.datetimepicker/jquery.datetimepicker.js" type="text/javascript"></script>

  <script type="text/javascript">
