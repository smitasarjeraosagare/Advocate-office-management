 
<div class="panel  panel-danger bord"  >
      <div class="panel-heading  red-color">Case
                    <!--  <a href="<?php echo site_url('Employees/add'); ?>" style="float: right; padding-bottom: 3px;" class="btn btn-danger btn-sm">Add</a>  -->
                </div>  
      
             <div class="box-body">

         
        <div class="table-responsive" >  
 <!-- try -->
 <div class="row" style="margin-bottom:10px;">
            <div class="col-xs-12">
                <div class="">
                    <div class="col-xs-2">
            <select name="filter" id="Attendence_id" class="form-control chzn">
              <option>--Filter By Attendence--</option>
                                </select>
          </div>
          
           <div class="col-xs-2">
            <select name="filter_court" id="court_id" class="form-control chzn">
              <option>--Filter By Court--</option>
                  <option value="4" >Civil</option><option value="6" >Sidney Rema</option><option value="7" >sargodha courts</option>           </select>
          </div>
            
           <div class="col-xs-2">
            <select name="filter_location" id="location_id" class="form-control chzn">
              <option>--Filter By Location--</option>
              <option value="22" >Muscat</option><option value="23" >Seeb</option><option value="25" >sargodha</option>           </select>
          </div>
          
          <div class="col-xs-2">
            <select name="filter_location" id="case_sAttendencee_id" class="form-control chzn">
              <option>--Filter By Case SAttendencees--</option>
              <option value="6" >Filing</option><option value="8" >Pre-Trial</option><option value="5" >Preliminary Hearing</option><option value="7" >Service of summons</option><option value="9" >Hearing</option><option value="10" >Submissions 2</option><option value="11" >Judgement</option>           </select>
          </div>
          
          <div class="col-xs-2">
            <input type="text" name="date1" id="date1" class="form-control datepicker" placeholder="Filling Date" />
          </div>
          
          <div class="col-xs-2">
            <input type="text" name="date2" id="date2" class="form-control datepicker" placeholder="Hearing Date" />
          </div>
          
                </div>
            </div>    
        </div>  
        
        <div class="row">
          <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                                                      
                </div><!-- /.box-header -->


 <!-- finish --><!-- form -->
<div class="row">
    <div class="col-md-12">
        <div class="box box-info" style="border-top-color: #605ca8">
            <div class="box-header with-border">
                <h3 class="box-title"></h3>
            </div>
            <?php echo form_open('Attendence/add'); ?>
            <div class="box-body">
              <div class="row clearfix">

   <div class="col-md-6">
                        <label for="e_id" class="control-label"> Employee
                            <span class="text-danger">*</span></label>

   <div class="form-group">
                                   <select   name="ename" id="e_id" class="form-control">
                                         <option value="">Select Employee</option>
                                              <?php
                                                   foreach($all_employees as $employee)
                                                  {

                                                  $selected = ($employee['ename'] == $this->input->post('ename')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$employee['e_id'].'" '.$selected.'>'.$employee['ename'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
                               <span class="text-danger"><?php echo form_error('ename');?></span>
                             </div>
                           </div>
                      <div class="col-md-6">
            <label for="datefrom" class="control-label"> Date From
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="date" name="datefrom" value="<?php echo $this->input->post('datefrom'); ?>" class="form-control" id="datefrom" />
              <span class="text-danger"><?php echo form_error('datefrom');?></span>
            </div>
          </div>
 <div class="col-md-6">
            <label for="dateto" class="control-label"> Date To
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="date" name="dateto" value="<?php echo $this->input->post('dateto'); ?>" class="form-control" id="dateto" />
              <span class="text-danger"><?php echo form_error('dateto');?></span>
            </div>
          </div>
          
            <div class="box-footer">
              <button type="submit" class="btn btn-success">
                <i class="fa fa-check"></i> Save
              </button>
            </div></div></div>
</div></div></div></div></div></div>