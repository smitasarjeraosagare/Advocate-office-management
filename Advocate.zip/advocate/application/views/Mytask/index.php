 
<style>
.css-serial {
  counter-reset: serial-number;  /* Set the serial number counter to 0 */
}

.css-serial td:first-child:before {
  counter-increment: serial-number;  /* Increment the serial number counter */
  content: counter(serial-number);  /* Display the counter */
}
</style>
 <style>
         .star {
         background-color: transparent;
         background-image: url('http://localhost/technicalkeeda/images/star-off.png');
         background-repeat:no-repeat;
         display: block;  
         height:16px;
         width:16px;
         float:left;
         } 
         .favorited {
         text-indent: -5000px;
         background-color: transparent;
         background-image: url('http://localhost/technicalkeeda/images/star-on.png');
         background-repeat:no-repeat;   
         height:16px;
         width:16px;
         float:left;
         }
      </style>

<script>
function confirm_delete()
{
    if(confirm("Are you sure you want to delete this record ?"))
    {
        return true;
    }
    else
    {
        return false;
    }
}   
function star()
{
    if(confirm(Add to Star))
    {
        return true;
    }
    else
    {
        return false;
    }
}   
</script>
<script type="text/javascript" language="javascript" src="http://code.jquery.com/jquery-latest.js"></script>
      <script>
        $(document).ready(function(){ 
           $('.star,.favorited').click(function() {
            var id = $(this).parents('div').attr('id');    
            var className = $(this).attr('class');
            var flag  = (className=='star') ? 'Y':'N';
            var $this = $(this);
            $.ajax({
              type: "post",
              url: "http://localhost/technicalkeeda/demo",
              cache: false,    
              data:{'sid': id,'sflag':flag},
              success: function(response){
               if(response=='true'){        
                $this.toggleClass("favorited");
               } 
              },
              error: function(){      
               alert('Error while request..');
              }
              });
            });
         });
      </script>



 
<div class="panel  panel-danger bord"  >
      <div class="panel-heading  red-color">Case
                     
                </div>  
      
             <div class="box-body">

         
        <div class="table-responsive" >  
 <!-- try -->
  <div class="row" style="margin-bottom:10px;">
            <div class="col-xs-12">
                <div class="">
            <!--         <div class="col-xs-2">
            <select   name="ctitle" id="c_id" class="form-control">
                                         <option value="">--Filter By Client--</option>
                                              <?php
                                                  foreach($all_cases as $cases)
                                                  {

                                                  $selected = ($cases['ctitle'] == $this->input->post('ctitle')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$cases['c_id'].'" '.$selected.'>'.$cases['ctitle'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
          </div> -->
           <div class="col-xs-2">
            <select   name="name" id="cl_id" class="form-control">
                                         <option value="">--Filter By Client--</option>
                                              <?php
                                                   foreach($all_clients as $client)
                                                  {

                                                  $selected = ($client['name'] == $this->input->post('name')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$client['cl_id'].'" '.$selected.'>'.$client['name'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
          </div>
          
           <div class="col-xs-2">
             <select   name="court" id="court_id" class="form-control">
                                         <option value="">--Filter By Court--</option>
                                              <?php
                                                  foreach($all_court as $court)
                                                  {

                                                  $selected = ($court['court'] == $this->input->post('court')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$court['court_id'].'" '.$selected.'>'.$court['court'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
          </div>
            
           <div class="col-xs-2">
             <select   name="lname" id="l_id" class="form-control">
                                         <option value="">--Filter By Location--</option>
                                              <?php
                                                   foreach($all_location as $location)
                                                  {

                                                  $selected = ($location['lname'] == $this->input->post('lname')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$location['l_id'].'" '.$selected.'>'.$location['lname'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
          </div>
          
          <div class="col-xs-2">
            <select   name="catname" id="cc_id" class="form-control">
                                         <option value="">--Filter By Category--</option>
                                              <?php
                                                  foreach($all_casecategory as $casecategory)
                                                  {

                                                  $selected = ($casecategory['catname'] == $this->input->post('catname')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$casecategory['cc_id'].'" '.$selected.'>'.$casecategory['catname'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
          </div>
          
          <div class="col-xs-2">
            <input type="text" name="date1" id="date1" class="form-control datepicker" placeholder="Filling Date" />
          </div>
          
          <div class="col-xs-2">
            <input type="text" name="date2" id="date2" class="form-control datepicker" placeholder="Hearing Date" />
          </div>
          
                </div>
            </div>    
        </div>  
            </div>    
        </div>  
        
        <div class="row">
          <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                                                      
                </div><!-- /.box-header -->


 <!-- finish -->
 
            <table id="tb" class="table css-serial   table-bordered" cellspacing="0" width="100%">
        <thead>

                    <tr>
                        <th>Sr. No</th>
                        <th>Name</th>
                        <th>Priority</th><th>Due Date</th>
                        <th>Action</th>

                       

                    </tr>
                </thead>
                    <?php foreach($task as $c){ ?>
                    <tr>
                        <td></td>
                       

 
                        <td><?php echo $c['task']; ?></td>

                        <td><?php echo $c['priority']; ?></td>
                        <td><?php echo $c['due']; ?></td>

                       

 
                                            
                        <td>
                            <a href="<?php echo site_url('Task/view/'.$c['task_id']); ?>" ><button class="btn btn-primary btn-xs"><span>View</span></button>  </a>

                            <a href="<?php echo site_url('Task/edit/'.$c['task_id']); ?>" ><button class="btn btn-info btn-xs"><span>Edit</span></button>  </a>

                            <a href="<?php echo site_url('Task/remove/'.$c['task_id']); ?>" class="btn btn-danger btn-xs" onclick="return confirm_delete()"><button class="btn btn-danger btn-xs"><span>Delete</span></button>  </a>
                            
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                            
            </div>
        </div>
    </div>
</div>

 
  <script>
  $(function(){
    $("#tb").dataTable();
  })
  </script>
