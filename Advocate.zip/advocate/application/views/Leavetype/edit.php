

 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

 
<script type="text/javascript">
  $(document).ready(function() {
  $('#des').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#fdate').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
<script type="text/javascript">
  $(document).ready(function() {
  $('#hdate').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
 <script type="text/javascript">
  $(document).ready(function() {
  $('#fitness_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() 
  $('#insu_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#tax_rcp_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#mfg_date').datetimepicker({
    format: 'MM-YYYY',
 }); 
});
 </script>

<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title"> Edit Leavetype</h3>
            </div>
			<?php echo form_open('Leavetype/edit/'.$leavetype['le_id']); ?>
			<div class="box-body">
				<div class="row clearfix">

					<div class="col-md-6">
						<label for="leav" class="control-label"> Leave
						<span class="text-danger">*</span></label>
						<div class="form-group">
							<input type="text" name="leav" value="<?php echo ($this->input->post('leav') ? $this->input->post('leav') : $leavetype['leav']); ?>" class="form-control" id="leav" /> <span class="text-danger"><?php echo form_error('leav');?></span>
						</div>
					</div>
					


					<div class="col-md-6">
						<label for="des" class="control-label"> Description
						<span class="text-danger">*</span></label>
						<div class="form-group">
							<input type="textarea" name="des" value="<?php echo ($this->input->post('des') ? $this->input->post('des') : $leavetype['des']); ?>" class="form-control" id="des" /> <span class="text-danger"><?php echo form_error('des');?></span>
						</div>
					</div>


					
				
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Update
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>
</div>
</div>