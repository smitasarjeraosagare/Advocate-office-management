<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>


<script type="text/javascript">
  $(document).ready(function() {
  $('#reg_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#permit_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
<script type="text/javascript">
  $(document).ready(function() {
  $('#puc_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
</script>
 <script type="text/javascript">
  $(document).ready(function() {
  $('#fitness_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#insu_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#tax_rcp_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#mfg_date').datetimepicker({
    format: 'MM-YYYY',
 }); 
});
 </script>
 <div class="row">
    <div class="col-md-12">
      	<div class="box box-info" style="border-top-color: #605ca8">
            <div class="box-header with-border">
              	<h3 class="box-title">Notification Setting</h3>
            </div>
            <?php echo form_open('Notification/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">                    

          <div class="col-md-6">
            <label for="cas" class="control-label">
            Case Alert Days  
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="number" name="cas" value="<?php echo $this->input->post('cas'); ?>" class="form-control" id="cas" />
              <span class="text-danger"><?php echo form_error('cas');?></span>
            </div>
          </div>
          <div class="col-md-6">
             <div class="col-md-6">
            <label for="todo" class="control-label">
            To Do Alert Days
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="number" name="todo" value="<?php echo $this->input->post('todo'); ?>" class="form-control" id="todo" />
              <span class="text-danger"><?php echo form_error('todo');?></span>
            </div></div>
          </div>
           <div class="col-md-6">
            <label for="appoint" class="control-label">
            Appointment Alert Days
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="number" name="appoint" value="<?php echo $this->input->post('appoint'); ?>" class="form-control" id="appoint" />
              <span class="text-danger"><?php echo form_error('appoint');?></span>
            </div>
          </div>

	        	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div></div></div>
</div></div></div> 
<style>
.css-serial {
  counter-reset: serial-number;  /* Set the serial number counter to 0 */
}

.css-serial td:first-child:before {
  counter-increment: serial-number;  /* Increment the serial number counter */
  content: counter(serial-number);  /* Display the counter */
}
</style>
 <style>
         .star {
         background-color: transparent;
         background-image: url('http://localhost/technicalkeeda/images/star-off.png');
         background-repeat:no-repeat;
         display: block;  
         height:16px;
         width:16px;
         float:left;
         } 
         .favorited {
         text-indent: -5000px;
         background-color: transparent;
         background-image: url('http://localhost/technicalkeeda/images/star-on.png');
         background-repeat:no-repeat;   
         height:16px;
         width:16px;
         float:left;
         }
      </style>

<script>
function confirm_delete()
{
    if(confirm("Are you sure you want to delete this record ?"))
    {
        return true;
    }
    else
    {
        return false;
    }
}   
function star()
{
    if(confirm(Add to Star))
    {
        return true;
    }
    else
    {
        return false;
    }
}   
</script>
<script type="text/javascript" Notification="javascript" src="http://code.jquery.com/jquery-latest.js"></script>
      <script>
        $(document).ready(function(){ 
           $('.star,.favorited').click(function() {
            var id = $(this).parents('div').attr('id');    
            var classcas = $(this).attr('class');
            var flag  = (classcas=='star') ? 'Y':'N';
            var $this = $(this);
            $.ajax({
              type: "post",
              url: "http://localhost/technicalkeeda/demo",
              cache: false,    
              data:{'sid': id,'sflag':flag},
              success: function(response){
               if(response=='true'){        
                $this.toggleClass("favorited");
               } 
              },
              error: function(){      
               alert('Error while request..');
              }
              });
            });
         });
      </script>




