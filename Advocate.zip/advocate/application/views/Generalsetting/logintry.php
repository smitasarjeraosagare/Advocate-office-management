<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Advocate</title>
        <!-- Tell the browser to be responsive to screen width -->
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <!-- Bootstrap 3.3.6 -->
        <link rel="stylesheet" href="<?php echo site_url('resources/css/bootstrap.min.css');?>">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="<?php echo site_url('resources/css/font-awesome.min.css');?>">
        <!-- Ionicons -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
        <!-- Datetimepicker -->
        <link rel="stylesheet" href="<?php echo site_url('resources/css/bootstrap-datetimepicker.min.css');?>">
        <!-- Theme style -->
        <link rel="stylesheet" href="<?php echo site_url('resources/css/AdminLTE.min.css');?>">
        <!-- AdminLTE Skins. Choose a skin from the css/skins
             folder instead of downloading all of them to reduce the load. -->
        <link rel="stylesheet" href="<?php echo site_url('resources/css/_all-skins.min.css');?>">
    </head>

    <body class="hold-transition skin-blue sidebar-mini" style=" background-repeat: no-repeat;
  background-size: 100% 100%; background-image: url('/cpaccounting/resources/img/cpcash.jpg');">
            <img   style="width: 7%; display: block; margin-left: auto; margin-right: auto; margin-bottom: -90px; padding-top: 60px"/> <div class="login-box" style=" border: 0;  border-radius: 1rem;  box-shadow: 0 0.5rem 1rem 0 rgba(0, 0, 0, 0.2);">
            <div class="login-box-body" style="border-radius: 10px;background-color:lavender;
"><h3>   <p class="login-box-msg" style="color: #black">Login</p></h3> 
                <?php
                    if($this->session->flashdata('error')) {
                ?>
               
                <?php
                    }
                ?>
            </div>
        </div>
        <div class="tabbable">
                            
                                <ul class="nav nav-tabs">
                                    <li class="active"><a href="#1" data-toggle="tab">Admin</a></li>
                                    <li><a href="#2" data-toggle="tab">Client</a></li>
                                    <li><a href="#3" data-toggle="tab">Employee</a></li>
                                </ul>
                                <div class="tab-content">
                                    <div class="tab-pane active" id="1">
            <form action="<?php echo base_url('auth/login');?>" method="post">
                    <div class="form-group has-feedback">
                        <input type="email" class="form-control" name="email" placeholder="Email">
                        <span class=" form-control-feedback"></span>
                        <?php
                            if(form_error('email')) {
                        ?>
                            <span class="help-block"><?php echo form_error('password');?></span>
                        <?php
                            }
                        ?>
                    </div>
                    <div class="form-group has-feedback">
                        <input type="password" class="form-control" name="password" placeholder="Password">
                        <spans></span>
                        <?php
                            if(form_error('password')) {
                        ?>
                            <span class="help-block"><?php echo form_error('password');?></span>
                        <?php
                            }
                        ?></form>
                    </div>
                    <div class="row">
                        <div class="col-xs-12">
                            <button type="submit">Sign In</button>
                         
                            
</form>
                       
      <a href="<?php echo site_url('Admin/register'); ?>" class="btn btn-success btn-sm">Sign up</a>
                    </div>
                </div>
<div class="tab-content">
                                    <div class="tab-pane active" id="2">
            <form action="<?php echo base_url('auth/login');?>" method="post">
                    <div class="form-group has-feedback">
                        <input type="email" class="form-control" name="email" placeholder="Email">
                        <span class=" form-control-feedback"></span>
                        <?php
                            if(form_error('email')) {
                        ?>
                            <span class="help-block"><?php echo form_error('password');?></span>
                        <?php
                            }
                        ?>
                    </div>
                    <div class="form-group has-feedback">
                        <input type="password" class="form-control" name="password" placeholder="Password">
                        <spans></span>
                        <?php
                            if(form_error('password')) {
                        ?>
                            <span class="help-block"><?php echo form_error('password');?></span>
                        <?php
                            }
                        ?></form>
                    </div>
                    <div class="row">
                        <div class="col-xs-12">
                            <button type="submit">Sign In</button>
                            <h5>I don't have account</h5>
                            
</form>
</div></div>
<div class="tab-content">
                                    <div class="tab-pane active" id="3">
            <form action="<?php echo base_url('auth/login');?>" method="post">
                    <div class="form-group has-feedback">
                        <input type="email" class="form-control" name="email" placeholder="Email">
                        <span class=" form-control-feedback"></span>
                        <?php
                            if(form_error('email')) {
                        ?>
                            <span class="help-block"><?php echo form_error('password');?></span>
                        <?php
                            }
                        ?>
                    </div>
                    <div class="form-group has-feedback">
                        <input type="password" class="form-control" name="password" placeholder="Password">
                        <spans></span>
                        <?php
                            if(form_error('password')) {
                        ?>
                            <span class="help-block"><?php echo form_error('password');?></span>
                        <?php
                            }
                        ?></form>
                    </div>
                    <div class="row">
                        <div class="col-xs-12">
                            <button type="submit">Sign In</button>
                            <h5>I don't have account</h5>
                            
</form></div></div></div>
