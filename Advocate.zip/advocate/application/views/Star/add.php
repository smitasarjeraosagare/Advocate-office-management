<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#reg_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#permit_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
<script type="text/javascript">
  $(document).ready(function() {
  $('#puc_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
</script>
 <script type="text/javascript">
  $(document).ready(function() {
  $('#fitness_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#insu_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#tax_rcp_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#mfg_date').datetimepicker({
    format: 'MM-YYYY',
 }); 
});
 </script>
 <div class="row">
    <div class="col-md-12">
      	<div class="box box-info" style="border-top-color: #605ca8">
            <div class="box-header with-border">
              	<h3 class="box-title">Add Client</h3>
            </div>
            <?php echo form_open('client/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">

	
	<div class="col-md-6">
						<label for="ctitle" class="control-label">
						Case Title
            <span class="text-danger"></span></label>
						<div class="form-group">
							<input type="text" name="ctitle" value="<?php echo $this->input->post('ctitle'); ?>" class="form-control" id="ctitle" />
							<span class="text-danger"><?php echo form_error('ctitle');?></span>
						</div>
					</div>
	<div class="col-md-6">
						<label for="cno" class="control-label">
						client no
					    <span class="text-danger"></span></label>
						<div class="form-group">
							<input type="text" name="cno" value="<?php echo $this->input->post('cno'); ?>" class="form-control" id="cno" />
							<span class="text-danger"><?php echo form_error('cno');?></span>
						</div>
					</div>
          <div class="col-md-6">
            <label for="cname" class="control-label">
            Client
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="text" name="cname" value="<?php echo $this->input->post('cname'); ?>" class="form-control" id="cname" />
              <span class="text-danger"><?php echo form_error('cname');?></span>
            </div>
          </div>
          <div class="col-md-6">
            <label for="cno" class="control-label">
            Location
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="text" name="loc" value="<?php echo $this->input->post('loc'); ?>" class="form-control" id="loc" />
              <span class="text-danger"><?php echo form_error('loc');?></span>
            </div>
          </div>
          <div class="col-md-6">
             <label for="ccat" class="control-label">  Court Category
                <span class="text-danger">*</span></label>
                   <div class="form-group">
                      <select id="ccat" name="ccat" class="form-control">
                         <option value="">Select </option>
                                   <option value="Own">Own</option>
                                   <option value="Other">Other</option>
                       </select>
                 <span class="text-danger"><?php echo form_error('ccat');?></span>
                </div>
            </div>
           
            <div class="col-md-6">
                        <label for="ccourt" class="control-label">  Court
                            <span class="text-danger">*</span></label>
                        <div class="form-group">
                            <select id="ccourt" name="ccourt" class="form-control">
                                   <option value="">Select company</option>
                                   <option value="Civil">Civil</option>
                                   <option value="high">High</option>
                                    <option value="supreme">Supreme</option>
                            </select>
                            <span class="text-danger"><?php echo form_error('ccourt');?></span>
                        </div>
                    </div>

                       <div class="col-md-6">
                        <label for="cstage" class="control-label">  Case Stage
                            <span class="text-danger">*</span></label>
                        <div class="form-group">
                            <select id="cstage" name="cstage" class="form-control">
                                   <option value="">Select </option>
                                   <option value="Criminal">Crimilnal</option>
                                   <option value="Bankrupt">Bankrupt</option>
                                    <option value="fraud">Fraud</option>
                            </select>
                            <span class="text-danger"><?php echo form_error('cstage');?></span>
                        </div>
                       <div class="col-md-6">
                        <label for="act" class="control-label"> Act
                            <span class="text-danger">*</span></label>
                        <div class="form-group">
                            <select id="act" name="act" class="form-control">
                                    <option value="0">Select</option>
                              <option value="income tax">Income tax</option>
                              <option value="corruption">Corruption</option>
                              <option value="drug">Article 127(Drug)</option>
                              <option value="kill">Article 128(murder)</option>
                              <option value="Divorce">Divorce</option>
                            </select>
                            <span class="text-danger"><?php echo form_error('act');?></span>
                        </div>
                      
                       <div class="col-md-6" >
            <label for="des" class="control-label">Description 
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="text" name="des" value="<?php echo $this->input->post('des'); ?>" class="form-control" id="des" />
              <span class="text-danger"><?php echo form_error('des');?></span>
            </div>
          </div><br>
          <div class="col-md-6">
            <label for="fdate" class="control-label">Filling Date
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="date" name="fdate" value="<?php echo $this->input->post('fdate'); ?>" class="form-control" id="fdate" />
              <span class="text-danger"><?php echo form_error('fdate');?></span>
            </div>
          </div>
 <div class="col-md-6">
            <label for="hdate" class="control-label">Hearing Date
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="date" name="hdate" value="<?php echo $this->input->post('hdate'); ?>" class="form-control" id="hdate" />
              <span class="text-danger"><?php echo form_error('hdate');?></span>
            </div>
          </div>
          <div class="col-md-6">
            <label for="opp" class="control-label">Opposite To 
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="text" name="opp" value="<?php echo $this->input->post('opp'); ?>" class="form-control" id="opp" />
              <span class="text-danger"><?php echo form_error('assign');?></span>
            </div>
            <div class="col-md-6">
            <label for="tfees" class="control-label">Total Fees
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="text" name="tfees" value="<?php echo $this->input->post('tfees'); ?>" class="form-control" id="tfees" />
              <span class="text-danger"><?php echo form_error('tfees');?></span>
            </div>
          </div>
          </div>
           <div class="col-md-6">
            <label for="assign" class="control-label">Assign To 
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="datetimepicker" name="assign" value="<?php echo $this->input->post('assign'); ?>" class="form-control" id="assign" />
              <span class="text-danger"><?php echo form_error('assign');?></span>
            </div>
          </div>

	        	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
</html>