<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Welcome</title>
        <!-- Tell the browser to be responsive to screen width -->
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <!-- Bootstrap 3.3.6 -->
        <link rel="stylesheet" href="<?php echo site_url('resources/css/bootstrap.min.css');?>">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="<?php echo site_url('resources/css/font-awesome.min.css');?>">
        <!-- Ionicons -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
        <!-- Datetimepicker -->
        <link rel="stylesheet" href="<?php echo site_url('resources/css/bootstrap-datetimepicker.min.css');?>">
        <!-- Theme style -->
        <link rel="stylesheet" href="<?php echo site_url('resources/css/AdminLTE.min.css');?>">
        <!-- AdminLTE Skins. Choose a skin from the css/skins
             folder instead of downloading all of them to reduce the load. -->
        <link rel="stylesheet" href="<?php echo site_url('resources/css/_all-skins.min.css');?>">
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<script language="JavaScript" src="https://code.jquery.com/jquery-1.11.1.min.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
 
 
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>





    </head>
    <style type="text/css">
    .bord
    {
        border: 1px solid #6c0107
    }
        .red-color
     
{
   background: #6c0107 !important;
      color: #ffffff !important;
      
}
        body
        {
            font-family: sans-serif;
        }
    </style>
    <body class="hold-transition skin-blue sidebar-mini">




        <div class="wrapper">
            <header class="main-header">
                <!-- Logo -->
                <a href="" class="logo">
                    <!-- mini logo for sidebar mini 50x50 pixels -->
                     <!-- logo for regular state and mobile devices -->
                    <span style="font-size:14px" class="logo-lg"> Advocate Office Management  </span>
                </a>
                <!-- Header Navbar: style can be found in header.less -->
                <nav class="navbar navbar-static-top">
                    <!-- Sidebar toggle button-->
                    <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>

                    <div class="navbar-custom-menu">
                        <ul class="nav navbar-nav">
                        <!-- User Account: style can be found in dropdown.less -->
                            <li class="dropdown user user-menu">
                                <a href="<?php echo base_url('auth/logout'); ?>" >Sign out</a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </header>
            <!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
                <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
                    <!-- Sidebar user panel -->

                      <div class="user-panel">
                        <div class="pull-left image">
                       <img  />
    
                        </div>

                     
                        <div class="pull-left info" style="margin-top: 5px;">
                            
                                <label>User :</label>
                               <?php echo ucfirst($this->session->userdata('username')) ?>
                            
                             

                              
                        </div>
                    </div>
                     <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-menu">
             <li>
                <a style="background-color: #4e4e4e" href="<?php echo site_url();?>"  >
                <i class="fa fa-dashboard"></i>  <span class="pull-down-container">Dashboard</span>
                </a>
            </li>

        <li>
            <a href=""><i class="fa fa-group"></i>
                 <span class="pull-down-container">
                HR Management</span>
                  <i class="fa fa-angle-down pull-down"></i>
                 
            </a>
        <ul class="treeview-menu">
                <li class="active">
                    <a href="<?php echo site_url('Clients/index');?>">
                        <i></i>  <span class="pull-down-container">Client</span>
                    </a>
                </li>  
            </ul>
           <ul class="treeview-menu">
                <li class="active">
                    <a href="<?php echo site_url('Employees/index');?>">
                        <i></i>  <span class="pull-down-container">Employees</span>
                    </a>
                </li>  
            </ul>
            <ul class="treeview-menu">
                <li class="active">
                    <a href="<?php echo site_url('Userrole/index');?>">
                        <i></i>  <span class="pull-down-container">User Role</span>
                    </a>
                </li>  
            </ul>
            <ul class="treeview-menu">
                <li class="active">
                    <a href="<?php echo site_url('Department/index');?>">
                        <i></i>  <span class="pull-down-container">Department</span>
                    </a>
                </li>  
            </ul>
            <!-- <ul class="treeview-menu">
                <li class="active">
                    <a href="<?php echo site_url('Premission/index');?>">
                        <i></i>  <span class="pull-down-container">Premission</span>
                    </a>
                </li>  
            </ul> -->
            <ul class="treeview-menu">
                <li class="active">
                    <a href="<?php echo site_url('Holiday/index');?>">
                        <i></i>  <span class="pull-down-container">Holidays</span>
                    </a>
                </li>  
            </ul>
            <ul class="treeview-menu">
                <li class="active">
                    <a href="<?php echo site_url('Notice/index');?>">
                        <i></i>  <span class="pull-down-container">Notice</span>
                    </a>
                </li>  
            </ul>
            <ul class="treeview-menu">
                <li class="active">
                    <a href="<?php echo site_url('Leavetype/index');?>">
                        <i></i>  <span class="pull-down-container">Leave Types</span>
                    </a>
                </li>  
            </ul>
            <ul class="treeview-menu">
                <li class="active">
                    <a href="<?php echo site_url('Attendence/index');?>">
                        <i></i>  <span class="pull-down-container">Attendence</span>
                    </a>
                </li>  
            </ul>
            <ul class="treeview-menu">
                <li class="active">
                    <a href="<?php echo site_url('Aleave/index');?>">
                        <i></i>  <span class="pull-down-container">Leave Notification</span>
                    </a>
                </li>  
            </ul>
           </li> 
           
        <li>
            <a href="">
                <i class="fa fa-th"></i>  <span class="pull-down-container">Cases</span>
                 <i class="fa fa-angle-down pull-down"></i>
            </a>
       
            <ul class="treeview-menu" style="list-style-type:square">
                <li class="active">
                    <a href="<?php echo site_url('Cases/index');?>">
                        <i ></i>  <span class="pull-down-container">All Cases
                        </span>
                    </a>
                </li>  
            </ul>
     <ul class="treeview-menu" style="list-style-type:square">
                <li class="active">
                    <a href="<?php echo site_url('Star/index');?>">
                        <i></i>  <span class="pull-down-container">Starred Cases</span>
                    </a>
                </li>  
            </ul>
            <ul class="treeview-menu" style="list-style-type:square">
                <li class="active">
                    <a href="<?php echo site_url('Archived/index');?>">
                        <i></i>  <span class="pull-down-container">Archived Cases </span>
                    </a>
                </li>  
            </ul>
            <ul class="treeview-menu" style="list-style-type:square">
                <li class="active">
                    <a href="<?php echo site_url('Document/index');?>">
                        <i></i>  <span class="pull-down-container">Documents </span>
                    </a>
                </li>  
            </ul>
           </li>
                         <li >
                            <a href="<?php echo site_url('Study/index');?>">
                                <i class="fa fa-book"></i> 
                                 <span class="pull-down-container">Case Study </span>
                            </a>
                             
                        </li>
                       <li>
                            <a href="">
                                <i class="fa fa-tasks"></i> 
                                 <span class="pull-down-container">Task</span>
                                 <i class="fa fa-angle-down pull-down"></i>
                            </a>
                             <ul class="treeview-menu">
                
                               <li class="active">
                                   <a href="<?php echo site_url('Task/index');?>">
                                    <i></i>  <span class="pull-down-container">Task</span>
                                </a>
                                </li>

                            </ul>
                            <ul class="treeview-menu">
                <li class="active">
                    <a href="<?php echo site_url('Mytask/index');?>">
                        <i></i>  <span class="pull-down-container">My task</span>
                    </a>
                </li>  
            </ul>
            
                        </li>
<li>
                            <a href="<?php echo site_url('Reports/index');?>">
                                <i class="fa fa-line-chart"></i> 
                                 <span class="pull-down-container">Reports</span>
                            </a>
                             
                        </li>
                        <li>
                            <a href="<?php echo site_url('Message/index');?>">
                                <i class="fa fa-envelope"></i> 
                                 <span class="pull-down-container">Message</span>
                            </a>
                             
                        </li>
                        <li class="active">
                            <a href="<?php echo site_url('Todolist/index');?>">
                                <i class="fa fa-list"></i> 
                                 <span class="pull-down-container"> To Do List</span>
                            </a>
                             
                        </li>
                        <li>
                            <a href="<?php echo site_url('Contact/index');?>">
                                <i class="fa fa-phone"></i> 
                                 <span class="pull-down-container">Contact</span>
                            </a>
                             
                        </li>           
                        <li>
                            <a href="<?php echo site_url('Customfield/index');?>">
                                <i class="fa fa-columns"></i> 
                                 <span class="pull-down-container">Custom Fields</span>
                            </a>
                             
            
                        </li>
                        <li>
                            <a href="<?php echo site_url('Appointment/index');?>">
                                <i class="fa fa-thumb-tack"></i> 
                                 <span class="pull-down-container">Appointment</span>
                            </a>
            
                        </li>
                        <li>
                            <a href="">
                                <i class="fa fa-folder"></i> 
                                 <span class="pull-down-container">Master</span>
                                  <i class="fa fa-angle-down pull-down"></i>
                            </a>
                             <ul class="treeview-menu">
                
                               <li class="active">
                                   <a href="<?php echo site_url('Location/index');?>">
                                    <i></i>  <span class="pull-down-container">Location</span>
                                </a>
                                </li>

                            </ul>
                            <ul class="treeview-menu">
                <li class="active">
                    <a href="<?php echo site_url('Tax/index');?>">
                        <i></i>  <span class="pull-down-container">Tax</span>
                    </a>
                </li>  
            </ul>
             <ul class="treeview-menu">
                <li class="active">
                    <a href="<?php echo site_url('Casecategory/index');?>">
                        <i></i>  <span class="pull-down-container">Case Category</span>
                    </a>
                </li>  
            </ul>
            <ul class="treeview-menu">
                <li class="active">
                    <a href="<?php echo site_url('Courtcategory/index');?>">
                        <i></i>  <span class="pull-down-container">Court Category</span>
                    </a>
                </li>  
            </ul>
             <ul class="treeview-menu">
                <li class="active">
                    <a href="<?php echo site_url('Act/index');?>">
                        <i></i>  <span class="pull-down-container">Act</span>
                    </a>
                </li>  
            </ul>
             <ul class="treeview-menu">
                <li class="active">
                    <a href="<?php echo site_url('Court/index');?>">
                        <i></i>  <span class="pull-down-container">Court</span>
                    </a>
                </li>  
            </ul>
             <ul class="treeview-menu">
                <li class="active">
                    <a href="<?php echo site_url('Casestage/index');?>">
                        <i></i>  <span class="pull-down-container">Case Stages</span>
                    </a>
                </li>  
            </ul>
             <ul class="treeview-menu">
                <li class="active">
                    <a href="<?php echo site_url('Payment/index');?>">
                        <i></i>  <span class="pull-down-container">Payment Mode</span>
                    </a>
                </li>  
            </ul>
                        </li>
                        <li>
                            <a href="">
                                <i class="fa fa-gear"></i> 
                                 <span class="pull-down-container">Administrative</span>
                                  <i class="fa fa-angle-down pull-down"></i>
                            </a>
                             <ul class="treeview-menu">
                
                               <li class="active">
                                   <a href="<?php echo site_url('Generalsetting/index');?>">
                                    <i></i>  <span class="pull-down-container">General Setting</span>
                                </a>
                                </li>

                            </ul>
                            <ul class="treeview-menu">
                <li class="active">
                    <a href="<?php echo site_url('Notification/index');?>">
                        <i></i>  <span class="pull-down-container">Notification Setting</span>
                    </a>
                </li>  
            </ul>
             <ul class="treeview-menu">
                <li class="active">
                    <a href="<?php echo site_url('Language/index');?>">
                        <i></i>  <span class="pull-down-container">Language Setting</span>
                    </a>
                </li>  
            </ul>
                        </li>
                    </ul>
                </section>
                <!-- /.sidebar -->
            </aside>


            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Main content -->
                <section class="content">
                    <?php                    
                    if(isset($_view) && $_view)
                        $this->load->view($_view);
                    ?>                    
                </section>
                <!-- /.content -->
            </div>
            <!-- /.content-wrapper -->
            <footer class="main-footer">
               <!-- <strong>Generated By <a href="http://www.crudigniter.com/">CRUDigniter</a> 3.2</strong>-->
            </footer>

            <!-- Control Sidebar -->
            <aside class="control-sidebar control-sidebar-dark">
                <!-- Create the tabs -->
                <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
                    
                </ul>
                <!-- Tab panes -->
                <div class="tab-content">
                    <!-- Home tab content -->
                    <div class="tab-pane" id="control-sidebar-home-tab">

                    </div>
                    <!-- /.tab-pane -->
                    <!-- Stats tab content -->
                    <div class="tab-pane" id="control-sidebar-stats-tab">Stats Tab Content</div>
                    <!-- /.tab-pane -->
                    
                </div>
            </aside>
            <!-- /.control-sidebar -->
            <!-- Add the sidebar's background. This div must be placed
            immediately after the control sidebar -->
            <div class="control-sidebar-bg"></div>
        </div>
        <!-- ./wrapper -->

        <!-- jQuery 2.2.3 -->
       <!-- <script src="<?php echo site_url('resources/js/jquery-2.2.3.min.js');?>"></script>-->
        <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
  
        <!-- Bootstrap 3.3.6 -->
        <script src="<?php echo site_url('resources/js/bootstrap.min.js');?>"></script>
        <!-- FastClick -->
        <script src="<?php echo site_url('resources/js/fastclick.js');?>"></script>
        <!-- AdminLTE App -->
        <script src="<?php echo site_url('resources/js/app.min.js');?>"></script>
        <!-- AdminLTE for demo purposes -->
        <script src="<?php echo site_url('resources/js/demo.js');?>"></script>
        <!-- DatePicker -->
        <script src="<?php echo site_url('resources/js/moment.js');?>"></script>
        <script src="<?php echo site_url('resources/js/bootstrap-datetimepicker.min.js');?>"></script>
        <script src="<?php echo site_url('resources/js/global.js');?>"></script>




 <link rel="stylesheet" type="text/css" href="<?php echo site_url('resources/dataTables.bootstrap4.min.css');?>">



 <script src="<?php echo site_url('resources/jquery.dataTables.min.js');?>"></script>
  <script src="<?php echo site_url('resources/dataTables.bootstrap4.min.js');?>"></script>




    </body>

</html>


 