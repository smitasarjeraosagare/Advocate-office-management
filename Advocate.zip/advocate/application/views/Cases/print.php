<section class="content">
  
 <!-- Main content -->
                <section class="content invoice">
                    <!-- title row -->
                    <div class="row">
                        <div class="col-xs-12"><h1>Advocate Management System</h1>
              <div class="col-sm-3 ">
                                           <!--  <img src="http://advocate.webappsdemo.in/assets/uploads/images/Screenshot_2019-12-09_at_15.40_.14_.png"  height="70" width="150" /> -->
                                           
                
              </div>
              <div class="col-sm-4 invoice-col">  
                <h2 class="page-header">
                               
                </h2>
                
              </div>
              <div class="col-sm-4 invoice-col">
                <small class="pull-right"> <?php echo ($this->input->post('date') ? $this->input->post('date') : $cases['date']); ?></small>
              </div>
                        </div><!-- /.col -->
                    </div>
                    <!-- info row -->
                    <div class="row invoice-info">
                        <div class="col-sm-4 invoice-col">
                            From                            <address>
                                <strong>Advocate Management System</strong><br>
                              
                                Phone: 000000000<br/>
                                Email: Admin@admin.com                           </address>
                        </div><!-- /.col -->
                        <div class="col-sm-4 invoice-col">
                            To  <?php echo ($this->input->post('name') ? $this->input->post('name') : $client['name']); ?>                            <address>
                                <strong></strong><br>
                                <br>
                                Phone: <br/>
                                Email:                             </address>
                        </div><!-- /.col -->
                        <div class="col-sm-4 invoice-col">
                            <b>Invoice <?php echo ($this->input->post('c_id') ? $this->input->post('c_id') : $cases['c_id']); ?></b><br/>
                            <b>Case No:</b> <?php echo ($this->input->post('cno') ? $this->input->post('cno') : $cases['cno']); ?><br/>
                           <!--  <b>Payment Mode: --> <!-- <?php echo ($this->input->post('pay') ? $this->input->post('pay') : $cases['pay']); ?> --></b> <br/>
                            
                        </div><!-- /.col -->
                    </div><!-- /.row -->

                    <!-- Table row -->
                    <div class="row">
                        <div class="col-xs-12 table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                       
                                        <th>Details</th>
                     <th align="right">Amount </th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Payment</td>
                                        <td align="right"> <?php echo ($this->input->post('tfees') ? $this->input->post('tfees') : $cases['tfees']); ?></td>
                                        
                                    </tr>
                                                                              <tr>
                      <td> <span class="pull-right">  %</span> </td>
                      <td align="right">  0.00</td>
                      
                    </tr>
                  
                                           
                                           <tr>
                                        <td>Total</td>
                                        <td align="right"> <?php echo ($this->input->post('total') ? $this->input->post('total') : $cases['total']); ?></td>
                                        
                                    </tr>
                                </tbody>
                            </table>
                        </div><!-- /.col -->
                    </div><!-- /.row -->

                      
        
                    <!-- this row will not appear when printing -->
                    <div class="row no-print">
                        <div class="col-xs-12">
                            <button class="btn btn-default" onClick="window.print();"><i class="fa fa-print"></i> Print</button>
                            <a class="downloadable"><button> Download</button></a>
                           
                      <!-- 
                                                      <a href=""class="btn btn-primary pull-right" style="margin-right: 5px;"><i class="fa fa-download"></i> Generate Pdf</a> -->
                                            <a href="https://mail.google.com/mail/"class="btn btn-primary pull-right" style="margin-right: 5px;"><i class="fa fa-mail-forward"></i> Mail To Client</a>
                                           <script type="text/javascript">
 $(function(){
  $('.downloadable').click(function(){

     window.location.href = "<?php echo site_url('Fees/file_download') ?>?file_name="+ $(this).attr('href');
  });
});
</script>
                                        </div>
                    </div>
          
          
          
          
                </section><!-- /.content -->
<script src="http://advocate.webappsdemo.in/assets/plugins/chosen/chosen.jquery.min.js" type="text/javascript"></script>
<script src="http://advocate.webappsdemo.in/assets/js/bootstrap-datepicker.js" type="text/javascript"></script>


<script src="http://advocate.webappsdemo.in/assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
<script type="text/javascript">
$(function() {
  
  $('.chzn').chosen();
  
});

$(function() {
  //bootstrap WYSIHTML5 - text editor
  $(".txtarea").wysihtml5();
});

 $(function() {
    $( ".datepicker" ).pickmeup({
    format  : 'Y-m-d'
});
  });
</script>  </div>    
           
        </div>
        <!-- ./wrapper -->
        <!-- jQuery UI 1.10.3 -->
       
     <script src="http://advocate.webappsdemo.in/assets/js/jquery.pickmeup.min.js" type="text/javascript"></script>
        
        
        <!-- SlimScroll -->
        <script src="http://advocate.webappsdemo.in/assets/plugins/slimScroll/jquery.slimscroll.min.js"></script>
        <!-- FastClick -->
        <script src="http://advocate.webappsdemo.in/assets/plugins/fastclick/fastclick.js"></script>
        
        <!-- iCheck -->
        <script src="http://advocate.webappsdemo.in/assets/plugins/iCheck/icheck.min.js" type="text/javascript"></script>
        
        <!-- AdminLTE App -->
        <script src="http://advocate.webappsdemo.in/assets/js/app.js" type="text/javascript"></script>
        
         <!-- odr -->
        <link rel="stylesheet" href="http://advocate.webappsdemo.in/odr/style.css" type="text/css" />
        <script type="text/javascript" src="http://advocate.webappsdemo.in/odr/odr.js.php"></script>
        <!-- /odr -->