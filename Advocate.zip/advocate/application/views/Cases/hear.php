<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
  <script>tinymce.init({ selector:'textarea' });</script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#reg_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#permit_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
<script type="text/javascript">
  $(document).ready(function() {
  $('#puc_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
</script>
 <script type="text/javascript">
  $(document).ready(function() {
  $('#fitness_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#insu_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#tax_rcp_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#mfg_date').datetimepicker({
    format: 'MM-YYYY',
 }); 
});
 </script>
 <div class="row">
    <div class="col-md-12">
        <div class="box box-info" style="border-top-color: #605ca8">
            <div class="box-header with-border">
                <h3 class="box-title">Hearing</h3>
            </div>
<!--             <?php echo form_open('Hear/add'); ?>

 -->           
<?php echo form_open_multipart('Cases/hear/'.$cases['c_id']); ?>
<!-- <?php echo form_open('Archived/add/'.$cases['c_id']); ?> -->
  <div class="box-body">
              <div class="row clearfix">
           <div class="col-md-6">
            <label for="ctitle" class="control-label"> Case Title
            <span class="text-danger">*</span></label>
            <div class="form-group">
              <input type="text" name="ctitle" value="<?php echo ($this->input->post('ctitle') ? $this->input->post('ctitle') : $cases['ctitle']); ?>" class="form-control" id="ctitle" />
              <span class="text-danger"><?php echo form_error('ctitle');?></span>
            </div>
          </div>
         
<div class="row clearfix">
  <div class="col-md-6">
    <label for="attach" class="control-label">Attachment<span class="text-danger">*</span></label>
                            
      <div class="form-group">
        <input type="file" name="attach" value="<?php echo $this->input->post('attach'); ?>" class="form-control" id="attach" />
          <span class="text-danger"><?php echo form_error('attach');?></span>
       </div>
  </div>
</div>

<div class="row clearfix">
  <div class="col-md-6">
    <label for="ndate" class="control-label">Next Date<span class="text-danger">*</span></label>
      <div class="form-group">
        <input type="date" name="ndate" value="<?php echo $this->input->post('ndate'); ?>" class="form-control" id="ndate" />
          <span class="text-danger"><?php echo form_error('ndate');?></span>
      </div>
  </div> 
</div> 

<div class="row clearfix">
  <div class="col-md-6">
      <label for="ldate" class="control-label">Last Date<span class="text-danger">*</span></label>
    <div class="form-group">
      <input type="date" name="ldate" value="<?php echo $this->input->post('ldate'); ?>" class="form-control" id="ldate" />
       <span class="text-danger"><?php echo form_error('ldate');?></span>
    </div>
  </div>
</div>

                      <div class="row clearfix">
                        <div class="col-md-6">
                            <label for="hnote" class="control-label">
                            Note<span class="text-danger">*</span></label>
                            <div class="form-group">
                              <textarea name="hnote" value="<?php echo $this->input->post('hnote'); ?>" class="form-control" id="hnote"></textarea>
                              <span class="text-danger"><?php echo form_error('hnote');?></span>
                            </div>
                        </div>
                        </div>   
      </div>
            <div class="box-footer">
              <button type="submit" class="btn btn-success">
                <i class="fa fa-check"></i> Save
              </button>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>
 
        <div class="box box-info" style="border-top-color: #605ca8">

            <table id="tb" class="table css-serial   table-bordered" cellspacing="0" width="100%">
        <thead>

                    <tr>
                        <!-- <th>Sr. No</th> -->
                        <th>Case</th>
                        <th>Hearing Date no</th>
                        <th>Next Date</th>
                        <th> Closing Date </th>
                        
                        
                    </tr>
                </thead>
                  
                    <tr>
                        


 
                        <td><?php echo ($this->input->post('ctitle') ? $this->input->post('ctitle') : $cases['ctitle']); ?></td>

                        <td><?php echo ($this->input->post('hdate') ? $this->input->post('hdate') : $cases['hdate']); ?></td>

                        <td><?php echo ($this->input->post('ndate') ? $this->input->post('ndate') : $cases['ndate']); ?></td>
                        <td><?php echo ($this->input->post('cdate') ? $this->input->post('cdate') : $cases['cdate']); ?></td>

                        
                       
                    </tr>
                   
                </table>
                            
            </div>
        </div>
    </div>
</div>

 
  <script>
  $(function(){
    $("#tb").dataTable();
  })
  </script>

</html>