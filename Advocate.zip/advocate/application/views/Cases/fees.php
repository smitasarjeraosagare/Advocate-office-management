<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

 <section class="content">
    <div class="row">
  
      
        <!-- left column -->
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
                   
                </div><!-- /.box-header -->
        
        <div class="box-body">

<div class="row">
    <div class="col-md-12">
        <div class="box box-info" style="border-top-color: #605ca8">
            <div class="box-header with-border">
                <h3 class="box-title">Payment</h3>
            </div>
             <?php echo form_open('Cases/fees/'.$cases['c_id']); ?>
   
          <div class="col-md-12">
            <h4> <b>Case Title:</b><?php echo ($this->input->post('ctitle') ? $this->input->post('ctitle') : $cases['ctitle']); ?></h4>
          

           <h4><b>Case No.:</b><?php echo ($this->input->post('cno') ? $this->input->post('cno') : $cases['cno']); ?></h4>
          
          <h4> <b>Cases Name:</b><?php echo ($this->input->post('name') ? $this->input->post('name') : $cases['name']); ?></h4></div>
<!--            <h4> <b>Invoice no:</b><?php echo ($this->input->post('f_id') ? $this->input->post('f_id') : $fees['f_id']); ?></h4></div>
 -->           

           <div class="col-md-6">
                        <label for="pay" class="control-label">Payment Mode
                            <span class="text-danger">*</span></label>

   <div class="form-group">
                                   <select   name="pay" id="p_id" class="form-control">
                                         <option value="">Select </option>
                                              <?php
                                                  foreach($all_payment as $payment)
                                                  {

                                                  $selected = ($payment['pay'] == $this->input->post('pay')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$payment['p_id'].'" '.$selected.'>'.$payment['pay'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
                               <span class="text-danger"><?php echo form_error('pay');?></span>
                             </div>
                           </div>
                            <div>
                            <div class="col-md-6">
            <label for="date" class="control-label">
            Date
              <span class="text-danger">*</span></label>
            <div class="form-group">
              <input type="date" f_id="date" value="<?php echo $this->input->post('date'); ?>" class="form-control" id="date" />
              <span class="text-danger"><?php echo form_error('date');?></span>
            </div>
          </div>
         
                            <div class="col-md-6">
                        <label for="tax_id" class="control-label">Tax
                            <span class="text-danger">*</span></label>

   <div class="form-group">
                                   <select   name="tax_name" id="tax_id" class="form-control">
                                         <option value="">Select </option>
                                              <?php
                                                  foreach($all_tax as $tax)
                                                  {

                                                  $selected = ($tax['tax_name'] == $this->input->post('tax_name')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$tax['tax_id'].'" '.$selected.'>'.$tax['tax_name'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
                               <span class="text-danger"><?php echo form_error('tax_name');?></span>
                             </div>
                           </div>

                            <!-- <div class="col-md-6">
                        <label for="tax_id" class="control-label">Tax
                            <span class="text-danger">*</span></label>

   <div class="form-group">
                                   <select   name="tax" id="tax_id" class="form-control">
                                         <option value="">Select </option>
                                              <?php
                                                  foreach($all_taxm as $tax)
                                                  {

                                                  $selected = ($tax['tax'] == $this->input->post('tax')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$tax['tax_id'].'" '.$selected.'>'.$tax['tax'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
                               <span class="text-danger"><?php echo form_error('tax');?></span>
                             </div>
                           </div> -->
                           <div class="row clearfix">
 <div class="col-md-6">
            <label for="tfees" class="control-label">Amount
            <span class="text-danger">*</span></label>
            <div class="form-group">
              <input type="text" disabled="true" name="tfees" value="<?php echo ($this->input->post('tfees') ? $this->input->post('tfees') : $cases['tfees']); ?>" class="form-control" id="tfees" />
              <span class="text-danger"><?php echo form_error('tfees');?></span>
            </div>
          </div>
          
  <div class="col-md-6">
    <label for="total" class="control-label">Total<span class="text-danger">*</span></label>
                            
      <div class="form-group">
        <input type="number" name="total" value="<?php echo $this->input->post('total'); ?>" class="form-control" id="total" />
          <span class="text-danger"><?php echo form_error('total');?></span>
       </div>
  </div>
</div>
<div>
          
</div>
         </div>     
         <div class="box-footer">
              <button type="submit" class="btn btn-success">
                <i class="fa fa-check"></i> Save
              </button>
            </div>
            <?php echo form_close(); ?>
        </div>            
      </div>
            
    </div>
</div></div>
 