

 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
  <script>tinymce.init({ selector:'textarea' });</script>
 
<script type="text/javascript">
  $(document).ready(function() {
  $('#cno').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#fdate').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
<script type="text/javascript">
  $(document).ready(function() {
  $('#hdate').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
 <script type="text/javascript">
  $(document).ready(function() {
  $('#fitness_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#insu_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#tax_rcp_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#mfg_date').datetimepicker({
    format: 'MM-YYYY',
 }); 
});
 </script>

<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title"> Edit cases</h3>
            </div>
			<?php echo form_open('Cases/edit/'.$cases['c_id']); ?>
			<div class="box-body">
				<div class="row clearfix">

					<div class="col-md-6">
						<label for="ctitle" class="control-label"> Case Title
						<span class="text-danger">*</span></label>
						<div class="form-group">
							<input type="text" name="ctitle" value="<?php echo ($this->input->post('ctitle') ? $this->input->post('ctitle') : $cases['ctitle']); ?>" class="form-control" id="ctitle" />
							<span class="text-danger"><?php echo form_error('ctitle');?></span>
						</div>
					</div>
					


					<div class="col-md-6">
						<label for="cno" class="control-label"> Case No
						<span class="text-danger">*</span></label>
						<div class="form-group">
							<input type="text" name="cno" value="<?php echo ($this->input->post('cno') ? $this->input->post('cno') : $cases['cno']); ?>" class="form-control" id="cno" />
							<span class="text-danger"><?php echo form_error('cno');?></span>
						</div>
					</div>

					 <div class="col-md-6"> 
                        <label for="cl_id" class="control-label"> Name
                            <span class="text-danger">*</span></label>

                   <div class="form-group">
                                   <select   name="name" id="cl_id" class="form-control">
                                         <option value="">Select Client</option>
                                              <?php
                                                   foreach($all_clients as $client)
                                                  {

                                                  $selected = ($client['name'] == $this->input->post('name')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$client['cl_id'].'" '.$selected.'>'.$client['name'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
                               <span class="text-danger"><?php echo form_error('name');?></span>
                             </div>
                           </div>

					<div class="col-md-6">
           <label for="l_id" class="control-label"> Location
                            <span class="text-danger">*</span></label>

                        <div class="form-group">
                                   <select   name="lname" id="l_id" class="form-control">
                                         <option value="">Select Location</option>
                                              <?php
                                                   foreach($all_location as $location)
                                                  {

                                                  $selected = ($location['lname'] == $this->input->post('lname')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$location['l_id'].'" '.$selected.'>'.$location['lname'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
                               <span class="text-danger"><?php echo form_error('lname');?></span>
                             </div>
                           </div>
           
        
					 <div class="col-md-6">
                        <label for="courtname" class="control-label"> Court Category
                            <span class="text-danger">*</span></label>

                               <div class="form-group">
                                   <select   name="courtname" id="coucat_id" class="form-control">
                                         <option value="">Select case</option>
                                              <?php
                                                  foreach($all_courtcat as $courtcat)
                                                  {

                                                  $selected = ($courtcat['courtname'] == $this->input->post('courtname')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$courtcat['coucat_id'].'" '.$selected.'>'.$courtcat['courtname'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
                               <span class="text-danger"><?php echo form_error('courtname');?></span>
                             </div>
                           </div>
           
              <div class="col-md-6">
                        <label for="court_id" class="control-label"> Court
                            <span class="text-danger">*</span></label>

   <div class="form-group">
                                   <select   name="court" id="court_id" class="form-control">
                                         <option value="">Select case</option>
                                              <?php
                                                  foreach($all_court as $court)
                                                  {

                                                  $selected = ($court['court'] == $this->input->post('court')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$court['court_id'].'" '.$selected.'>'.$court['court'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
                               <span class="text-danger"><?php echo form_error('court');?></span>
                             </div>
                           </div>

                      <div class="col-md-6">
                        <label for="cs_id" class="control-label"> Case Stage
                            <span class="text-danger">*</span></label>

   <div class="form-group">
                                   <select   name="stage" id="cs_id" class="form-control">
                                         <option value="">Select case</option>
                                              <?php
                                                  foreach($all_casestage as $casestage)
                                                  {

                                                  $selected = ($casestage['stage'] == $this->input->post('stage')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$casestage['cs_id'].'" '.$selected.'>'.$casestage['stage'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
                               <span class="text-danger"><?php echo form_error('stage');?></span>
                             </div>
                           </div>
                       <div class="col-md-6">
                        <label for="act_id" class="control-label"> Act
                            <span class="text-danger">*</span></label>

   <div class="form-group">
                                   <select   name="act_name" id="act_id" class="form-control">
                                         <option value="">Select case</option>
                                              <?php
                                                  foreach($all_act as $act)
                                                  {

                                                  $selected = ($act['act_name'] == $this->input->post('act_name')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$act['act_id'].'" '.$selected.'>'.$act['act_name'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
                               <span class="text-danger"><?php echo form_error('act_name');?></span>
                             </div>
                           </div>
                        <br>

                       <div class="col-md-6" >
            <label for="des" class="control-label">Description 
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="textarea" rows="30" name="des" value="<?php echo $this->input->post('des'); ?>" class="form-control" id="des" />
              <span class="text-danger"><?php echo form_error('des');?></span>
            </div>
          </div>
					<div class="col-md-6">
				     	<label for="fdate" class="control-label"> Filling  Date
					     	<span class="text-danger">*</span></label>
						<div class="form-group">
					      	<input type="text" name="fdate" value="<?php echo ($this->input->post('fdate') ? date('d-m-Y', strtotime($this->input->post('fdate'))) : date('d-m-Y', strtotime($cases['fdate']))); ?>" class="has-datetimepicker form-control" id="fdate" />
                              <span class="text-danger"><?php echo form_error('fdate');?></span>
						</div>
					</div>

					<div class="col-md-6">
				     	<label for="hdate" class="control-label"> Hearing Date
					     	<span class="text-danger">*</span></label>
						<div class="form-group">
					      	<input type="text" name="hdate" value="<?php echo ($this->input->post('hdate') ? date('d-m-Y', strtotime($this->input->post('hdate'))) : date('d-m-Y', strtotime($cases['hdate']))); ?>" class="has-datetimepicker form-control" id="hdate" />
                              <span class="text-danger"><?php echo form_error('hdate');?></span>
						</div>
					</div>
					

					<div class="col-md-6">
						<label for="opp" class="control-label">Opposite To
						<span class="text-danger">*</span></label>
						<div class="form-group">
							<input type="text" name="opp" value="<?php echo ($this->input->post('opp') ? $this->input->post('opp') : $cases['opp']); ?>" class="form-control" id="opp" />
							<span class="text-danger"><?php echo form_error('opp');?></span>
						</div>
					</div>

					<div class="col-md-6">
						<label for="tfees" class="control-label">Total Fees
						<span class="text-danger">*</span></label>
						<div class="form-group">
							<input type="text" name="tfees" value="<?php echo ($this->input->post('tfees') ? $this->input->post('tfees') : $cases['tfees']); ?>" class="form-control" id="tfees" />
							<span class="text-danger"><?php echo form_error('tfees');?></span>
						</div>
					</div>

					<div class="col-md-6">
                        <label for="e_id" class="control-label"> Assign to
                            <span class="text-danger">*</span></label>

   <div class="form-group">
                                   <select   name="ename" id="e_id" class="form-control">
                                         <option value="">Select Employee</option>
                                              <?php
                                                   foreach($all_employees as $employee)
                                                  {

                                                  $selected = ($employee['ename'] == $this->input->post('ename')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$employee['e_id'].'" '.$selected.'>'.$employee['ename'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
                               <span class="text-danger"><?php echo form_error('ename');?></span>
                             </div>
                           </div>
					
				
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Update
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>
</div>
</div>