

 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

 
<script type="text/javascript">
  $(document).ready(function() {
  $('#cno').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#fdate').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
<script type="text/javascript">
  $(document).ready(function() {
  $('#cdate').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
 <script type="text/javascript">
  $(document).ready(function() {
  $('#fitness_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#insu_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#tax_rcp_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#cdate').datetimepicker({
    format: 'MM-YYYY',
 }); 
});
 </script>

<div class="row">
    <div class="col-md-12">
        <div class="box box-info">
            <div class="box-header with-border">
                <h3 class="box-title">Archive</h3>
            </div>
      <?php echo form_open('Archived/add/'.$cases['c_id']); ?>
      <div class="box-body">
        <div class="row clearfix">

          <div class="col-md-6">
            <label for="ctitle" class="control-label"> Case Title
            <span class="text-danger">*</span></label>
            <div class="form-group">
              <input type="text" disabled="true" name="ctitle" value="<?php echo ($this->input->post('ctitle') ? $this->input->post('ctitle') : $cases['ctitle']); ?>" class="form-control" id="ctitle" />
              <span class="text-danger"><?php echo form_error('ctitle');?></span>
            </div>
          </div>
          


          <div class="col-md-6">
              <label for="cno" class="control-label">  Case No
                <span class="text-danger">*</span></label>
            <div class="form-group">
                  <input type="text" disabled="true" name="cno" value="<?php echo ($this->input->post('cno') ? date('d-m-Y', strtotime($this->input->post('cno'))) : date('d-m-Y', strtotime($cases['cno']))); ?>" class="has-datetimepicker form-control" id="cno" />
                              <span class="text-danger"><?php echo form_error('cno');?></span>
            </div>
          </div>

          <div class="col-md-6">
            <label for="cname" class="control-label">Cases Name
            <span class="text-danger">*</span></label>
            <div class="form-group">
              <input type="text" disabled="true" name="cname" value="<?php echo ($this->input->post('cname') ? $this->input->post('cname') : $cases['cname']); ?>" class="form-control" id="cname" />
              <span class="text-danger"><?php echo form_error('cname');?></span>
            </div>
          </div>
          <div class="col-md-6">
            <label for="note" class="control-label">Note
            <span class="text-danger">*</span></label>
            <div class="form-group">
              <input type="text" name="note" value="<?php echo ($this->input->post('note') ? $this->input->post('note') : $cases['note']); ?>" class="form-control" id="note" />
              <span class="text-danger"><?php echo form_error('note');?></span>
            </div>
          </div>
         <div class="col-md-6">
              <label for="cdate" class="control-label"> Closing Date
                <span class="text-danger">*</span></label>
            <div class="form-group">
                  <input type="text" name="cdate" value="<?php echo ($this->input->post('cdate') ? date('MM-YYYY', strtotime($this->input->post('cdate'))) : $cases['cdate']); ?>" class="has-datetimepicker form-control" id="cdate" />
                              <span class="text-danger"><?php echo form_error('cdate');?></span>
            </div>
          </div>


 <!-- <div class="col-md-6">
            <label for="cdate" class="control-label">Closing Date
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="date" name="cdate" value="<?php echo $this->input->post('cdate'); ?>" class="form-control" id="cdate" />
              <span class="text-danger"><?php echo form_error('cdate');?></span>
            </div>
          </div> -->
         
          
        
        </div>
      </div>
      <div class="box-footer">
              <button type="submit" class="btn btn-success">
          <i class="fa fa-check"></i> Archive
        </button>
          </div>        
      <?php echo form_close(); ?>
    </div>
    </div>
</div>
</div>
</div>