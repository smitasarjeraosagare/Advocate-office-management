<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#reg_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#permit_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
<script type="text/javascript">
  $(document).ready(function() {
  $('#puc_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
</script>
 <script type="text/javascript">
  $(document).ready(function() {
  $('#fitness_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#insu_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#tax_rcp_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#mfg_date').datetimepicker({
    format: 'MM-YYYY',
 }); 
});
 </script>
 <div class="row">
    <div class="col-md-12">
        <div class="box box-info" style="border-top-color: #605ca8">
            <div class="box-header with-border">
                <h3 class="box-title">Add</h3>
            </div>
            <?php echo form_open('Holiday/add'); ?>
            <div class="box-body">
              <div class="row clearfix">

  
  <div class="col-md-6">
            <label for="name" class="control-label">
          Name 
            <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="text" name="name" value="<?php echo $this->input->post('name'); ?>" class="form-control" id="name" />
              <span class="text-danger"><?php echo form_error('name');?></span>
            </div>
          </div>
 <div class="col-md-6">
            <label for="date" class="control-label">
          Date
            <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="text" name="date" value="<?php echo $this->input->post('date'); ?>" class="form-control" id="date" />
              <span class="text-danger"><?php echo form_error('date');?></span>
            </div>
          </div>
                
            <div class="col-md-6">
                        <label for="month" class="control-label"> Months
                            <span class="text-danger">*</span></label>

   <div class="form-group">
                                   <select   name="month" id="month" class="form-control">
                                      <option value="0">Select</option>
    <option value="1">January</option>
    <option value="2">Febuary</option>
    <option value="3">March</option>
    <option value="4">April</option>
     <option value="5">May</option>
    <option value="6">June</option>
    <option value="7">July</option>
    <option value="8">August</option>
     <option value="9">September</option>
    <option value="10">October</option>
    <option value="11">November</option>
    <option value="12">December</option>
                                  </select>
                               <span class="text-danger"><?php echo form_error('month');?></span>
                             </div>
                           </div>

                  <div class="col-md-6">
            <label for="year" class="control-label">
          Year
            <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="year" name="year" value="<?php echo $this->input->post('year'); ?>" class="form-control" id="year" />
              <span class="text-danger"><?php echo form_error('year');?></span>
            </div>
          </div>


            <div class="box-footer">
              <button type="submit" class="btn btn-success">
                <i class="fa fa-check"></i> Save
              </button>
            </div></div></div>
</div></div></div></div></div></div>