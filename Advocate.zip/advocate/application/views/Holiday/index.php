<style>
.css-serial {
  counter-reset: serial-number;  /* Set the serial number counter to 0 */
}

.css-serial td:first-child:before {
  counter-increment: serial-number;  /* Increment the serial number counter */
  content: counter(serial-number);  /* Display the counter */
}
</style>
 <style>
         .star {
         background-color: transparent;
         background-image: url('http://localhost/technicalkeeda/images/star-off.png');
         background-repeat:no-repeat;
         display: block;  
         height:16px;
         width:16px;
         float:left;
         } 
         .favorited {
         text-indent: -5000px;
         background-color: transparent;
         background-image: url('http://localhost/technicalkeeda/images/star-on.png');
         background-repeat:no-repeat;   
         height:16px;
         width:16px;
         float:left;
         }
      </style>
      <script type="text/javascript">
        $(".fa-star, .fa-star-o, .glyphicon-star, .glyphicon-star-empty").click(function(e) {
                    e.preventDefault();
                    //detect type
                    var glyph = $(this).hasClass("glyphicon");
                    var fa = $(this).hasClass("fa");

                    //Switch states
                    if (glyph) {
                        $(this).toggleClass("glyphicon-star");
                        $(this).toggleClass("glyphicon-star-empty");
                    }

                    if (fa) {
                        $(this).toggleClass("fa-star");
                        $(this).toggleClass("fa-star-o");
                    }
                });
$(".Privat").click(function (e) {
    e.preventDefault();
    //alert($(this).text());
  vch = $(this).text();
  //var ajax_load = '<img style="margin-left:200px;" src="http://advocate.webappsdemo.in/assets/img/ajax-loader.gif"/>';
  //$('#reg_no_result').html(ajax_load);
    
  $.ajax({
    url: 'http://localhost/programs/advocate/Star/index',
    type:'POST',
    data:{id:vch},
    success:function(result){
     }
  });
  
  
});   


$(".Public").click(function (e) {
    e.preventDefault();
    vch = $(this).text();
    
  $.ajax({
    url: 'http://localhost/programs/advocate/Holidays/addStar',
    type:'POST',
    data:{id:vch},
    success:function(result){
      //alert(result);return false;
    //$('#result_vehilces').html(result);
   }
  });
  
  
}); 
        $(document).on('change', '#location_id', function(){
 //alert(12);
  vch = $(this).val();
  var ajax_load = '';
  $('#result').html(ajax_load);
    
  $.ajax({
    url: '',
    type:'POST',
    data:{id:vch},
    success:function(result){
      //alert(result);return false;
    $('#result').html(result);
    $(".chzn").chosen();
    $('#example1').dataTable({});
   }
  });
});

$(document).on('change', '#case_stage_id', function(){
 //alert(12);
  vch = $(this).val();
  var ajax_load = '<img style="margin-left:100px;" src="http://advocate.webappsdemo.in/assets/img/ajax-loader.gif"/>';
  $('#result').html(ajax_load);
    
  $.ajax({
    url: 'http://advocate.webappsdemo.in/admin/holiday/get_case_by_case_stage_id',
    type:'POST',
    data:{id:vch},
    success:function(result){
      //alert(result);return false;
    $('#result').html(result);
    $(".chzn").chosen();
    $('#example1').dataTable({});
   }
  });
});
jQuery('.msgstar').click(function(){
            if(jQuery(this).hasClass('starred'))
                jQuery(this).removeClass('starred');
            else
                jQuery(this).addClass('starred');
});

$(document).on('change', '#date1', function(){
 //alert(12);
  vch = $(this).val();
  var ajax_load = '<img style="margin-left:100px;" src="http://advocate.webappsdemo.in/assets/img/ajax-loader.gif"/>';
  $('#result').html(ajax_load);
  //alert(vch);   
  $.ajax({
    url: 'http://advocate.webappsdemo.in/admin/holiday/get_case_by_case_filing_date',
    type:'POST',
    data:{id:vch},
    success:function(result){
      //alert(result);return false;
    $('#result').html(result);
    $(".chzn").chosen();
    $('#example1').dataTable({});
   }
  });
});

$(document).on('change', '#date2', function(){
 //alert(12);
  vch = $(this).val();
  var ajax_load = '<img style="margin-left:100px;" src="http://advocate.webappsdemo.in/assets/img/ajax-loader.gif"/>';
  $('#result').html(ajax_load);
  //alert(vch);   
  $.ajax({
    url: 'http://advocate.webappsdemo.in/admin/holiday/get_case_by_case_hearing_date',
    type:'POST',
    data:{id:vch},
    success:function(result){
      //alert(result);return false;
    $('#result').html(result);
    $(".chzn").chosen();
    $('#example1').dataTable({});
   }
  });
});
      </script>

<script>
function confirm_delete()
{
    if(confirm("Are you sure you want to delete this record ?"))
    {
        return true;
    }
    else
    {
        return false;
    }
}   
function star()
{
    if(confirm(Add to Star))
    {
        return true;
    }
    else
    {
        return false;
    }
}   
</script>
<script type="text/javascript" language="javascript" src="http://code.jquery.com/jquery-latest.js"></script>
      <script>
        $(document).ready(function(){ 
           $('.star,.favorited').click(function() {
            var id = $(this).parents('div').attr('id');    
            var className = $(this).attr('class');
            var flag  = (className=='star') ? 'Y':'N';
            var $this = $(this);
            $.ajax({
              type: "post",
              url: "http://localhost/technicalkeeda/demo",
              cache: false,    
              data:{'sid': id,'sflag':flag},
              success: function(response){
               if(response=='true'){        
                $this.toggleClass("favorited");
               } 
              },
              error: function(){      
               alert('Error while request..');
              }
              });
            });
         });
      </script>



 
<div class="panel  panel-danger bord"  >
      <div class="panel-heading  red-color">Holidays
                     <a href="<?php echo site_url('Holiday/add'); ?>" style="float: right; padding-bottom: 3px;" class="btn btn-danger btn-sm">Add</a> 
                </div>  
      
             <div class="box-body">

         
        <div class="table-responsive" >  
 <!-- try -->
  <div class="row" style="margin-bottom:10px;">
            <div class="col-xs-12">
                <div class="">
            <!--         <div class="col-xs-2">
            <select   name="ctitle" id="c_id" class="form-control">
                                         <option value="">--Filter By Client--</option>
                                              <?php
                                                  foreach($all_cases as $cases)
                                                  {

                                                  $selected = ($cases['ctitle'] == $this->input->post('ctitle')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$cases['c_id'].'" '.$selected.'>'.$cases['ctitle'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
          </div> -->
           <div class="col-xs-2">
            <select   name="name" id="cl_id" class="form-control">
                                         <option value="">--Filter By Client--</option>
                                              <?php
                                                   foreach($all_clients as $client)
                                                  {

                                                  $selected = ($client['name'] == $this->input->post('name')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$client['cl_id'].'" '.$selected.'>'.$client['name'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
          </div>
          
           <div class="col-xs-2">
             <select   name="court" id="court_id" class="form-control">
                                         <option value="">--Filter By Court--</option>
                                              <?php
                                                  foreach($all_court as $court)
                                                  {

                                                  $selected = ($court['court'] == $this->input->post('court')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$court['court_id'].'" '.$selected.'>'.$court['court'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
          </div>
            
           <div class="col-xs-2">
             <select   name="lname" id="l_id" class="form-control">
                                         <option value="">--Filter By Location--</option>
                                              <?php
                                                   foreach($all_location as $location)
                                                  {

                                                  $selected = ($location['lname'] == $this->input->post('lname')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$location['l_id'].'" '.$selected.'>'.$location['lname'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
          </div>
          
          <div class="col-xs-2">
            <select   name="catname" id="cc_id" class="form-control">
                                         <option value="">--Filter By Category--</option>
                                              <?php
                                                  foreach($all_casecategory as $casecategory)
                                                  {

                                                  $selected = ($casecategory['catname'] == $this->input->post('catname')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$casecategory['cc_id'].'" '.$selected.'>'.$casecategory['catname'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
          </div>
          
          <div class="col-xs-2">
            <input type="text" name="date1" id="date1" class="form-control datepicker" placeholder="Filling Date" />
          </div>
          
          <div class="col-xs-2">
            <input type="text" name="date2" id="date2" class="form-control datepicker" placeholder="Hearing Date" />
          </div>
          
                </div>
            </div>    
        </div>  
 
  
<div class="row">
          <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border m-b-20">
                    <h3 class="box-title"> </h3>                                    
                </div><!-- /.box-header -->
        
          <div class="row">
                    <div class="col-md-12 m-b-20">
            <div class="col-md-3">
               <ul class="sidebar-menu">
                                         <li class="col-md-12 ">
                                    <a href="<?php echo site_url('Holiday/jan'); ?>" target="iframe_a">
                                    <i class="fa fa-calendar"></i> January </a>
                                    <span class="after"></span>
                             </li>
                                        <li class="col-md-12 ">
                                    <a href="<?php echo site_url('Holiday/feb');?>" target="iframe_a" >
                                    <i class="fa fa-calendar"></i> February </a>
                                    <span class="after"></span>
                             </li>
                                        <li class="col-md-12 active">
                                   <a href="<?php echo site_url('Holiday/mar');?>" target="iframe_a">
                                    <i class="fa fa-calendar"></i> March </a>
                                    <span class="after"></span>
                             </li>
                                        <li class="col-md-12 ">
                                    <a href="<?php echo site_url('Holiday/apr');?>" target="iframe_a">
                                    <i class="fa fa-calendar"></i> April </a>
                                    <span class="after"></span>
                             </li>
                                        <li class="col-md-12 ">
                                   <a href="<?php echo site_url('Holiday/may');?>"target="iframe_a">
                                    <i class="fa fa-calendar"></i> May </a>
                                    <span class="after"></span>
                             </li>
                                        <li class="col-md-12 ">
                                  <a href="<?php echo site_url('Holiday/jun');?>" target="iframe_a">
                                    <i class="fa fa-calendar"></i> June </a>
                                    <span class="after"></span>
                             </li>
                                        <li class="col-md-12 ">
                                   <a href="<?php echo site_url('Holiday/jul');?>" target="iframe_a">
                                    <i class="fa fa-calendar"></i> July </a>
                                    <span class="after"></span>
                             </li>
                                        <li class="col-md-12 ">
                           <a href="<?php echo site_url('Holiday/aug');?>" target="iframe_a">
                                    <i class="fa fa-calendar"></i> August </a>
                                    <span class="after"></span>
                             </li>
                                        <li class="col-md-12 ">
                                    <a href="<?php echo site_url('Holiday/sep');?>" target="iframe_a">
                                    <i class="fa fa-calendar"></i> September </a>
                                    <span class="after"></span>
                             </li>
                                        <li class="col-md-12 ">
                                    <a href="<?php echo site_url('Holiday/oct');?>" target="iframe_a">
                                    <i class="fa fa-calendar"></i> October </a>
                                    <span class="after"></span>
                             </li>
                                        <li class="col-md-12 "><a href="<?php echo site_url('Holiday/nov');?>" target="iframe_a">
                                    <i class="fa fa-calendar"></i> November </a>
                                    <span class="after"></span>
                             </li>
                                        <li class="col-md-12 ">
                                   <a href="<?php echo site_url('Holiday/dec');?>" target="iframe_a">
                                    <i class="fa fa-calendar"></i> December </a>
                                    <span class="after"></span>
                             </li>
               
                
              </ul>
            </div>
            <div class="col-md-9">
              <div class="tab-content">
                <!DOCTYPE html>

<iframe height="3000px" width="100%" name="iframe_a"></iframe>
                 
          <!--      <div id="1" class="tab-pane ">
                <div class="box box-black">
             <table id="tb" class="table css-serial   table-bordered" cellspacing="0" width="100%">
        <thead>

                    <tr>
                        <th>Sr. No</th>
                        <th>Title</th>
                        <th>Action</th>

                    </tr>
                </thead>
                    <?php foreach($holiday as $c){ ?>
                    <tr>
                        <td></td>
                        

 
                        <td><?php echo $c['name']; ?></td>
                         <td><?php echo $c['date']; ?></td>

                            <a href="<?php echo site_url('Holiday/remove/'.$c['ho_id']); ?>" class="btn btn-danger btn-xs" onclick="return confirm_delete()"><button class="btn btn-danger btn-xs"><span>Delete</span></button>  </a>
                            
                        </td>
                    </tr>
                    <?php } ?>
                </table> -->
           

       
      