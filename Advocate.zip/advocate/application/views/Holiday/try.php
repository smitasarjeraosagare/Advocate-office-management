 
<style>
.css-serial {
  counter-reset: serial-number;  /* Set the serial number counter to 0 */
}

.css-serial td:first-child:before {
  counter-increment: serial-number;  /* Increment the serial number counter */
  content: counter(serial-number);  /* Display the counter */
}
</style>
 <style>
         .star {
         background-color: transparent;
         background-image: url('http://localhost/technicalkeeda/images/star-off.png');
         background-repeat:no-repeat;
         display: block;  
         height:16px;
         width:16px;
         float:left;
         } 
         .favorited {
         text-indent: -5000px;
         background-color: transparent;
         background-image: url('http://localhost/technicalkeeda/images/star-on.png');
         background-repeat:no-repeat;   
         height:16px;
         width:16px;
         float:left;
         }
      </style>

<script>
function confirm_delete()
{
    if(confirm("Are you sure you want to delete this record ?"))
    {
        return true;
    }
    else
    {
        return false;
    }
}   
function star()
{
    if(confirm(Add to Star))
    {
        return true;
    }
    else
    {
        return false;
    }
}   
</script>
<script type="text/javascript" language="javascript" src="http://code.jquery.com/jquery-latest.js"></script>
      <script>
        $(document).ready(function(){ 
           $('.star,.favorited').click(function() {
            var id = $(this).parents('div').attr('id');    
            var className = $(this).attr('class');
            var flag  = (className=='star') ? 'Y':'N';
            var $this = $(this);
            $.ajax({
              type: "post",
              url: "http://localhost/technicalkeeda/demo",
              cache: false,    
              data:{'sid': id,'sflag':flag},
              success: function(response){
               if(response=='true'){        
                $this.toggleClass("favorited");
               } 
              },
              error: function(){      
               alert('Error while request..');
              }
              });
            });
         });
      </script>



 
            <table id="tb" class="table css-serial   table-bordered" cellspacing="0" width="100%" border="1">
        <thead>

                    <tr>
                        <th>Sr. No</th>
                        <th>Title</th>
                         <th>Date</th>
                          <th>Month</th>
                           <th>Year</th>
                        <th>Action</th>
                    </tr>
                </thead>
                    <?php foreach($holiday as $c){ ?>
                    <tr>
                        <td></td>
                        

 
                        <td><?php echo $c['name']; ?></td>
                         <td><?php echo $c['date']; ?></td>
                         <td><?php echo $c['month']; ?></td>
                         <td><?php echo $c['year']; ?></td>


                      
 
                                            
                        <td>
                            <a href="<?php echo site_url('Holiday/remove/'.$c['ho_id']); ?>" class="btn btn-danger btn-xs" onclick="return confirm_delete()"><button class="btn btn-danger btn-xs"><span>Delete</span></button>  </a>
                            
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                            
            </div>
        </div>
    </div>
</div>

 
  <script>
  $(function(){
    $("#tb").dataTable();
  })
  </script>
