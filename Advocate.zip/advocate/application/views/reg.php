<html>
	
	<head>
		<title>Untitled</title>
	</head>

<body>

	<form name="form1" method="post" action="" enctype="multipart/form-data" />

	upload file <input type="file" name="f" /></br>

	name <input type="text" name="t" id="t" />
</br>
<input type="submit" name="submit" value="submit" />
</form>
</body>

<?php

//$filename = $_POST["t"];


//$link = mysqli_connect("localhost","root","","garment_inventory");


 $link = mysqli_connect("localhost", "gstuser", "gstpassword2019*", "gst");


if(isset($_POST["submit"]))
{
	$filename = $_POST['t'];
	$fnm = $_FILES["f"]["name"];
	$dst = "./image/" . $fnm;
	move_uploaded_file($_FILES["f"]["name"],$dst);
	$query = "insert into demo(filename, name, path) values('$filename', '$fnm', '$dst')";

	$query1 = mysqli_query($link, $query);

	// $ros = mysqli_query($link, $query) or die ("Error");

	if($query1 == true)
			{
				echo "data inserted";
			}
}
?>

</html>