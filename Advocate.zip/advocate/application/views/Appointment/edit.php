

 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
	<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
  <script>tinymce.init({ selector:'textarea' });</script>
<script type="text/javascript">
  $(document).ready(function() {
  $('#cno').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#adate').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
<script type="text/javascript">
  $(document).ready(function() {
  $('#adate').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
 <script type="text/javascript">
  $(document).ready(function() {
  $('#fitness_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#insu_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#tax_rcp_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#mfg_date').datetimepicker({
    format: 'MM-YYYY',
 }); 
});
 </script>

<div class="row">
    <div class="col-md-12">
        <div class="box box-info">
            <div class="box-header with-border">
                <h3 class="box-title"> Edit appointment</h3>
            </div>
      <?php echo form_open('Appointment/edit/'.$appointment['ap_id']); ?>
      <div class="box-body">
        <div class="row clearfix">

          <div class="col-md-6">
            <label for="atitle" class="control-label">Title
            <span class="text-danger">*</span></label>
            <div class="form-group">
              <input type="text" name="atitle" value="<?php echo ($this->input->post('atitle') ? $this->input->post('atitle') : $appointment['atitle']); ?>" class="form-control" id="atitle" />
              <span class="text-danger"><?php echo form_error('atitle');?></span>
            </div>
          </div>
       
          
              
          <div class="col-md-6">
              <label for="adate" class="control-label"> Appointment  Date
                <span class="text-danger">*</span></label>
            <div class="form-group">
                  <input type="text" name="adate" value="<?php echo ($this->input->post('adate') ? date('d-m-Y', strtotime($this->input->post('adate'))) : date('d-m-Y', strtotime($appointment['adate']))); ?>" class="has-datetimepicker form-control" id="adate" />
                              <span class="text-danger"><?php echo form_error('adate');?></span>
            </div>
          </div>
          <div class="col-md-6">
                        <label for="ct_id" class="control-label"> Contact
                            <span class="text-danger">*</span></label>
          <div class="form-group">
                                   <select   name="name" id="ct_id" class="form-control">
                                         <option value="">Select case</option>
                                              <?php
                                                  foreach($all_contact as $contact)
                                                  {

                                                  $selected = ($contact['name'] == $this->input->post('name')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$contact['ct_id'].'" '.$selected.'>'.$contact['name'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
                               <span class="text-danger"><?php echo form_error('name');?></span>
                             </div>
                           </div>
<div class="col-md-6">
            <label for="motive" class="control-label">Motive
              <span></span></label>
            <div class="form-group">
              <input type="text" name="motive" value="<?php echo $this->input->post('motive'); ?>" class="form-control" id="motive"/>
              <span class="text-danger"><?php echo form_error('motive');?></span>
            </div></div>

            <div class="col-md-6">
              <label for="adate" class="control-label"> Appointment Date
                <span class="text-danger">*</span></label>
            <div class="form-group">
                  <input type="text" name="adate" value="<?php echo ($this->input->post('adate') ? date('d-m-Y', strtotime($this->input->post('adate'))) : date('d-m-Y', strtotime($appointment['adate']))); ?>" class="has-datetimepicker form-control" id="adate" />
                              <span class="text-danger"><?php echo form_error('adate');?></span>
            </div>
          </div>

          <div class="col-md-6">
            <label for="note" class="control-label">Notes
            <span class="text-danger">*</span></label>
            <div class="form-group">
            <textarea name="note" value="<?php echo ($this->input->post('note') ? $this->input->post('note') : $appointment['note']); ?>" class="form-control" id="note"></textarea>
              <span class="text-danger"><?php echo form_error('note');?></span>
            </div>
          </div>
          </div></div>
      <div class="box-footer">
              <button type="submit" class="btn btn-success">
          <i class="fa fa-check"></i> Update
        </button>
          </div>        
      <?php echo form_close(); ?>
    </div>
    </div>
</div>
</div>
</div>
					

					