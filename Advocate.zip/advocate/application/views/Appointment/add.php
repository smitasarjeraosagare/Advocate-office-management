<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>   <script>tinymce.init({ selector:'textarea' });</script>

<div class="row">
    <div class="col-md-12">
        <div class="box box-info" style="border-top-color: #605ca8">
            <div class="box-header with-border">
                <h3 class="box-title">Add Appointment</h3>
            </div>
            <?php echo form_open('Appointment/add'); ?>
            <!-- for Document -->
             
 <div class="col-md-6">
            <label for="atitle" class="control-label">
      Title
              <span class="text-danger">*</span></label>
            <div class="form-group">
              <input atitle="text" name="atitle" value="<?php echo $this->input->post('atitle'); ?>" class="form-control" id="atitle" />
              <span class="text-danger"><?php echo form_error('atitle');?></span>
            </div>
          </div>
            <div class="col-md-6">
                        <label for="ct_id" class="control-label"> Contact
                            <span class="text-danger">*</span></label>

   <div class="form-group">
                                   <select   name="name" id="ct_id" class="form-control">
                                         <option value="">Select case</option>
                                              <?php
                                                  foreach($all_contact as $contact)
                                                  {

                                                  $selected = ($contact['name'] == $this->input->post('name')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$contact['ct_id'].'" '.$selected.'>'.$contact['name'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
                               <span class="text-danger"><?php echo form_error('name');?></span>
                             </div>
                           </div> <a href="<?php echo site_url('Contact/add'); ?>" style="float: right; padding-bottom: 3px;" class="btn btn-danger btn-sm">Add New Contact</a> 
                            <div class="col-md-6">
            <label for="motive" class="control-label">
            Motive
              <span class="text-danger">*</span></label>
            <div class="form-group">
              <input atitle="text" name="motive" value="<?php echo $this->input->post('motive'); ?>" class="form-control" id="motive" />
              <span class="text-danger"><?php echo form_error('motive');?></span>
            </div>
          </div>
            <div class="col-md-6">
            <label for="adate" class="control-label">Appointment Date
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="date" name="adate" value="<?php echo $this->input->post('adate'); ?>" class="form-control" id="adate" />
              <span class="text-danger"><?php echo form_error('adate');?></span>
            </div>
          </div>
            <div class="col-md-6">
            <label for="note" class="control-label">
             Notes
            <span class="text-danger"></span></label>
            <div class="form-group">
              <textarea row="30" cols="70" name="note" value="<?php echo $this->input->post('note'); ?>" class="form-control redactor" id="note"></textarea>
              <span class="text-danger"><?php echo form_error('note');?></span>
            </div>
          </div>        
      </div></div></div>
            <div class="box-footer">
              <button atitle="submit" class="btn btn-success">
                <i class="fa fa-check"></i> Save
              </button>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>
</div>