<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#reg_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#permit_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
<script type="text/javascript">
  $(document).ready(function() {
  $('#puc_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
</script>
 <script type="text/javascript">
  $(document).ready(function() {
  $('#fitness_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#insu_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#tax_rcp_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#mfg_date').datetimepicker({
    format: 'MM-YYYY',
 }); 
});
 </script>
 <div class="row">
    <div class="col-md-12">
        <div class="box box-info" style="border-top-color: #605ca8">
            <div class="box-header with-border">
                <h3 class="box-title">leavetype</h3>
            </div>
            <?php echo form_open('leavetype/add'); ?>
            <div class="box-body">
              <div class="row clearfix">
<div class="col-md-6">
            <label for="date" class="control-label"> Date
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="date" name="date" value="<?php echo $this->input->post('date'); ?>" class="form-control" id="date" />
              <span class="text-danger"><?php echo form_error('date');?></span>
            </div>
          </div>

  <div class="col-md-6">

  <div class="form-group">Select leave
                                   <select   name="leav" id="le_id" class="form-control" placeholder="leavetype">
                                         <option value="">Select</option>
                                              <?php
                                                  foreach($all_leavetype as $leavetypetype)
                                                  {

                                                  $selected = ($leavetype['leav'] == $this->input->post('leav')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$leavetype['le_id'].'" '.$selected.'>'.$leavetype['leav'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
                               <span class="text-danger"><?php echo form_error('leav');?></span>
                             </div>
                           </div>
                 <div class="col-md-6" >
            <label for="rea" class="control-label">Reason
              <span class="text-danger"></span></label>
            <div class="form-group">
              <textarea rows="3" name="rea" value="<?php echo $this->input->post('rea'); ?>" class="form-control" id="rea"></textarea>
              <span class="text-danger"><?php echo form_error('rea');?></span>
            </div>
          </div>
            <div class="row">
                <!-- <div class="col-xs-12">
                  <button class="add_field_button btn btn-success m-b-20">Add More </button>
                </div> -->
            </div>
          </div>


            <div class="box-footer">
              <button type="submit" class="btn btn-success">
                <i class="fa fa-check"></i> Save
              </button>
            </div></div></div>
</div></div></div></div></div></div>