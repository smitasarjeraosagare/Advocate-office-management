
        <div class="box box-info">
            <div class="box-header with-border">
                <h3 class="box-title">Manage Document</h3>
            </div>
      <!--  <?php echo form_open_multipart('Document/upload/'.$doc['d_id']); ?> -->
       <?php echo form_open_multipart('Document/index/'.$doc['d_id']); ?>
      <div class="box-body">
        <div class="row clearfix">
           
<div class="col-md-6">
            <label for="doc" class="control-label">
            <span class="text-danger">*</span></label>Attachment
            <div class="form-group">
              <input type="file" title="doc" value="<?php echo ($this->input->post('doc') ? $this->input->post('doc') : $doc['doc']); ?>" class="form-control" id="doc" />
              <span class="text-danger"><?php echo form_error('doc');?></span>
            </div>
          </div>
 <div>
         <div class="col-md-6">
          <div class="col-md-6">
            <label for="title" class="control-label"> Name
            <span class="text-danger">*</span></label>
            <div class="form-group">
              <input type="text" name="title" value="<?php echo ($this->input->post('title') ? $this->input->post('title') : $doc['title']); ?>" class="form-control" id="title" />
              <span class="text-danger"><?php echo form_error('title');?></span>
            </div>
          </div>
        </div>
      </div>



      </div>
            <div class="box-footer">
              <button type="submit" class="btn btn-success">
                <i class="fa fa-check"></i> Save
              </button>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>