

 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

 
<script type="text/javascript">
  $(document).ready(function() {
  $('#cno').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#ndat').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
<script type="text/javascript">
  $(document).ready(function() {
  $('#hdate').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
 <script type="text/javascript">
  $(document).ready(function() {
  $('#fitness_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#insu_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#tax_rcp_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#mfg_date').datetimepicker({
    format: 'MM-YYYY',
 }); 
});
 </script>

<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title"> Edit todolist</h3>
            </div>
			<?php echo form_open('todolist/edit/'.$todolist['t_id']); ?>
			<div class="box-body">
				<div class="row clearfix">

					<div class="col-md-6">
						<label for="name" class="control-label"> Case Title
						<span class="text-danger">*</span></label>
						<div class="form-group">
							<input type="text" name="name" value="<?php echo ($this->input->post('name') ? $this->input->post('name') : $todolist['name']); ?>" class="form-control" id="name" />
							<span class="text-danger"><?php echo form_error('name');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="des" class="control-label"> Case Title
						<span class="text-danger">*</span></label>
						<div class="form-group">
							<input type="text" name="des" value="<?php echo ($this->input->post('des') ? $this->input->post('des') : $todolist['des']); ?>" class="form-control" id="des" />
							<span class="text-danger"><?php echo form_error('des');?></span>
						</div>
					</div>
					
					<div class="col-md-6">
				     	<label for="ndat" class="control-label"> Next  Date
					     	<span class="text-danger">*</span></label>
						<div class="form-group">
					      	<input type="text" name="ndat" value="<?php echo ($this->input->post('ndat') ? date('d-m-Y', strtotime($this->input->post('ndat'))) : date('d-m-Y', strtotime($todolist['ndat']))); ?>" class="has-datetimepicker form-control" id="ndat" />
                              <span class="text-danger"><?php echo form_error('ndat');?></span>
						</div>
					</div>

					
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Update
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>
</div>
</div>