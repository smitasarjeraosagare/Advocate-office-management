

 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<!--  
<script type="text/javascript">
  $(document).ready(function() {
  $('#note').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#fdate').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
<script type="text/javascript">
  $(document).ready(function() {
  $('#hdate').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
 <script type="text/javascript">
  $(document).ready(function() {
  $('#fitness_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#insu_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#tax_rcp_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#mfg_date').datetimepicker({
    format: 'MM-YYYY',
 }); 
});
 </script>

 --><div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title"> Edit study</h3>
            </div>
			<?php echo form_open('study/edit/'.$study['st_id']); ?>
			<div class="box-body">
				<div class="row clearfix">

					<div class="col-md-6">
						<label for="stitle" class="control-label">
							Title
						<span class="text-danger">*</span></label>
						<div class="form-group">
							<input type="text" name="stitle" value="<?php echo ($this->input->post('stitle') ? $this->input->post('stitle') : $study['stitle']); ?>" class="form-control" id="stitle" />
							<span class="text-danger"><?php echo form_error('stitle');?></span>
						</div>
					</div>
					 <div class="col-md-6">
                        <label for="cscat" class="control-label">  Case Category
                            <span class="text-danger">*</span></label>
                        <div class="form-group">
                            <select id="cscat" name="cscat" class="form-control">
                                   <option value="">Select </option>
                                   <option value="Criminal">Crimilnal</option>
                                   <option value="Bankrupt">Bankrupt</option>
                                    <option value="fraud">Fraud</option>
                            </select>
                            <span class="text-danger"><?php echo form_error('cscat');?></span>
                        </div></div>

					<div class="col-md-6">
						<label for="note" class="control-label">Note
						<span class="text-danger">*</span></label>
						<div class="form-group">
							<input type="textarea" name="note" value="<?php echo ($this->input->post('note') ? $this->input->post('note') : $study['note']); ?>" class="form-control" id="note" />
							<span class="text-danger"><?php echo form_error('note');?></span>
						</div>
					</div>

					<div class="col-md-6">
						<label for="res" class="control-label">Result
						<span class="text-danger">*</span></label>
						<div class="form-group">
							<input type="textarea" name="res" value="<?php echo ($this->input->post('res') ? $this->input->post('res') : $study['res']); ?>" class="form-control" id="res" />
							<span class="text-danger"><?php echo form_error('res');?></span>
						</div>
					</div>

					
				
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Update
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>
</div>
</div>