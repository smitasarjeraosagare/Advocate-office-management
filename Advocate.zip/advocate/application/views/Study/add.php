<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
  <script>tinymce.init({ selector:'textarea' });</script>
<script src="http://advocate.webappsdemo.in/assets/plugins/chosen/chosen.jquery.min.js" type="text/javascript"></script>
<script src="http://advocate.webappsdemo.in/assets/js/redactor.min.js"></script>
<script type="text/javascript">
$(function() {
  
  $('.chzn').chosen();
  
});
</script>

 <script>
  $(document).ready(function(){
    $('.redactor').redactor({
        // formatting: ['p', 'blockquote', 'h2','img'],
            minHeight: 200,
            imageUpload: 'http://advocate.webappsdemo.in/wysiwyg/upload_image',
            fileUpload: 'http://advocate.webappsdemo.in/wysiwyg/upload_file',
            imageGetJson: 'http://advocate.webappsdemo.in/wysiwyg/get_images',
            imageUploadErrorCallback: function(json)
            {
                alert(json.error);
            },
            fileUploadErrorCallback: function(json)
            {
                alert(json.error);
            }
      });
});
  </script> 
<script type="text/javascript">
  $(document).ready(function() {
  $('#reg_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
 <script type="text/javascript">
        $(document).ready(

        function() {
            $('#redactor_content').redactor({
                imageUpload: './image'
            });
        });
    </script>
    <script type="text/javascript">
$(function() {
  
  $('.chzn').chosen();
  
});
</script>

 <script>
  $(document).ready(function(){
    $('.redactor').redactor({
        // formatting: ['p', 'blockquote', 'h2','img'],
            minHeight: 200,
            imageUpload: '',
            fileUpload: '',
            imageGetJson: '',
            imageUploadErrorCallback: function(json)
            {
                alert(json.error);
            },
            fileUploadErrorCallback: function(json)
            {
                alert(json.error);
            }
      });
});
  </script>
  <link href="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" rel="stylesheet">
<link href="http://netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link href="editor.css" type="text/css" rel="stylesheet"/>
<script src="editor.js"></script>
<script type="text/javascript">
$(document).ready(function() {
$("#txtEditor").Editor();                   
});
</script>
<script>
 
                $(document).ready(function() {
 
                   $("#demo-editor-bootstrap").Editor();
 
                });
 
</script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#permit_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
<script type="text/javascript">
  $(document).ready(function() {
  $('#puc_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
</script>
 <script type="text/javascript">
  $(document).ready(function() {
  $('#fitness_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#insu_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#tax_rcp_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
 <script>
 
      $(document).ready(function() {
 
       $("#demo-editor-bootstrap").Editor(
 
        {"bold":false,
 
         "italics": false,
 
         "fonts": false
 
        }
 
        );
 
   });
 
</script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#mfg_date').datetimepicker({
    format: 'MM-YYYY',
 }); 
});
 </script>
 <div class="row">
    <div class="col-md-12">
      	<div class="box box-info" style="border-top-color: #605ca8">
            <div class="box-header with-border">
              	<h3 class="box-title">Add Case study</h3>
            </div>
            <?php echo form_open('study/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">

	
	<div class="col-md-6">
						<label for="stitle" class="control-label">
						 Title
            <span class="text-danger"></span></label>
						<div class="form-group">
							<input type="text" name="stitle" value="<?php echo $this->input->post('stitle'); ?>" class="form-control" id="stitle" />
							<span class="text-danger"><?php echo form_error('stitle');?></span>
						</div>
					</div>
	  <div class="col-md-6">
                        <label for="cscat" class="control-label">  Case Category
                            <span class="text-danger">*</span></label>
                        <div class="form-group">
                            <select id="cscat" name="cscat" class="form-control">
                                   <option value="">Select </option>
                                   <option value="Criminal">Crimilnal</option>
                                   <option value="Bankrupt">Bankrupt</option>
                                    <option value="fraud">Fraud</option>
                            </select>
                            <span class="text-danger"><?php echo form_error('cscat');?></span>
                        </div></div>
<div class="col-md-6">
            <label for="note" class="control-label">
             Notes
            <span class="text-danger"></span></label>
            <div class="form-group">
              <textarea class="form-control redactor" rows="10"  name="note" value="<?php echo $this->input->post('note'); ?>" class="form-control redactor" id="note"></textarea>
              <span class="text-danger"><?php echo form_error('note');?></span>
            </div>
          </div>
<div class="col-md-6">
            <label for="res" class="control-label">
             Result
            <span class="text-danger"></span></label>
            <div class="form-group">
              <textarea class="form-control redactor" rows="10"  name="res" value="<?php echo $this->input->post('res'); ?>" class="form-control redactor" id="res"></textarea>
              <span class="text-danger"><?php echo form_error('res');?></span>
            </div>
          </div>       
	        	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div>
</html>