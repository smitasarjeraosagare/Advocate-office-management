  <!--    <form action="http://localhost/program/advocate/Employee/upload_file" 

 enctype="multipart/form-data" method="post" accept-charset="utf-8"> -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimephotoker/4.17.37/css/bootstrap-datetimephotoker.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimephotoker/4.17.37/js/bootstrap-datetimephotoker.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#reg_date').datetimephotoker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#permit_exp_date').datetimephotoker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
<script type="text/javascript">
  $(document).ready(function() {
  $('#puc_exp_date').datetimephotoker({
    format: 'D-MM-YYYY',
 }); 
});
</script>
 <script type="text/javascript">
  $(document).ready(function() {
  $('#fitness_exp_date').datetimephotoker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#insu_exp_date').datetimephotoker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#tax_rcp_exp_date').datetimephotoker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#mfg_date').datetimephotoker({
    format: 'MM-YYYY',
 }); 
});
 </script>
 <div class="row">
    <div class="col-md-12">
      	<div class="box box-info" style="border-top-color: #605ca8">
            <div class="box-header with-border">
              	<h3 class="box-title">Add Employee</h3>
            </div>

           <!--  <?php echo form_open('Employees/add'); ?> -->
           <?php echo form_open_multipart('Employees/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">

	
	<div class="col-md-6">
						<label for="ename" class="control-label">
						Name
            <span class="text-danger"></span></label>
						<div class="form-group">
							<input type="text" name="ename" value="<?php echo $this->input->post('ename'); ?>" class="form-control" id="ename" />
							<span class="text-danger"><?php echo form_error('ename');?></span>
						</div>
					</div>

          
            <div class="col-md-6">
            <label for="photo" class="control-label">
            Photo
              <span class="text-danger"></span></label>
            <div class="form-group"> 
              <input type="file" name="photo" value="<?php echo $this->input->post('photo'); ?>" class="form-control" id="photo" />
              <span class="text-danger"><?php echo form_error('photo');?></span>
            </div>
          </div>
          <div><div  class="col-md-6">
          <label for="gen">gender:<span class="text-danger"></span></label>
                             <div class="radio">&nbsp;&nbsp;
                            <?php echo form_radio('gen', 'Male', FALSE); ?>Male  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                           <?php echo form_radio('gen', 'Female', FALSE); ?>Female
                     </div>
                 </div></div>
         
         
  <div class="col-md-6">
            <label for="edob" class="control-label"> Date of Birth
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="date" name="edob" value="<?php echo $this->input->post('edob'); ?>" class="form-control" id="edob" />
              <span class="text-danger"><?php echo form_error('edob');?></span>
            </div>
          </div>
          <div class="col-md-6">
            <label for="jsalary" class="control-label">joining salary  
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="text" name="jsalary" value="<?php echo $this->input->post('jsalary'); ?>" class="form-control" id="jsalary" />
              <span class="text-danger"><?php echo form_error('jsalary');?></span>
            </div>
          </div>
          <div class="col-md-6">
                        <label for="ur_id" class="control-label"> Role
                            <span class="text-danger">*</span></label>

   <div class="form-group">
                                   <select   name="uename" id="ur_id" class="form-control">
                                         <option value="">Select role</option>
                                              <?php
                                                  foreach($all_role as $userrole)
                                                  {

                                                  $selected = ($userrole['uename'] == $this->input->post('uename')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$userrole['ur_id'].'" '.$selected.'>'.$userrole['uename'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
                               <span class="text-danger"><?php echo form_error('uename');?></span>
                             </div>
                           </div>
            <!-- for department -->         
<div class="col-md-6">
                        <label for="dp_id" class="control-label"> department
                            <span class="text-danger">*</span></label>

   <div class="form-group">
                                   <select   name="dname" id="dp_id" class="form-control">
                                         <option value="">Select department</option>
                                              <?php
                                                  foreach($all_department as $department)
                                                  {

                                                  $selected = ($department['dname'] == $this->input->post('dname')) ? ' select="select"' : "";

                                                  echo '<option value="'.$department['dp_id'].'" '.$select.'>'.$department['dname'].'</option>';
                                                   }
                                              ?>
                                  </select>

                               <span class="text-danger"><?php echo form_error('dname');?></span>
                             </div>
                           </div>
<div class="col-md-6">
            <label for="email" class="control-label">Email 
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="datetimephotoker" name="email" value="<?php echo $this->input->post('email'); ?>" class="form-control" id="email" />
              <span class="text-danger"><?php echo form_error('email');?></span>
            </div>
          </div>
          
        <div class="col-md-6">
            <label for="username" class="control-label">user
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="text" name="username" value="<?php echo $this->input->post('username'); ?>" class="form-control" id="username" />
              <span class="text-danger"><?php echo form_error('username');?></span>
            </div>
          </div>
       
         <div class="row clearfix">
          <div class="col-md-6">
            <label for="password" class="control-label">Password</label>
            <div class="form-group">
              <input type="password" name="password" value="" class="form-control" id="password" />
              <span class="text-danger"><?php echo form_error('password');?></span>
            </div>
          </div>
          <div class="col-md-6">
            <label for="passconf" class="control-label">Confirm Password</label>
            <div class="form-group">
              <input type="password" name="passconf" value="" class="form-control" id="passconf" />
              <span class="text-danger"><?php echo form_error('passconf');?></span>
            </div>
          </div>
          </div>
          <div class="col-md-6">
            <label for="ephone" class="control-label">
            phone
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="text" name="ephone" value="<?php echo $this->input->post('ephone'); ?>" class="form-control" id="ephone" />
              <span class="text-danger"><?php echo form_error('ephone');?></span>
            </div>
          </div>
       
          <div class="col-md-6">
            <label for="eadd" class="control-label">address  
              <span class="text-danger"></span></label>
            <div class="form-group">
              <textarea rows="4" name="eadd" value="<?php echo $this->input->post('eadd'); ?>" class="form-control" id="eadd"></textarea>
              <span class="text-danger"><?php echo form_error('eadd');?></span>
            </div>
          </div>
          <br>
          
          <br>
           <div><div  class="col-md-6">
          <label for="status">Status:<span class="text-danger"></span></label>
                             <div class="Checkbox">
                            <?php echo form_checkbox('status', 'Active'); ?>Active  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                           <?php echo form_checkbox('status', 'Deactive'); ?>Deactive
                     </div>
                 </div></div>
        
           

	        	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div></div></div>
</div></div></div></div></div></div>
<!-- </form> -->