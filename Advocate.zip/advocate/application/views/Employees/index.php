 
<style>
.css-serial {
  counter-reset: serial-number;  /* Set the serial number counter to 0 */
}

.css-serial td:first-child:before {
  counter-increment: serial-number;  /* Increment the serial number counter */
  content: counter(serial-number);  /* Display the counter */
}
</style>
 <style>
         .star {
         background-color: transparent;
         background-image: url('http://localhost/technicalkeeda/images/star-off.png');
         background-repeat:no-repeat;
         display: block;  
         height:16px;
         width:16px;
         float:left;
         } 
         .favorited {
         text-indent: -5000px;
         background-color: transparent;
         background-image: url('http://localhost/technicalkeeda/images/star-on.png');
         background-repeat:no-repeat;   
         height:16px;
         width:16px;
         float:left;
         }
      </style>

<script>
function confirm_delete()
{
    if(confirm("Are you sure you want to delete this record ?"))
    {
        return true;
    }
    else
    {
        return false;
    }
}   
function star()
{
    if(confirm(Add to Star))
    {
        return true;
    }
    else
    {
        return false;
    }
}   
</script>
<script type="text/javascript" language="javascript" src="http://code.jquery.com/jquery-latest.js"></script>
      <script>
        $(document).ready(function(){ 
           $('.star,.favorited').click(function() {
            var id = $(this).parents('div').attr('id');    
            var className = $(this).attr('class');
            var flag  = (className=='star') ? 'Y':'N';
            var $this = $(this);
            $.ajax({
              type: "post",
              url: "http://localhost/technicalkeeda/demo",
              cache: false,    
              data:{'sid': id,'sflag':flag},
              success: function(response){
               if(response=='true'){        
                $this.toggleClass("favorited");
               } 
              },
              error: function(){      
               alert('Error while request..');
              }
              });
            });
         });
      </script>



 
<div class="panel  panel-danger bord"  >
      <div class="panel-heading  red-color">Employees
                     <a href="<?php echo site_url('Employees/add'); ?>" style="float: right; padding-bottom: 3px;" class="btn btn-danger btn-sm">Add</a> 
                </div>  
      
             <div class="box-body">

         
        <div class="table-responsive" >  
 <!-- try -->
 <div class="row" style="margin-bottom:10px;">
            <div class="col-xs-12">
                <div class="">
                    <div class="col-xs-2">
            <select name="filter" id="Employees_id" class="form-control chzn">
              <option>--Filter By Employees--</option>
                                </select>
          </div>
          
           <div class="col-xs-2">
            <select name="filter_court" id="court_id" class="form-control chzn">
              <option>--Filter By Court--</option>
                  <option value="4" >Civil</option><option value="6" >Sidney Rema</option><option value="7" >sargodha courts</option>           </select>
          </div>
            
           <div class="col-xs-2">
            <select name="filter_location" id="location_id" class="form-control chzn">
              <option>--Filter By Location--</option>
              <option value="22" >Muscat</option><option value="23" >Seeb</option><option value="25" >sargodha</option>           </select>
          </div>
          
          <div class="col-xs-2">
            <select name="filter_location" id="case_sEmployeese_id" class="form-control chzn">
              <option>--Filter By Case SEmployeeses--</option>
              <option value="6" >Filing</option><option value="8" >Pre-Trial</option><option value="5" >Preliminary Hearing</option><option value="7" >Service of summons</option><option value="9" >Hearing</option><option value="10" >Submissions 2</option><option value="11" >Judgement</option>           </select>
          </div>
          
          <div class="col-xs-2">
            <input type="text" name="date1" id="date1" class="form-control datepicker" placeholder="Filling Date" />
          </div>
          
          <div class="col-xs-2">
            <input type="text" name="date2" id="date2" class="form-control datepicker" placeholder="Hearing Date" />
          </div>
          
                </div>
            </div>    
        </div>  
        
        <div class="row">
          <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                                                      
                </div><!-- /.box-header -->


 <!-- finish -->
 
            <table id="tb" class="table css-serial   table-bordered" cellspacing="0" width="100%">
        <thead>

                    <tr>
                        <th>Sr. No</th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Status</th>
                        <th>Action</th>
                       

                    </tr>
                </thead>
                    <?php foreach($employee as $c){ ?>
                    <tr>
                        <td></td>
                        

 
                        <td><?php echo $c['ename']; ?></td>

                        <td><?php echo $c['ephone']; ?></td>
                        <td><?php echo $c['status']; ?></td>

                       

 
                                            
                        <td>
                            <a href="<?php echo site_url('Employees/view/'.$c['e_id']); ?>" class="btn btn-primary btn-xs"><button class="btn btn-danger btn-xs"><span>View</span></button>  </a>

                            <a href="<?php echo site_url('Employees/edit/'.$c['e_id']); ?>" class="btn btn-info btn-xs"><button class="btn btn-danger btn-xs"><span>Edit</span></button>  </a>

                            <a href="<?php echo site_url('Employees/remove/'.$c['e_id']); ?>" class="btn btn-danger btn-xs" onclick="return confirm_delete()"><button class="btn btn-danger btn-xs"><span>Delete</span></button>  </a>
                           
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                            
            </div>
        </div>
    </div>
</div>

 
  <script>
  $(function(){
    $("#tb").dataTable();
  })
  </script>
