<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
  <script>tinymce.init({ selector:'textarea' });</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#reg_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#permit_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
<script type="text/javascript">
  $(document).ready(function() {
  $('#puc_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
</script>
 <script type="text/javascript">
  $(document).ready(function() {
  $('#fitness_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
 <script type="text/javascript">
$(document).ready(function() {
    var max_fields      = 100; //maximum input boxes allowed
    var wrapper         = $(".input_fields_wrap"); //Fields wrapper
    var add_button      = $(".add_field_button"); //Add button ID
    
    var x = 1; //initlal text box count
    $(add_button).click(function(e){ //on add input button click
        e.preventDefault();
        if(x < max_fields){ //max input box allowed
            x++; //text box increment
            $(wrapper).append('<div class="row"><div class="col-md-4"><input type="text" name="design[]" value="" class="form-control" placeholder="design"></div><a href="#" class="remove_field btn btn-danger" >Remove</a></div></div>'); //add input box
      $('.chzn').chosen({search_contains:true});
        }
    });
    
    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).parent('div').remove(); x--;
    })
});



</script>  

 <script type="text/javascript">
  $(document).ready(function() {
  $('#insu_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#tax_rcp_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#mfg_date').datetimepicker({
    format: 'MM-YYYY',
 }); 
});
 </script>
 <div class="row">
    <div class="col-md-12">
        <div class="box box-info" style="border-top-color: #605ca8">
            <div class="box-header with-border">
                <h3 class="box-title">Add</h3>
            </div>
            <?php echo form_open('Department/add'); ?>
            <div class="box-body">
              <div class="row clearfix">

  
  <div class="col-md-8">
            <label for="dname" class="control-label">
           name
            <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="text" name="dname" value="<?php echo $this->input->post('dname'); ?>" class="form-control" id="dname" />
              <span class="text-danger"><?php echo form_error('dname');?></span>
            </div>
          </div><div>
  <!--  <div class="col-md-8">
            <label for="design" class="control-label">
           Designation
            <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="text" name="design" value="<?php echo $this->input->post('design'); ?>" class="form-control" id="design" />
              <span class="text-danger"><?php echo form_error('design');?></span>
            </div>
          </div></div> -->
          <div class="col-md-8">
            <label for="des" class="control-label">
            Desciption
            <span class="text-danger"></span></label>
            <div class="form-group">
              <textarea name="des" rows="10" value="<?php echo $this->input->post('des'); ?>" class="form-control" id="des"></textarea>
              <span class="text-danger"><?php echo form_error('des');?></span>
            </div>
           
                    
                    <!-- <div class="col-md-4" style="padding-top:22px;">
                      <button class="add_field_button btn btn-success" >Add More </button>
                    </div> -->
          </div><div></div></div></div></div>
            </div></div>
            <div class="box-footer">
              <button type="submit" class="btn btn-success">
                <i class="fa fa-check"></i> Save
              </button></div>
</div></div></div></div></div></div>