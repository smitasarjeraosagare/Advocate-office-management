<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

 

<div class="row">
    <div class="col-md-12">
        <div class="box box-info" style="border-top-color: #605ca8">
            <div class="box-header with-border">
                <h3 class="box-title">Add Court</h3>
            </div>
            <?php echo form_open('Court/add'); ?>
             <div>
                            <div class="col-md-6">
            <label for="court" class="control-label">
            Name
              <span class="text-danger">*</span></label>
            <div class="form-group">
              <input type="text" name="court" value="<?php echo $this->input->post('court'); ?>" class="form-control" id="court" />
              <span class="text-danger"><?php echo form_error('court');?></span>
            </div>
          </div>

      </div>
            <!-- for unit -->
            <div class="col-md-6">
                        <label for="l_id" class="control-label"> Location
                            <span class="text-danger">*</span></label>

   <div class="form-group">
                                   <select   name="lname" id="l_id" class="form-control">
                                         <option value="">Select Location</option>
                                              <?php
                                                  foreach($all_location as $location)
                                                  {

                                                  $selected = ($location['lname'] == $this->input->post('lname')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$location['l_id'].'" '.$selected.'>'.$location['lname'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
                               <span class="text-danger"><?php echo form_error('lname');?></span>
                             </div>
                           </div>
            <!-- for courtcat -->         
<div class="col-md-6">
                        <label for="coucat_id" class="control-label"> courtcat
                            <span class="text-danger">*</span></label>

   <div class="form-group">
                                   <select   name="courtname" id="coucat_id" class="form-control">
                                         <option value="">Select courtcat</option>
                                              <?php
                                                  foreach($all_courtcat as $courtcat)
                                                  {

                                                  $selected = ($courtcat['courtname'] == $this->input->post('courtname')) ? ' select="select"' : "";

                                                  echo '<option value="'.$courtcat['coucat_id'].'" '.$select.'>'.$courtcat['courtname'].'</option>';
                                                   }
                                              ?>
                                  </select>

                               <span class="text-danger"><?php echo form_error('courtname');?></span>
                             </div>
                           </div>
                           <div>
                            <div class="col-md-6">
            <label for="des" class="control-label">
            Description
              <span class="text-danger">*</span></label>
            <div class="form-group">
              <input type="text" name="des" value="<?php echo $this->input->post('des'); ?>" class="form-control" id="des" />
              <span class="text-danger"><?php echo form_error('des');?></span>
            </div>
          </div>

      </div>
            <div class="box-footer">
              <button type="submit" class="btn btn-success">
                <i class="fa fa-check"></i> Save
              </button>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>
</div>