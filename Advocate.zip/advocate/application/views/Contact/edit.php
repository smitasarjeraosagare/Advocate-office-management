

 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

 
<script type="text/javascript">
  $(document).ready(function() {
  $('#cno').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#ndat').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
<script type="text/javascript">
  $(document).ready(function() {
  $('#hdate').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
 <script type="text/javascript">
  $(document).ready(function() {
  $('#fitness_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#insu_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#tax_rcp_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#mfg_date').datetimepicker({
    format: 'MM-YYYY',
 }); 
});
 </script>

<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title"> Edit contact</h3>
            </div>
			<?php echo form_open('contact/edit/'.$contact['ct_id']); ?>
			<div class="box-body">
				<div class="row clearfix">

					<div class="col-md-6">
						<label for="name" class="control-label"> Name
						<span class="text-danger">*</span></label>
						<div class="form-group">
							<input type="text" name="name" value="<?php echo ($this->input->post('name') ? $this->input->post('name') : $contact['name']); ?>" class="form-control" id="name" />
							<span class="text-danger"><?php echo form_error('name');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="phone" class="control-label"> Phone
						<span class="text-danger">*</span></label>
						<div class="form-group">
							<input type="number" name="phone" value="<?php echo ($this->input->post('phone') ? $this->input->post('phone') : $contact['phone']); ?>" class="form-control" id="phone" />
							<span class="text-danger"><?php echo form_error('phone');?></span>
						</div>
					</div>
					
					<div class="col-md-6">
						<label for="email" class="control-label"> Email
						<span class="text-danger">*</span></label>
						<div class="form-group">
							<input type="email" name="email" value="<?php echo ($this->input->post('email') ? $this->input->post('email') : $contact['email']); ?>" class="form-control" id="email" />
							<span class="text-danger"><?php echo form_error('email');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="addr" class="control-label"> Address
						<span class="text-danger">*</span></label>
						<div class="form-group">
							<input type="text" name="addr" value="<?php echo ($this->input->post('addr') ? $this->input->post('addr') : $contact['addr']); ?>" class="form-control" id="addr" />
							<span class="text-danger"><?php echo form_error('addr');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="card" class="control-label"> Id Card No
						<span class="text-danger">*</span></label>
						<div class="form-group">
							<input type="text" name="card" value="<?php echo ($this->input->post('card') ? $this->input->post('card') : $contact['card']); ?>" class="form-control" id="card" />
							<span class="text-danger"><?php echo form_error('card');?></span>
						</div>
					</div>

					
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Update
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>
</div>
</div>