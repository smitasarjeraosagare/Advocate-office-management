  <!--    <form action="http://localhost/program/advocate/Clients/upload_file" 

 enctype="multipart/form-data" method="post" accept-charset="utf-8"> -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#reg_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#permit_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
<script type="text/javascript">
  $(document).ready(function() {
  $('#puc_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
</script>
 <script type="text/javascript">
  $(document).ready(function() {
  $('#fitness_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#insu_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#tax_rcp_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#mfg_date').datetimepicker({
    format: 'MM-YYYY',
 }); 
});
 </script>
 <div class="row">
    <div class="col-md-12">
      	<div class="box box-info" style="border-top-color: #605ca8">
            <div class="box-header with-border">
              	<h3 class="box-title">Add Clients</h3>
            </div>

            <!-- <?php echo form_open('Clients/add'); ?> -->
            <?php echo form_open_multipart('Clients/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">

	
	<div class="col-md-6">
						<label for="name" class="control-label">
						Name
            <span class="text-danger"></span></label>
						<div class="form-group">
							<input type="text" name="name" value="<?php echo $this->input->post('name'); ?>" class="form-control" id="name" />
							<span class="text-danger"><?php echo form_error('name');?></span>
						</div>
					</div>

          <div class="col-md-6">
            <label for="phone" class="control-label">
            Phone
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="text" name="phone" value="<?php echo $this->input->post('phone'); ?>" class="form-control" id="phone" />
              <span class="text-danger"><?php echo form_error('phone');?></span>
            </div>
          </div>
        
  <div class="col-md-6">
    <label for="photo" class="control-label">Photo<span class="text-danger">*</span></label>
                            
      <div class="form-group">
        <input type="file" name="photo" value="<?php echo $this->input->post('photo'); ?>" class="form-control" id="photo" />
          <span class="text-danger"><?php echo form_error('photo');?></span>
       </div>
  </div>

          
            <div  class="col-md-6">
          <label for="gender">Gender:<span class="text-danger"></span></label>
                             <div class="radio">
                            <?php echo form_radio('gender', 'Male', FALSE); ?>Male  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                           <?php echo form_radio('gender', 'Female', FALSE); ?>Female
                     </div>
                 </div>
       
         
         
  <div class="col-md-6">
            <label for="dob" class="control-label"> Date of Birth
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="date" name="dob" value="<?php echo $this->input->post('dob'); ?>" class="form-control" id="dob" />
              <span class="text-danger"><?php echo form_error('dob');?></span>
            </div>
          </div>
<div class="col-md-6">
            <label for="email" class="control-label">Email 
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="datetimepicker" name="email" value="<?php echo $this->input->post('email'); ?>" class="form-control" id="email" />
              <span class="text-danger"><?php echo form_error('email');?></span>
            </div>
          </div>
          
        <div class="col-md-6">
            <label for="username" class="control-label">Username
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="text" name="username" value="<?php echo $this->input->post('username'); ?>" class="form-control" id="username" />
              <span class="text-danger"><?php echo form_error('username');?></span>
            </div>
          </div>
       
          <div class="col-md-6">
            <label for="password" class="control-label">Password</label>
            <div class="form-group">
              <input type="password" name="password" value="" class="form-control" id="password" />
              <span class="text-danger"><?php echo form_error('password');?></span>
            </div>
          </div>
          <div class="col-md-6">
            <label for="passconf" class="control-label">Confirm Password</label>
            <div class="form-group">
              <input type="password" name="passconf" value="" class="form-control" id="passconf" />
              <span class="text-danger"><?php echo form_error('passconf');?></span>
            </div>
          </div>
       
          <div class="col-md-6">
            <label for="address" class="control-label">Address  
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="textarea" name="address" value="<?php echo $this->input->post('address'); ?>" class="form-control" id="address" />
              <span class="text-danger"><?php echo form_error('address');?></span>
            </div>
          </div>
          <br>
          <div class="col-md-6">
            <label for="m" class="control-label">m 
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="text" name="m" value="<?php echo $this->input->post('m'); ?>" class="form-control" id="m" />
              <span class="text-danger"><?php echo form_error('m');?></span>
            </div>
          </div>
          <br>
          <div class="col-md-6">
            <label for="test" class="control-label">test  
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="text" name="test" value="<?php echo $this->input->post('test'); ?>" class="form-control" id="test" />
              <span class="text-danger"><?php echo form_error('test');?></span>
            </div>
          </div>
          <br>
          <div class="col-md-6">
            <label for="ctype" class="control-label">Client Type
              <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="text" name="ctype" value="<?php echo $this->input->post('ctype'); ?>" class="form-control" id="ctype" />
              <span class="text-danger"><?php echo form_error('ctype');?></span>
            </div>
          </div>
        
           

	        	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Save
            	</button>
          	</div></div></div>
</div></div></div></div></div></div>
<!-- </form> -->