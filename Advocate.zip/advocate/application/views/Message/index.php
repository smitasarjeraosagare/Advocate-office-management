
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script type="text/javascript" src="ckeditor.js"></script>
<script type="text/javascript" src="advocate/assests/js/tiny_mce.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<!-- <script type="text/javascript">
  tinyMCE.init({
  theme : "advanced",
  theme_advanced_toolbar_location : "top",
  theme_advanced_toolbar_align : "left",
  mode : "exact",
  elements : "message",
});
</script> -->
<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
  <script>tinymce.init({ selector:'textarea' });</script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#reg_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#permit_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
<script type="text/javascript">
  $(document).ready(function() {
  $('#puc_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
</script>
 <script type="text/javascript">
  $(document).ready(function() {
  $('#fitness_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#insu_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#tax_rcp_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#mfg_date').datetimepicker({
    format: 'MM-YYYY',
 }); 
});
 </script>
 <div class="row">
    <div class="col-md-12">
        <div class="box box-info" style="border-top-color: #605ca8">
            <div class="box-header with-border">
             
                <h3 class="box-title">Message</h3>  <div>
           <a href="https://mail.google.com/mail/"class="btn btn-primary pull-right" style="margin-right: 5px;"><i class="fa fa-envelope"></i> Message Via Mail </a></div>
            </div>
            <?php echo form_open('Message/add'); ?>
              <div class="col-md-8">
            <label for="name" class="control-label">
            
            <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="text" name="name" value="<?php echo $this->input->post('name'); ?>" class="form-control" id="name" placeholder="Your Name" />
              <span class="text-danger"><?php echo form_error('name');?></span>
            </div>
          </div>
              </div>
              <div class="col-md-8">
            <label for="email" class="control-label">
            
            <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="text" name="email" value="<?php echo $this->input->post('email'); ?>" class="form-control" id="email" placeholder="Your email" />
              <span class="text-danger"><?php echo form_error('email');?></span>
            </div>
          </div>
             <div class="col-md-8">
            <label for="number" class="control-label"> 
            <span class="text-danger"></span></label>
            <div class="form-group">
              <input type="text" name="number" value="<?php echo $this->input->post('number'); ?>" class="form-control" id="number" placeholder="Your number" />
              <span class="text-danger"><?php echo form_error('number');?></span>
            </div>
          </div>
              <div class="col-sm-8">
            <label for="message" class="control-label">
            Message
            <span class="text-danger"></span></label>
            <div class="form-group">
              <textarea name="message" rows="5" value="<?php echo $this->input->post('message'); ?>" class="form-control" id="message" placeholder="Message"></textarea>

              <span class="text-danger"><?php echo form_error('message');?></span>
            </div><div class="col-sm-6">
          </div>
             <div class="form-group">
                 <!--  <input type="submit" name="btnSubmit" id="get_in_touch_btn" class="btnContact" value=""" /> -->
              </div>
              <button type="submit" class="btn btn-success" name="btnSubmit" id="get_in_touch_btn" class="btnContact">Submit</button>

          </div>



  <!-- </form> -->
</div>
</body>
 
<script type="text/javascript">
  var BASE_URL = "<?php echo base_url(); ?>";
     if ($("#getInTouchForm").length > 0) {
     $("#getInTouchForm").validate({
          rules: {
            name: {
              required: true,
            },
            email: {
              required: true,
            },
            number: {
              required: true,
              maxlength: 10,
            },
            message: {
              required: true,
            }
          },
           messages: {
              name: {
                required: 'Please enter name',
              },
              email: {
                required: 'Please enter email',
              },
              number: {
                required: 'Please enter mobile number',
              },
              message: {
                required: 'Please enter message',
              }
              
            },
          submitHandler: function (form) {
            var oldval = $('#get_in_touch_btn').val();
            $('#get_in_touch_btn').prop('disabled', true);
            $('#get_in_touch_btn').val('Submitting..');
              $.ajax({
                  type: "POST",
                  url: BASE_URL  + "Message/add",
                  data: $(form).serialize(),
                  dataType: 'json'
              }).done(function (response) {
                  if (response.success == true) {
                      $('#get_in_touch_btn').val(oldval);
                      $('#get_in_touch_btn').prop('disabled', false);
 
                      $('#res_message').html(response.msg);
                      $('#res_message').show();
                      $('#msg_div').removeClass('d-none');
 
                      document.getElementById("getInTouchForm").reset(); 
                      setTimeout(function(){
                      $('#res_message').hide();
                      $('#msg_div').hide();
                      },10000);
                   
                  } else {
                      $('#get_in_touch_btn').val(oldval);
                      $('#get_in_touch_btn').prop('disabled', false);
                     
                  }
              });
              return false;
          }
 
      });
 
  }
</script>

</html>
