<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script type="text/javascript" src="ckeditor.js"></script>
<script type="text/javascript" src="advocate/assests/js/tiny_mce.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<!-- <script type="text/javascript">
  tinyMCE.init({
  theme : "advanced",
  theme_advanced_toolbar_location : "top",
  theme_advanced_toolbar_align : "left",
  mode : "exact",
  elements : "message",
});
</script> -->
<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
  <script>tinymce.init({ selector:'textarea' });</script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#reg_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

<script type="text/javascript">
  $(document).ready(function() {
  $('#permit_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>
<script type="text/javascript">
  $(document).ready(function() {
  $('#puc_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
</script>
 <script type="text/javascript">
  $(document).ready(function() {
  $('#fitness_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#insu_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#tax_rcp_exp_date').datetimepicker({
    format: 'D-MM-YYYY',
 }); 
});
 </script>

 <script type="text/javascript">
  $(document).ready(function() {
  $('#mfg_date').datetimepicker({
    format: 'MM-YYYY',
 }); 
});
 </script>
 <div class="row">
    <div class="col-md-12">
        <div class="box box-info" style="border-top-color: #605ca8">
            <div class="box-header with-border">
                <h3 class="box-title">Message</h3>
            </div>
            <?php echo form_open('Message/add'); ?>
            <div class="box-body">
              <div class="row clearfix">
 <div class="col-md-6">
                        <label for="e_id" class="control-label"> Employee
                            <span class="text-danger">*</span></label>

   <div class="form-group">
                                   <select   name="ename" id="e_id" class="form-control">
                                         <option value="">Select Employee</option>
                                              <?php
                                                   foreach($all_employees as $employee)
                                                  {

                                                  $selected = ($employee['ename'] == $this->input->post('ename')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$employee['e_id'].'" '.$selected.'>'.$employee['ename'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
                               <span class="text-danger"><?php echo form_error('ename');?></span>
                             </div>
                           </div>
                            <div class="col-md-6">
                        <label for="cl_id" class="control-label"> Client
                            <span class="text-danger">*</span></label>

   <div class="form-group">
                                   <select   name="name" id="cl_id" class="form-control">
                                         <option value="">Select case</option>
                                              <?php
                                                  foreach($all_client as $client)
                                                  {

                                                  $selected = ($client['name'] == $this->input->post('name')) ? ' selected="selected"' : "";

                                                  echo '<option value="'.$client['cl_id'].'" '.$selected.'>'.$client['name'].'</option>';
                                                  
                                                   }
                                              ?>
                                  </select>
                               <span class="text-danger"><?php echo form_error('name');?></span>
                             </div>

  
  <div class="col-sm-12">
            <label for="message" class="control-label">
         
            <span class="text-danger"></span></label>
            <div class="form-group">
              <textarea name="message" rows="5" value="<?php echo $this->input->post('message'); ?>" class="form-control" id="message"></textarea>

              <span class="text-danger"><?php echo form_error('message');?></span>
            </div>
          </div>
         <!--  <div class="row clearfix">
          <div class="col-md-6">
            <label for="message" class="control-label"> template
            <span class="text-danger">*</span></label>
            <div class="form-group">
              <textarea id="message" cols="50" rows="5"></textarea>
              
              <span class="text-danger"><?php echo form_error('message');?></span> -->


            <div class="box-footer">
              <button type="submit" class="btn btn-success">
                <i class="fa fa-check"></i> Save
              </button>
            </div></div></div>
</div></div></div></div></div></div>
