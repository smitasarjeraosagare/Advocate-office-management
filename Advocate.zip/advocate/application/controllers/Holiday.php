<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Holiday extends Base_Controller{
    function __construct()
    {
        parent::__construct();
        $this->authenticate();

        $this->load->model('Holiday_Model');
        $this->load->model('Location_Model');
         $this->load->model('Courtcategory_Model');
    } 
/*index function starts*/

    function index()
    {
       $data['holiday'] = $this->Holiday_Model->get_all_Holidays();
        $data['_view'] = 'Holiday/index';
        $this->load->view('layouts/main',$data);
    }
    function Calendar()
    {
       $data['holiday'] = $this->Holiday_Model->get_all_Holidays();
        $data['_view'] = 'Holiday/calender';
        $this->load->view('layouts/main',$data);
    }
function jan()
    {
       $data['holiday'] = $this->Holiday_Model->get_january();
        $this->load->view('Holiday/try',$data);
        
  }
  function feb()
    {
        $data['holiday'] = $this->Holiday_Model->get_feb();
      $this->load->view('Holiday/try',$data);
  }
function mar()
    {
       $data['holiday'] = $this->Holiday_Model->get_march();
       $this->load->view('Holiday/try',$data);
       
  }
 function apr()
    {
       $data['holiday'] = $this->Holiday_Model->get_april();
        $this->load->view('Holiday/try',$data);
      
  }
 function may()
    {
       $data['holiday'] = $this->Holiday_Model->get_may();
        $this->load->view('Holiday/try',$data);
       
  }
  function jun()
    {
       $data['holiday'] = $this->Holiday_Model->get_june();
        $this->load->view('Holiday/try',$data);
       
  }
  function jul()
    {
       $data['holiday'] = $this->Holiday_Model->get_july();
       $this->load->view('Holiday/try',$data);
        
  }
  function aug()
    {
       $data['holiday'] = $this->Holiday_Model->get_august();
        $this->load->view('Holiday/try',$data);
       
  }
  function sep()
    {
       $data['holiday'] = $this->Holiday_Model->get_sep();
       $this->load->view('Holiday/try',$data);
       
  }
  function oct()
    {
       $data['holiday'] = $this->Holiday_Model->get_oct();
       $this->load->view('Holiday/try',$data);
  }
  function nov()
    {
       $data['holiday'] = $this->Holiday_Model->get_nov();
       $this->load->view('Holiday/try',$data);
  }
  function dec()
    {
       $data['holiday'] = $this->Holiday_Model->get_dec();
      $this->load->view('Holiday/try',$data);
  }
    /*end of index function*/
    function add()
    {   
        $this->load->library('form_validation');
          $this->form_validation->set_rules('name','Name','required|max_length[100]');
         $this->form_validation->set_rules('date','Date','required|max_length[100]');
          $this->form_validation->set_rules('month','Month','required|max_length[100]');
           $this->form_validation->set_rules('year','Year','required|max_length[100]');
        if($this->form_validation->run())     
        {   
            $params = array(
                    'name' => $this->input->post('name'),
                    'date' => $this->input->post('date'),
                   'month' => $this->input->post('month'),
                   'year' => $this->input->post('year')         
                    );
            $ho_id = $this->Holiday_Model->add_Holiday($params);
            redirect('Holiday/index');
        }
        else
        {            
            $data['_view'] = 'Holiday/add';
            $this->load->view('layouts/main',$data);
        }
    }  
    /*end add function*/ 

      function remove($ho_id)
    {
        $holiday = $this->Holiday_Model->get_Holiday($ho_id);

        // check if the customer exists before trying to delete it
        if(isset($holiday['ho_id']))
        {
            $this->Holiday_Model->delete_Holiday($ho_id);
            redirect('holiday/index');
        }
        else
            show_error('The holiday you are trying to delete does not exist.');
    }
   

}
?>