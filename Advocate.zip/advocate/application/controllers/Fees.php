<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Fees extends Base_Controller{
    function __construct()
    {
        parent::__construct();
               $this->authenticate();

        $this->load->model('Fees_Model');
        $this->load->model('Cases_Model'); 
        $this->load->model('Payment_Model');
        $this->load->model('Tax_Model');
        $this->load->helper('download');
    force_download('/path/to/pdf.pdf', NULL);
        
    } 
/*index function starts*/

    function index()
    {
          /*$data['cases'] = $this->Cases_Model->get_all_Case();*/
           $data['cases'] = $this->Fees_Model->get_all_Fee();
        
        $data['_view'] = 'Cases/fees';
        
        $this->load->view('layouts/main',$data);
         
       
  }
      function add($c_id)
    {   
        
        $data['cases'] = $this->Fees_Model->get_Fees($c_id);
        
        if(isset($data['cases']['c_id']))
        {
            
          $data['all_payment'] = $this->Payment_Model->get_all_Payment();
         $data['all_tax'] = $this->Tax_Model->get_all_tax();

          $this->load->library('form_validation');
        $this->form_validation->set_rules('pay','payment','max_length[100]');
        $this->form_validation->set_rules('tax_name','Tax','max_length[100]');
        $this->form_validation->set_rules('amount','Amount','max_length[100]');
        $this->form_validation->set_rules('total','Total ','max_length[100]');
       
            if($this->form_validation->run())     
            {   
                  $params = array(
                    'p_id' => $this->input->post('pay'),

                    'tax_id' => $this->input->post('tax_name'),
                    'date' => date('Y-m-d', strtotime($this->input->post('date'))),
                    'amount' => $this->input->post('amount'),
                    'total' => $this->input->post('total')
            );

                $this->Cases_Model->update_Cases($c_id,$params);            
                redirect('cases/index');
            }
            else
            {
                $data['_view'] = 'cases/fees';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The cases you are trying to edit does not exist.');
    }  
     function view($f_id)
    {   
         
        $data['fees'] = $this->Cases_Model->get_Fees($f_id);
        if(isset($data['fees']['f_id']))
        {
            $data['_view'] = 'cases/invoice';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The cases does not exist.');
    } 
  function invoice()
    {
          $data['cases'] = $this->Cases_Model->get_all_Case();
      
        $data['_view'] = 'Cases/invoice';
        
        $this->load->view('layouts/main',$data);
         
       
  }
  function file_download()
    {
        $file_name= $this->input->get('file_name');

        $this->load->helper('download');
        $data = file_get_contents($file_name);
        $name = 'Download.pdf'; // custom file name for your download

        force_download($name, $data);
        //force_download($file_name, NULL); will get the file name for you
}
/*function file_download($c_id)
    {   
         
        $data['cases'] = $this->Cases_Model->get_Cases($c_id);
        if(isset($data['cases']['c_id']))
        {
            $file_name= $this->input->get('file_name');

        $this->load->helper('download');
        $data = file_get_contents($file_name);
        $name = 'Download.pdf'; // custom file name for your download

        force_download($name, $data);
        }
        else
            show_error('The cases does not exist.');
    } */
}
?>