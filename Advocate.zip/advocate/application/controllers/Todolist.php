<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Todolist extends Base_Controller{
    function __construct()
    {
        parent::__construct();
        $this->authenticate();
        $this->load->model('Todolist_Model');
        /* $this->load->model('Star_Model');*/
    } 
/*index function starts*/
	function index()
    {
        $data['todolist'] = $this->Todolist_Model->get_all_todolists();
        
        $data['_view'] = 'Todolist/index'; 
        
        $this->load->view('layouts/main',$data);
         
 
 
 }/*end of index function*/
    function add()
    {   

       
        $this->load->library('form_validation');
        $this->form_validation->set_rules('name','Title','required|max_length[100]');
        $this->form_validation->set_rules('des','Description','required|max_length[100]');
        $this->form_validation->set_rules('ndat','Next Date','required|max_length[100]');
        
        if($this->form_validation->run())     
        {   
            $params = array(
                                

                    
                    'name' => $this->input->post('name'),
                    'des' => $this->input->post('des'),
                    'ndat' => date('Y-m-d', strtotime($this->input->post('ndat'))),
                   
                     
          
            );
            
            $t_id = $this->Todolist_Model->add_todolist($params);
            redirect('Todolist/index');
        }
        else
        {            
            $data['_view'] = 'Todolist/add';
            $this->load->view('layouts/main',$data);
        }
    }  
    /*end add function*/ 
 function edit($t_id)
    {   
        
        // check if the customer exists before trying to edit it
        $data['todolist'] = $this->Todolist_Model->get_todolist($t_id);
        
        if(isset($data['todolist']['t_id']))
        {
             
        $this->load->library('form_validation');
        $this->form_validation->set_rules('name','Title','required|max_length[100]');
        $this->form_validation->set_rules('des','Description','required|max_length[100]');
        $this->form_validation->set_rules('ndat','Next Date','required|max_length[100]');
       
        
            if($this->form_validation->run())     
            {   
               $params = array(
                       'name' => $this->input->post('name'),
                    'des' => $this->input->post('des'),
                    'ndat' => date('Y-m-d', strtotime($this->input->post('ndat'))),
                   
                     

                );

                $this->Todolist_Model->update_todolist($t_id,$params);            
                redirect('todolist/index');
            }
            else
            {
                $data['_view'] = 'Todolist/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The todolist you are trying to edit does not exist.');
    } 


    function view($t_id)
    {   
         
        $data['todolist'] = $this->Todolist_Model->get_todolist($t_id);
        if(isset($data['todolist']['t_id']))
        {
            $data['_view'] = 'Todolist/view';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The todolist does not exist.');
    } 

    /*
     * Deleting todolist
     */
    function remove($t_id)
    {
        $todolist = $this->Todolist_Model->get_todolist($t_id);

        // check if the customer exists before trying to delete it
        if(isset($todolist['t_id']))
        {
            $this->Todolist_Model->delete_todolist($t_id);
            redirect('todolist/index');
        }
        else
            show_error('The todolist you are trying to delete does not exist.');
    }
    
/*
            function archived($t_id)
            {   
        
        // check if the customer exists before trying to edit it
        $data['todolist'] = $this->todolist_Model->get_todolist($t_id);
        
        if(isset($data['todolist']['t_id']))
        {
             $this->load->library('form_validation');
        $this->form_validation->set_rules('notes','Company Name','required|max_length[100]');
        $this->form_validation->set_rules('cdate','Closing Date','required|max_length[100]');
           if($this->form_validation->run())     
            {   
               $params = array(
                    'note' => $this->input->post('note'),
                    'cdate' => date('Y-m-d', strtotime($this->input->post('cdate'))),  );

                $this->todolist_Model->add_archive($t_id,$params);            
                redirect('todolist/index');
            }
            else
            {
                $data['_view'] = 'todolist/archived';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The todolist you are trying to edit does not exist.');
    } 
*/

   
}
?>