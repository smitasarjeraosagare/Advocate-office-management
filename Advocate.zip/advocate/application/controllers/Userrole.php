<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Userrole extends Base_Controller{
    function __construct()
    {
        parent::__construct();
       $this->authenticate();
        $this->load->model('Userrole_Model');
        $this->load->model('Star_Model');
    } 
/*index function starts*/

    function index()
    {
        $data['userrole'] = $this->Userrole_Model->get_all_Userrole();
        $data['_view'] = 'Userrole/index';
        $this->load->view('layouts/main',$data);
  }

 
 
    /*end of index function*/
    function add()
    {   

       
        $this->load->library('form_validation');

        $this->form_validation->set_rules('uename','Userrole','required|max_length[100]');
        $this->form_validation->set_rules('des','Userrole','required|max_length[100]');
        if($this->form_validation->run())     
        {   
            $params = array(
                                

                    'uename' => $this->input->post('uename'),
                     'des' => $this->input->post('des')

                    );
            
            $ur_id = $this->Userrole_Model->add_Userrole($params);
            redirect('Userrole/index');
        }
        else
        {            
            $data['_view'] = 'Userrole/add';
            $this->load->view('layouts/main',$data);
        }
    }  
    /*end add function*/ 

}
?>