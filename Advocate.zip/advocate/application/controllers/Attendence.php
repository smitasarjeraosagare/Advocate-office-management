<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Attendence extends Base_Controller{
    function __construct()
    {
        parent::__construct();
       
        $this->load->model('Attendence_Model');
        $this->load->model('Employees_Model');
         $this->load->model('Cases_Model');
         $this->load->model('Clients_Model');
         $this->load->model('Employees_Model');
        $this->load->model('Fees_Model');
         $this->load->model('Act_Model');
         $this->load->model('Casecategory_Model');
         $this->load->model('Courtcategory_Model');
         $this->load->model('Court_Model');
         $this->load->model('Casestage_Model');
         $this->load->model('Payment_Model');
         $this->load->model('Tax_Model');
         $this->load->model('Location_Model');
    } 
/*add function starts*/
 function index()
    {
        $data['attendence'] = $this->Attendence_Model->get_all_Attendence();
        
       $data['cases'] = $this->Cases_Model->get_all_Case();
         $data['all_clients'] = $this->Clients_Model->get_all_Clients();
         $data['all_location'] = $this->Location_Model->get_all_Locations();
        $data['all_casecategory'] = $this->Casecategory_Model->get_all_Casecategory();
         $data['all_casestage'] = $this->Casestage_Model->get_all_Casestage();
        $data['all_act'] = $this->Act_Model->get_all_Act();
        $data['all_court'] = $this->Court_Model->get_all_Court();
        $data['all_courtcat'] = $this->Courtcategory_Model->get_all_Courtcategory();
        $data['all_employees'] = $this->Employees_Model->get_all_Employees();
        $data['cases'] = $this->Cases_Model->get_all_Case();
        $data['_view'] = 'Attendence/index';
        
        $this->load->view('layouts/main',$data);
         
        /*$query['star'] = $this->Star_Model->getstar();
        $query['star'] = null;
        if($query){
        $data['star'] =  $query;*/
  }


    function add()
    {
        $data['all_employees'] = $this->Employees_Model->get_all_Employees();
         $data['attendence'] = $this->Attendence_Model->get_all_Attendences();

        $data['_view'] = 'Attendence/add';
        $this->load->view('layouts/main',$data);
        $this->load->library('form_validation');
        $this->form_validation->set_rules('ename','Employee');
        $this->form_validation->set_rules('datefrom','Date from','max_length[100]');
        $this->form_validation->set_rules('dateto','Date to','max_length[100]');
        if($this->form_validation->run())     
        {   
            $params = array(
                            'e_id' => $this->input->post('ename'),    
                    'datefrom' => $this->input->post('datefrom'),
                    'dateto' => $this->input->post('dateto')
                    );
            
            $Attendence_id = $this->Attendence_Model->add_Attendence($params);
            redirect('Attendence/add');
        }
        else
        {            
            $data['_view'] = 'Attendence/add';
            $this->load->view('layouts/main',$data);
        }
  }

 
 
    /*end of add function*/
   /* function add()
    {   

  
$data['employee'] = $this->Employees_Model->get_all_Employees();    
$this->load->library('form_validation');
$this->form_validation->set_rules('ename','Attendence','required|max_length[100]');
        $this->form_validation->set_rules('datefrom','Attendence','required|max_length[100]');
        $this->form_validation->set_rules('dateto','Attendence','required|max_length[100]');
        if($this->form_validation->run())     
        {   
            $params = array(
                                
'e-id' => $this->input->post('ename'),
                    'datefrom' => $this->input->post('datefrom'),
                    'dateto' => $this->input->post('dateto')
                    );
            
            $Attendence_id = $this->Attendence_Model->add_Attendence($params);
            redirect('Attendence/add');
        }
        else
        {            
            $data['_view'] = 'Attendence/add';
            $this->load->view('layouts/main',$data);
        }
    }  */
    /*end add function*/ 
 function edit($at_id)
    {   
        
        // check if the customer exists before trying to edit it
        $data['attendence'] = $this->attendence_Model->get_attendences($at_id);
        
        if(isset($data['attendence']['at_id']))
        {
            $this->load->library('form_validation');
                

        $this->form_validation->set_rules('leav','attendence','required|max_length[100]');
          $this->form_validation->set_rules('des','description','required|max_length[100]');
       
        
            if($this->form_validation->run())     
            {   
                $params = array(
                     
                    'leav' => $this->input->post('leav'),
                    'des' => $this->input->post('des')
                );

                $this->attendence_Model->update_attendence($at_id,$params);            
                redirect('attendence/add');
            }
            else
            {
                $data['_view'] = 'attendence/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The attendence you are trying to edit does not exist.');
    }  
      function remove($at_id)
    {
        $attendence = $this->attendence_Model->get_attendences($at_id);

        // check if the customer exists before trying to delete it
        if(isset($attendence['at_id']))
        {
            $this->attendence_Model->delete_attendence($at_id);
            redirect('attendence/add');
        }
        else
            show_error('The attendence you are trying to delete does not exist.');
    }
    function view($at_id)
    {   
         
        $data['attendence'] = $this->attendence_Model->get_attendences($at_id);
        if(isset($data['attendence']['at_id']))
        {
            $data['_view'] = 'attendence/view';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The attendence does not exist.');
    } 

}
?>