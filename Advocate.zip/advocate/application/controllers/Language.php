<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Language extends Base_Controller{
    function __construct()
    {
        parent::__construct();
        $this->authenticate();

        $this->load->model('Language_Model');
        /* $this->load->model('Star_Model');*/
    } 
/*index function starts*/
    function index()
    {
        $data['language'] = $this->Language_Model->get_all_Language();
       
        $data['_view'] = 'Language/add'; 
        
        $this->load->view('layouts/main',$data);
         
 
 
 }/*end of index function*/
    function add()
    {   
        $this->load->library('form_validation');
        $this->form_validation->set_rules('name','Language ','required|max_length[100]');
         $this->form_validation->set_rules('photo','Icon','max_length[100]');
        $this->form_validation->set_rules('dir','Direction','required|max_length[100]');
        
        if($this->form_validation->run())     
        {   
            $params = array(
                    'name' => $this->input->post('name'),
                      'photo' => $this->input->post('photo'),
                    'dir' => $this->input->post('dir')
                    
            );
            
            $lan_id = $this->Language_Model->add_Language($params);
            redirect('Language/add');
        }
        else
        {            
            $data['_view'] = 'Language/add';
            $this->load->view('layouts/main',$data);
        }
    }  
    /*end add function*/ 



    function view($lan_id)
    {   
         
        $data['Language'] = $this->Language_model->get_Language($lan_id);
        if(isset($data['Language']['lan_id']))
        {
            $data['_view'] = 'Language/view';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The Language does not exist.');
    } 

    /*
     * Deleting Language
     */
    function remove($lan_id)
    {
        $Language = $this->Language_model->get_Language($lan_id);

        // check if the customer exists before trying to delete it
        if(isset($Language['lan_id']))
        {
            $this->Language_model->delete_Language($lan_id);
            redirect('Language/index');
        }
        else
            show_error('The Language you are trying to delete does not exist.');
    }
    
/*
            function archived($lan_id)
            {   
        
        // check if the customer exists before trying to edit it
        $data['Language'] = $this->Language_model->get_Language($lan_id);
        
        if(isset($data['Language']['lan_id']))
        {
             $this->load->library('form_validation');
        $this->form_validation->set_rules('notes','Company Name','required|max_length[100]');
        $this->form_validation->set_rules('cdate','Closing Date','required|max_length[100]');
           if($this->form_validation->run())     
            {   
               $params = array(
                    'note' => $this->input->post('note'),
                    'cdate' => date('Y-m-d', strtotime($this->input->post('cdate'))),  );

                $this->Language_model->add_archive($lan_id,$params);            
                redirect('Language/index');
            }
            else
            {
                $data['_view'] = 'Language/archived';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The Language you are trying to edit does not exist.');
    } 
*/

   
}
?>