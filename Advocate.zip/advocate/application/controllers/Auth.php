<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->model('User_Model');
         $this->load->model('Clients_Model');
          $this->load->model('Employees_Model');
    }
 
    function index() {
        if($this->session->userdata('user_id')) {
            redirect('dashboard');
        }
        else {
            redirect('auth/login');
        }
    }

    function login() {
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|trim');
        $this->form_validation->set_rules('password', 'Password', 'required|trim');

        if($this->form_validation->run()) {
            $user = $this->User_Model->login($this->input->post('email'), $this->input->post('password'));

            if($user['rc']) {
                $user_data = array(
                    "user_id" => $user['data']['id'],
                    "username" => $user['data']['username']
                  
                );
                $this->session->set_userdata($user_data);

                redirect('dashboard/admin');
            }
            else {
                $this->session->set_flashdata("error", "Email or password is wrong");
                redirect('auth/login');
            }
        }
        else {
            $data = array();
            $this->load->view('Admin/login', $data);
        }
    }
     function login1() {
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|trim');
        $this->form_validation->set_rules('password', 'Password', 'required|trim');

        if($this->form_validation->run()) {
            $client = $this->Clients_Model->login($this->input->post('email'), $this->input->post('password'));

            if($client['rc']) {
                $user_data = array(
                    "user_id" => $client['data']['cl_id'],
                    "username" => $client['data']['username']
                  
                );
                $this->session->set_userdata($user_data);

                redirect('dashboard/client');
            }
            else {
                $this->session->set_flashdata("error", "Email or password is wrong");
                redirect('auth/login1');
            }
        }
        else {
            $data = array();
            $this->load->view('Clients/login', $data);
        }
    }
    function login2() {
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|trim');
        $this->form_validation->set_rules('password', 'Password', 'required|trim');

        if($this->form_validation->run()) {
            $employee = $this->Employees_Model->login($this->input->post('email'), $this->input->post('password'));

            if($employee['rc']) {
                $user_data = array(
                    "user_id" => $employee['data']['e_id'],
                    "username" => $employee['data']['username']
                  
                );
                $this->session->set_userdata($user_data);

                redirect('dashboard/employee');
            }
            else {
                $this->session->set_flashdata("error", "Email or password is wrong");
                redirect('Auth/login2');
            }
        }
        else {
            $data = array();
            $this->load->view('Employees/login', $data);
        }
    }


    function logout() {
        $this->session->unset_userdata('user_id');
        $this->session->unset_userdata('username');

    
    unset($_SESSION['role']);

        redirect('auth/login');
    }
}