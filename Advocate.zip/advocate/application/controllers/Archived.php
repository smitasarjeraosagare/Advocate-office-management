<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Archived extends Base_Controller{
    function __construct()
    {
        parent::__construct();
    $this->authenticate();
 $this->load->model('Cases_Model');
         $this->load->model('Clients_Model');
         $this->load->model('Employees_Model');
        $this->load->model('Fees_Model');
         $this->load->model('Act_Model');
         $this->load->model('Casecategory_Model');
         $this->load->model('Courtcategory_Model');
         $this->load->model('Court_Model');
         $this->load->model('Casestage_Model');
         $this->load->model('Payment_Model');
         $this->load->model('Tax_Model');
         $this->load->model('Location_Model');
        $this->load->model('Cases_Model');
        $this->load->model('Archived_Model');
        /* $this->load->model('Star_Model');*/
    } 
/*index function starts*/
    function index()
    {
       $data['cases'] = $this->Cases_Model->get_all_Case();
         $data['all_clients'] = $this->Clients_Model->get_all_Clients();
         $data['all_location'] = $this->Location_Model->get_all_Locations();
        $data['all_casecategory'] = $this->Casecategory_Model->get_all_Casecategory();
         $data['all_casestage'] = $this->Casestage_Model->get_all_Casestage();
        $data['all_act'] = $this->Act_Model->get_all_Act();
        $data['all_court'] = $this->Court_Model->get_all_Court();
        $data['all_courtcat'] = $this->Courtcategory_Model->get_all_Courtcategory();
        $data['all_employees'] = $this->Employees_Model->get_all_Employees();
        $data['cases'] = $this->Cases_Model->get_all_Case();
 $data['cases'] = $this->Cases_Model->get_archived();
        
        $data['_view'] = 'Archived/index';
        $this->load->view('layouts/main',$data);
        }
        function add($c_id)
    {   
        
        $data['cases'] = $this->Cases_Model->get_Cases($c_id);
        
        if(isset($data['cases']['c_id']))
        {

        $this->load->library('form_validation');

         $this->form_validation->set_rules('note','Notes','required|max_length[100]');
        $this->form_validation->set_rules('cdate','Closing Date','required|max_length[100]');
        
            if($this->form_validation->run())     
            {   
                  $params = array(
                                

                   'note' => $this->input->post('note'),
                    'cdate' => date('Y-m-d', strtotime($this->input->post('cdate'))),
                     
          
            );

               $this->Cases_Model->update_Cases($c_id,$params);            
                redirect('archived/index');
            }
            else
            {
               $data['_view'] = 'archived/add';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The cases you are trying to edit does not exist.');
    }
 
   
}

?>