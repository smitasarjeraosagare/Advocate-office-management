<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Leavetype extends Base_Controller{
    function __construct()
    {
        parent::__construct();
        $this->authenticate();

        $this->load->model('Leavetype_Model');
        $this->load->model('Star_Model');
    } 
/*index function starts*/

    function index()
    {
        $data['leavetype'] = $this->Leavetype_Model->get_all_Leavetype();
        $data['_view'] = 'Leavetype/index';
        $this->load->view('layouts/main',$data);
  }
 
    /*end of index function*/
    function add()
    {   

       
        $this->load->library('form_validation');

        $this->form_validation->set_rules('leav','Leavetype','required|max_length[100]');
          $this->form_validation->set_rules('des','description','required|max_length[100]');
        
        if($this->form_validation->run())     
        {   
            $params = array(
                                

                    'leav' => $this->input->post('leav'),
                    'des' => $this->input->post('des')
                    );
            
            $Leavetype_id = $this->Leavetype_Model->add_Leavetype($params);
            redirect('Leavetype/index');
        }
        else
        {            
            $data['_view'] = 'Leavetype/add';
            $this->load->view('layouts/main',$data);
        }
    }  
    /*end add function*/ 
     function edit($le_id)
    {   
        
        // check if the customer exists before trying to edit it
        $data['leavetype'] = $this->Leavetype_Model->get_Leavetype($le_id);
        
        if(isset($data['leavetype']['le_id']))
        {
            $this->load->library('form_validation');
                

        $this->form_validation->set_rules('leav','Leavetype','required|max_length[100]');
          $this->form_validation->set_rules('des','description','required|max_length[100]');
       
        
            if($this->form_validation->run())     
            {   
                $params = array(
                     
                    'leav' => $this->input->post('leav'),
                    'des' => $this->input->post('des')
                );

                $this->Leavetype_Model->update_Leavetype($le_id,$params);            
                redirect('leavetype/index');
            }
            else
            {
                $data['_view'] = 'leavetype/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The leavetype you are trying to edit does not exist.');
    }  
      function remove($le_id)
    {
        $leavetype = $this->Leavetype_Model->get_leavetypes($le_id);

        // check if the customer exists before trying to delete it
        if(isset($leavetype['le_id']))
        {
            $this->leavetype_Model->delete_leavetype($le_id);
            redirect('leavetype/index');
        }
        else
            show_error('The leavetype you are trying to delete does not exist.');
    }
    function view($le_id)
    {   
         
        $data['leavetype'] = $this->leavetype_Model->get_leavetypes($le_id);
        if(isset($data['leavetype']['le_id']))
        {
            $data['_view'] = 'leavetype/view';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The leavetype does not exist.');
    } 


}
?>