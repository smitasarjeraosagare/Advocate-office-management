<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Notice extends Base_Controller{
    function __construct()
    {
        parent::__construct();
        $this->authenticate();

        $this->load->model('Notice_Model');
        
    } 
/*index function starts*/

    function index()
    {
        $data['notice'] = $this->Notice_Model->get_all_Notice();
        $data['_view'] = 'Notice/index';
        $this->load->view('layouts/main',$data);
  }

 
 
    /*end of index function*/
    function add()
    {   
        $this->load->library('form_validation');
        $this->form_validation->set_rules('title','Case Title','max_length[100]');
        $this->form_validation->set_rules('des','Case No.');
        $this->form_validation->set_rules('nodate','Filling Date','max_length[100]');
        if($this->form_validation->run())     
        {   
            $params = array(
                                

                    'title' => $this->input->post('title'),
                    'des' => $this->input->post('des'),
                    'nodate' => date('Y-m-d', strtotime($this->input->post('nodate'))),
                   
          
            );
            
            $n_id = $this->Notice_Model->add_Notice($params);
            redirect('Notice/index');
        }
        else
        {            
            $data['_view'] = 'Notice/add';
            $this->load->view('layouts/main',$data);
        }
    }  
    /*end add function*/ 
     function edit($n_id)
    {   
        
        // check if the customer exists before trying to edit it
        $data['notice'] = $this->Notice_Model->get_Notice($n_id);
        
        if(isset($data['notice']['n_id']))
        {
            $this->load->library('form_validation');
       $this->load->library('form_validation');
        $this->form_validation->set_rules('title','Case Title','max_length[100]');
        $this->form_validation->set_rules('des','Case No.');
        $this->form_validation->set_rules('nodate','Filling Date','max_length[100]');
       
        
            if($this->form_validation->run())     
            {   
                $params = array(
                       'title' => $this->input->post('title'),
                    'des' => $this->input->post('des'),
                    'nodate' => date('Y-m-d', strtotime($this->input->post('nodate'))),
                );

                $this->Notice_Model->update_Notice($n_id,$params);            
                redirect('notice/index');
            }
            else
            {
                $data['_view'] = 'notice/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The notice you are trying to edit does not exist.');
    }  
      function remove($n_id)
    {
        $notice = $this->notice_Model->get_notices($n_id);

        // check if the customer exists before trying to delete it
        if(isset($notice['n_id']))
        {
            $this->notice_Model->delete_notice($n_id);
            redirect('notice/index');
        }
        else
            show_error('The notice you are trying to delete does not exist.');
    }
    function view($n_id)
    {   
         
        $data['notice'] = $this->notice_Model->get_notices($n_id);
        if(isset($data['notice']['n_id']))
        {
            $data['_view'] = 'notice/view';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The notice does not exist.');
    } 
}


?>