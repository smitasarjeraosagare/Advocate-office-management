<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Star extends Base_Controller{
    function __construct()
    {
        parent::__construct();
        $this->authenticate();
        $this->load->model('Star_Model');
        /* $this->load->model('Star_Model');*/
    } 
/*index function starts*/
    function index()
    {
        $data['star'] = $this->Star_Model->get_all_stars();
        
        $data['_view'] = 'Star/index'; 
        
        $this->load->view('layouts/main',$data);
        
        
  
function add() {
    $data['star'] = $this->Star_Model->add_star();
     $data['_view'] = 'Star/index'; 
   /* $sid = $this->insert_post();
    $data = array(
        'sid' => $sid,
        //  ........ other data
    );
    $this->db->insert('star', $data);*/
}   
 }

}
?>