<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Aleave extends Base_Controller{
    function __construct()
    {
        parent::__construct();
        $this->authenticate();
        $this->load->model('Aleave_Model');
        $this->load->model('Leavetype_Model');
         $this->load->model('Cases_Model');
         $this->load->model('Clients_Model');
         $this->load->model('Employees_Model');
        $this->load->model('Fees_Model');
         $this->load->model('Act_Model');
         $this->load->model('Casecategory_Model');
         $this->load->model('Courtcategory_Model');
         $this->load->model('Court_Model');
         $this->load->model('Casestage_Model');
         $this->load->model('Payment_Model');
         $this->load->model('Tax_Model');
         $this->load->model('Location_Model');
    } 
/*index function starts*/

    function index()
     $data['cases'] = $this->Cases_Model->get_all_Case();
         $data['all_clients'] = $this->Clients_Model->get_all_Clients();
         $data['all_location'] = $this->Location_Model->get_all_Locations();
        $data['all_casecategory'] = $this->Casecategory_Model->get_all_Casecategory();
         $data['all_casestage'] = $this->Casestage_Model->get_all_Casestage();
        $data['all_act'] = $this->Act_Model->get_all_Act();
        $data['all_court'] = $this->Court_Model->get_all_Court();
        $data['all_courtcat'] = $this->Courtcategory_Model->get_all_Courtcategory();
        $data['all_employees'] = $this->Employees_Model->get_all_Employees();
        $data['cases'] = $this->Cases_Model->get_all_Case();
    { $data['leavetype'] = $this->Leavetype_Model->get_all_Leavetype();
        $data['aleave'] = $this->Aleave_Model->get_all_Aleaves();
        $data['_view'] = 'Aleave/index';
        $this->load->view('layouts/main',$data);
  }
 
    /*end of index function*/
    function add()
    {    $data['all_leavetype'] = $this->Leavetype_Model->get_all_Leavetype();
        $data['aleave'] = $this->Aleave_Model->get_all_Aleaves();
      $data['leavetype'] = $this->Leavetype_Model->get_all_Leavetype();
        $this->load->library('form_validation');

        $this->form_validation->set_rules('date','Date','max_length[100]');
        $this->form_validation->set_rules('leav','Leave','max_length[100]');
          $this->form_validation->set_rules('rea','reason','max_length[100]');
        
        if($this->form_validation->run())     
        {   
            $params = array(
                                
                    'date' => date('Y-m-d', strtotime($this->input->post('date'))),
                    'le_id' => $this->input->post('leav'),
                    'rea' => $this->input->post('rea')
                    );
            
            $al_id = $this->Aleave_Model->add_Aleave($params);
            redirect('dashboard');
        }
        else
        {            
            $data['_view'] = 'Aleave/add';
            $this->load->view('layouts/main',$data);
        }
    }  
    /*end add function*/ 
     function edit($al_id)
    {   
        
        // check if the customer exists before trying to edit it
        $data['Aleave'] = $this->Aleave_Model->get_Aleave($al_id);
        
        if(isset($data['Aleave']['al_id']))
        {
            $this->load->library('form_validation');
                

        $this->form_validation->set_rules('leav','Aleave','required|max_length[100]');
          $this->form_validation->set_rules('rea','reacription','required|max_length[100]');
       
        
            if($this->form_validation->run())     
            {   
                $params = array(
                     
                    'leav' => $this->input->post('leav'),
                    'rea' => $this->input->post('rea')
                );

                $this->Aleave_Model->update_Aleave($al_id,$params);            
                redirect('Aleave/index');
            }
            else
            {
                $data['_view'] = 'Aleave/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The Aleave you are trying to edit does not exist.');
    }  
      function remove($al_id)
    {
        $Aleave = $this->Aleave_Model->get_Aleaves($al_id);

        // check if the customer exists before trying to delete it
        if(isset($Aleave['al_id']))
        {
            $this->Aleave_Model->delete_Aleaves($al_id);
            redirect('Aleave/index');
        }
        else
            show_error('The Aleave you are trying to delete does not exist.');
    }
    function view($al_id)
    {   
         
        $data['Aleave'] = $this->Aleave_Model->get_Aleaves($al_id);
        if(isset($data['Aleave']['al_id']))
        {
            $data['_view'] = 'Aleave/view';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The Aleave does not exist.');
    } 
     function approve($al_id)
    {
        $data['aleave'] = $this->Aleave_Model->get_Aleaves($al_id);
        $data['_view'] = 'Aleave/index';
        $this->load->view('layouts/main',$data);
  }


}
?>