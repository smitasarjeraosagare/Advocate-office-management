<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hear extends Base_Controller{
    function __construct()
    {
        parent::__construct();
         $this->authenticate();
        $this->load->model('Cases_Model');
        /* $this->load->model('Star_Model');*/
    } 
/*index function starts*/
	function index($c_id)
    {
        $data['cases'] = $this->Cases_Model->get_Cases($c_id);
        
        $data['_view'] = 'Cases/hear'; 
        
        $this->load->view('layouts/main',$data);
         
 
 }
  function add($c_id)
    {   
        
       $data['cases'] = $this->Cases_Model->get_Cases($c_id);
        
        if(isset($data['cases']['c_id']))
        {

        $this->load->library('form_validation');

         $this->form_validation->set_rules('ndate','Next Date','required|max_length[100]');
        $this->form_validation->set_rules('ldate','Last Date','required|max_length[100]');
         $this->form_validation->set_rules('hnote','Note','required|max_length[100]');
       
        
           if($this->form_validation->run())     
        {   

  $config['upload_path']          = './image/';
                $config['allowed_types']        = 'gif|jpg|png|pdf|doc';
                $config['max_size']             = 10000;
                $config['max_width']            = 100024;
                $config['max_height']           = 768000;
                $this->load->library('upload', $config);
      if ( ! $this->upload->do_upload('attach')){

 echo '<script language="javascript">';
                    echo 'alert("fail")';
                    echo '</script>';

        }else{
         
        $upload_data = $this->upload->data();
       echo '<script language="javascript">';
                    echo 'alert("successfull")';
                    echo '</script>';
                  $params = array(
                                
                                 'ndate' => date('Y-m-d', strtotime($this->input->post('ndate'))),
                                 'ldate' => date('Y-m-d', strtotime($this->input->post('ldate'))),
                                 'hnote' => $this->input->post('hnote'),
                    

                    );


                      $params['attach']=$upload_data['file_name'];


           $this->Cases_Model->update_Cases($c_id,$params); 
            redirect('Cases/index');
        }
    }
            else
            {
               $data['_view'] = 'Cases/Hear';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The cases you are trying to edit does not exist.');
    }
    
   
}
?>