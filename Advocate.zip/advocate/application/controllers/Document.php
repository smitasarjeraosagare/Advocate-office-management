<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Document extends Base_Controller{
    function __construct()
    {
        parent::__construct();
        $this->authenticate();
        $this->load->model('Document_Model');
         $this->load->model('Cases_Model');
    } 
/*index function starts*/
	function index()
    {
        $data['doc'] = $this->Document_Model->get_all_Documents();
        
        $data['_view'] = 'Document/index'; 
        
        $this->load->view('layouts/main',$data);
    }
     function add()
    {   
        $data['all_cases'] = $this->Cases_Model->get_all_Case();
            
       /* $this->form_validation->set_rules('doc','doc','required|max_length[100]');*/
         $this->form_validation->set_rules('ctitle','Case','required|max_length[100]');
        $this->form_validation->set_rules('name','name','required|max_length[100]');
        
         if($this->form_validation->run())     
        {   

  $config['upload_path']          = './image';
                $config['allowed_types']        = 'gif|jpg|png|pdf|doc';
                $config['max_size']             = 100;
                $config['max_width']            = 1024;
                $config['max_height']           = 768;
                $this->load->library('upload', $config);
      if ( ! $this->upload->do_upload('photo')){

 echo '<script language="javascript">';
                    echo 'alert("fail")';
                    echo '</script>';

        }

        else{
         
        $upload_data = $this->upload->data();
       echo '<script language="javascript">';
                    echo 'alert("fail")';
                    echo '</script>';
            $params = array( 
                                /*'doc' => $this->input->post('doc'),*/
                                'd_id' => $this->input->post('ctitle'),
                                'name' => $this->input->post('name')

            );
            $params['photo']=$upload_data['file_name'];
            $d_id = $this->Document_Model->add_Document($params);
            redirect('Document/index');
        }
    }
        else
        {            
            $data['_view'] = 'Document/add';
            $this->load->view('layouts/main',$data);
        }
    }  
    

  function edit($d_id)
    {   
        
        // check if the customer exists before trying to edit it
        $data['doc'] = $this->Document_Model->get_Document($d_id);
        
        if(isset($data['doc']['d_id']))
        {
            $this->load->library('form_validation');
                

        $data['all_cases'] = $this->Cases_Model->get_all_Case();
            
       /* $this->form_validation->set_rules('doc','doc','required|max_length[100]');*/
         $this->form_validation->set_rules('ctitle','Case','required|max_length[100]');
        $this->form_validation->set_rules('name','name','required|max_length[100]');
        
            if($this->form_validation->run())     
            {   
                $params = array(
                     
                   'c_id' => $this->input->post('ctitle'),
                   'name' => $this->input->post('name')
                );

                $this->Document_Model->update_document($d_id,$params);            
                redirect('document/index');
            }
            else
            {
                $data['_view'] = 'document/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The doc you are trying to edit does not exist.');
    }  
      function remove($d_id)
    {
        $doc = $this->document_Model->get_documents($d_id);

        // check if the customer exists before trying to delete it
        if(isset($doc['d_id']))
        {
            $this->document_Model->delete_document($d_id);
            redirect('document/index');
        }
        else
            show_error('The doc you are trying to delete does not exist.');
    }
    function view($d_id)
    {   
         
        $data['doc'] = $this->document_Model->get_documents($d_id);
        if(isset($data['doc']['d_id']))
        {
            $data['_view'] = 'document/view';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The doc does not exist.');
    } 

 function upload($d_id)
    {   
        
       $data['doc'] = $this->Document_Model->get_Document($d_id);
        
        if(isset($data['doc']['d_id']))
        {

        $this->load->library('form_validation');

         $this->form_validation->set_rules('title','Name','max_length[100]');
       if($this->form_validation->run())    
        
             {   

  $config['upload_path']          = './image/';
                $config['allowed_types']        = 'gif|jpg|png|pdf|doc';
                $config['max_size']             = 10000;
                $config['max_width']            = 100024;
                $config['max_height']           = 768000;
                $this->load->library('upload', $config);
      if ( ! $this->upload->do_upload('doc')){

 echo '<script language="javascript">';
                    echo 'alert("fail")';
                    echo '</script>';

        }else{
         
        $upload_data = $this->upload->data();
       echo '<script language="javascript">';
                    echo 'alert("successfull")';
                    echo '</script>';
                  $params = array(
                                  'title' => $this->input->post('title'),
                    

                    );


                      $params['doc']=$upload_data['file_name'];
                  $params = array(
                                'title' => $this->input->post('title')
                    );


                      $params['doc']=$upload_data['file_name'];


            $this->Document_Model->update_document($d_id,$params);            
                redirect('document/index');
        }
    }
            else
            {
                $data['_view'] = 'document/upload';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The cases you are trying to edit does not exist.');
    }
}
 ?>