<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Court extends Base_Controller{
    function __construct()
    {
        parent::__construct();
        $this->authenticate();

        $this->load->model('Court_Model');
        $this->load->model('Location_Model');
         $this->load->model('Courtcategory_Model');
    } 
/*index function starts*/

    function index()
    {
        $data['court'] = $this->Court_Model->get_all_Court();
        $data['_view'] = 'Court/index';
        $this->load->view('layouts/main',$data);
  }

 
 
    /*end of index function*/
    function add()
    {   

       
        $this->load->library('form_validation');

       $data['all_location'] = $this->Location_Model->get_all_Locations();
        $data['all_courtcat'] = $this->Courtcategory_Model->get_all_Courtcategory();      
          $this->form_validation->set_rules('court','Court','required|max_length[100]');
         $this->form_validation->set_rules('lname','Location','required|max_length[100]');
         $this->form_validation->set_rules('courtname','Court Name','required|max_length[100]');  
$this->form_validation->set_rules('des','Description','required|max_length[100]');
        
        if($this->form_validation->run())     
        {   
            $params = array(
                    'court' => $this->input->post('court'),
                    'l_id' => $this->input->post('lname'),
                                'coucat_id' => $this->input->post('courtname'),
                                'des' => $this->input->post('des')
                    );
            
            $Court_id = $this->Court_Model->add_Court($params);
            redirect('Court/index');
        }
        else
        {            
            $data['_view'] = 'Court/add';
            $this->load->view('layouts/main',$data);
        }
    }  
    /*end add function*/ 
 function edit($court_id)
    {   
        
        // check if the customer exists before trying to edit it
        $data['court'] = $this->court_Model->get_courts($court_id);
        
        if(isset($data['court']['court_id']))
        {
            $this->load->library('form_validation');
                

        $this->form_validation->set_rules('leav','court','required|max_length[100]');
          $this->form_validation->set_rules('des','description','required|max_length[100]');
       
        
            if($this->form_validation->run())     
            {   
                $params = array(
                     
                    'leav' => $this->input->post('leav'),
                    'des' => $this->input->post('des')
                );

                $this->court_Model->update_court($court_id,$params);            
                redirect('court/index');
            }
            else
            {
                $data['_view'] = 'court/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The court you are trying to edit does not exist.');
    }  
      function remove($court_id)
    {
        $court = $this->court_Model->get_courts($court_id);

        // check if the customer exists before trying to delete it
        if(isset($court['']))
        {
            $this->court_Model->delete_court($court_id);
            redirect('court/index');
        }
        else
            show_error('The court you are trying to delete does not exist.');
    }
    function view($court_id)
    {   
         
        $data['court'] = $this->court_Model->get_courts($court_id);
        if(isset($data['court']['court_id']))
        {
            $data['_view'] = 'court/view';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The court does not exist.');
    } 

}
?>