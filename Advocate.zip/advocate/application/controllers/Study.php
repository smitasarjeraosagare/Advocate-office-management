<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Study extends Base_Controller{
    function __construct()
    {
        parent::__construct();
        $this->authenticate();
        $this->load->model('Study_Model');
         $this->load->model('Study_Model');
    } 
/*index function starts*/
	function index()
    {
        $data['study'] = $this->Study_Model->get_all_study();
        
        $data['_view'] = 'Study/index'; 
        
        $this->load->view('layouts/main',$data);
 }
 function add()
    {   
          $this->load->library('form_validation');
            
        $this->form_validation->set_rules('stitle','Title','required|max_length[100]');
         $this->form_validation->set_rules('cscat','Case','required|max_length[100]');
        $this->form_validation->set_rules('note','Notes','required|max_length[100]');
        $this->form_validation->set_rules('res','Result','required|max_length[100]');
        
        if($this->form_validation->run())     
        {   
            $params = array( 
                                'stitle' => $this->input->post('stitle'),
                                'cscat' => $this->input->post('cscat'),
                                'note' => $this->input->post('note'),
                                 'res' => $this->input->post('res')


            );
            
            $d_id = $this->Study_Model->add_study($params);
            redirect('Study/index');
        }
        else
        {            
            $data['_view'] = 'Study/add';
            $this->load->view('layouts/main',$data);
        }
    }  
     function edit($st_id)
    {   
        
        // check if the customer exists before trying to edit it
        $data['study'] = $this->Study_Model->get_Study($st_id);
        
        if(isset($data['study']['st_id']))
        {
             $this->load->library('form_validation');

              
        $this->form_validation->set_rules('stitle','Title','required|max_length[100]');
         $this->form_validation->set_rules('cscat','Case','required|max_length[100]');
        $this->form_validation->set_rules('note','Notes','required|max_length[100]');
        $this->form_validation->set_rules('res','Result','required|max_length[100]');
        
            if($this->form_validation->run())     
            {   
               $params = array(
                                
                    
                                'stitle' => $this->input->post('stitle'),
                                'cscat' => $this->input->post('cscat'),
                                'note' => $this->input->post('note'),
                                 'res' => $this->input->post('res')


                );

                $this->Study_Model->update_Study($st_id,$params);            
                redirect('Study/index');
            }
            else
            {
                $data['_view'] = 'Study/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The Study you are trying to edit does not exist.');
    } 


    function view($st_id)
    {   
         
        $data['study'] = $this->Study_Model->get_Study($st_id);
        if(isset($data['study']['st_id']))
        {
            $data['_view'] = 'Study/view';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The Study does not exist.');
    } 

    /*
     * Deleting Study
     */
    function remove($st_id)
    {
        $Study = $this->Study_Model->get_Study($st_id);

        // check if the customer exists before trying to delete it
        if(isset($Study['st_id']))
        {
            $this->Study_Model->delete_Study($st_id);
            redirect('Study/index');
        }
        else
            show_error('The Study you are trying to delete does not exist.');
    }
    
}
?>