<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Payment extends Base_Controller{
    function __construct()
    {
        parent::__construct();
        $this->authenticate();

        $this->load->model('Payment_Model');
        $this->load->model('Star_Model');
    } 
/*index function starts*/

    function index()
    {
        $data['payment'] = $this->Payment_Model->get_all_Payment();
        $data['_view'] = 'Payment/index';
        $this->load->view('layouts/main',$data);
  }

 
 
    /*end of index function*/
    function add()
    {   

       
        $this->load->library('form_validation');

        $this->form_validation->set_rules('pay','Payment','required|max_length[100]');
        
        if($this->form_validation->run())     
        {   
            $params = array(
                                

                    'pay' => $this->input->post('pay')
                    );
            
            $p_id = $this->Payment_Model->add_Payment($params);
            redirect('Payment/index');
        }
        else
        {            
            $data['_view'] = 'Payment/add';
            $this->load->view('layouts/main',$data);
        }
    }  
    /*end add function*/ 
    

}
?>