?<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Casestage extends Base_Controller{
    function __construct()
    {
        parent::__construct();
               $this->authenticate();

        $this->load->model('Casestage_Model');
        $this->load->model('Star_Model');
    } 
/*index function starts*/

    function index()
    {
        $data['casestage'] = $this->Casestage_Model->get_all_Casestage();
        $data['_view'] = 'Casestage/index';
        $this->load->view('layouts/main',$data);
  }

 
 
    /*end of index function*/
    function add()
    {   

       
        $this->load->library('form_validation');

        $this->form_validation->set_rules('stage','Casestage','required|max_length[100]');
        
        if($this->form_validation->run())     
        {   
            $params = array(
                                

                    'stage' => $this->input->post('stage')
                    );
            
            $Casestage_id = $this->Casestage_Model->add_Casestage($params);
            redirect('Casestage/index');
        }
        else
        {            
            $data['_view'] = 'Casestage/add';
            $this->load->view('layouts/main',$data);
        }
    }  
    /*end add function*/ 

}
?>