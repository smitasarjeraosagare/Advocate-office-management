<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Casecategory extends Base_Controller{
    function __construct()
    {
        parent::__construct();
        $this->authenticate();
       
        $this->load->model('Casecategory_Model');
        $this->load->model('Star_Model');
    } 
/*index function starts*/

    function index()
    {
        $data['casecategory'] = $this->Casecategory_Model->get_all_Casecategory();
        
        $data['_view'] = 'Casecategory/index';
        $this->load->view('layouts/main',$data);
         
        /*$query['star'] = $this->Star_Model->getstar();
        $query['star'] = null;
        if($query){
        $data['star'] =  $query;*/
  }

 
 
    /*end of index function*/
    function add()
    {   

       
        $this->load->library('form_validation');

        $this->form_validation->set_rules('catname','Case Title','required|max_length[100]');
        $this->form_validation->set_rules('patcat','Parent Category','required|max_length[100]');
       
        
        if($this->form_validation->run())     
        {   
            $params = array(
                                

                    'catname' => $this->input->post('catname'),
                    'patcat' => $this->input->post('patcat'),
                   
            );
            
            $c_id = $this->Casecategory_Model->add_Casecategory($params);
            redirect('Casecategory/index');
        }
        else
        {            
            $data['_view'] = 'Casecategory/add';
            $this->load->view('layouts/main',$data);
        }
    }  
    /*end add function*/ 
     function edit($cc_id)
    {   
        
        // check if the customer exists before trying to edit it
        $data['casecategory'] = $this->casecategory_Model->get_casecategorys($cc_id);
        
        if(isset($data['casecategory']['cc_id']))
        {
            $this->load->library('form_validation');
                

        $this->form_validation->set_rules('leav','casecategory','required|max_length[100]');
          $this->form_validation->set_rules('des','description','required|max_length[100]');
       
        
            if($this->form_validation->run())     
            {   
                $params = array(
                     
                    'leav' => $this->input->post('leav'),
                    'des' => $this->input->post('des')
                );

                $this->casecategory_Model->update_casecategory($cc_id,$params);            
                redirect('casecategory/index');
            }
            else
            {
                $data['_view'] = 'casecategory/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The casecategory you are trying to edit does not exist.');
    }  
      function remove($cc_id)
    {
        $casecategory = $this->casecategory_Model->get_casecategorys($cc_id);

        // check if the customer exists before trying to delete it
        if(isset($casecategory['cc_id']))
        {
            $this->casecategory_Model->delete_casecategory($cc_id);
            redirect('casecategory/index');
        }
        else
            show_error('The casecategory you are trying to delete does not exist.');
    }
    function view($cc_id)
    {   
         
        $data['casecategory'] = $this->casecategory_Model->get_casecategorys($cc_id);
        if(isset($data['casecategory']['cc_id']))
        {
            $data['_view'] = 'casecategory/view';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The casecategory does not exist.');
    } 
}


?>