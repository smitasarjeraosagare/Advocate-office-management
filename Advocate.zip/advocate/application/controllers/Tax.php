<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tax extends Base_Controller{
    function __construct()
    {
        parent::__construct();
       $this->authenticate();
        $this->load->model('Tax_Model');
        $this->load->model('Star_Model');
    } 
/*index function starts*/

    function index()
    {
        $data['tax'] = $this->Tax_Model->get_all_tax();
        
        $data['_view'] = 'Tax/index';
        $this->load->view('layouts/main',$data);
         
        /*$query['star'] = $this->Star_Model->getstar();
        $query['star'] = null;
        if($query){
        $data['star'] =  $query;*/
  }

 
 
    /*end of index function*/
    function add()
    {   

       
        $this->load->library('form_validation');

        $this->form_validation->set_rules('tax_name','Name','required|max_length[100]');
        $this->form_validation->set_rules('tax','Tax.','required|max_length[100]');
        
        
        if($this->form_validation->run())     
        {   
            $params = array(
                                

                    'tax_name' => $this->input->post('tax_name'),
                    'tax' => $this->input->post('tax'),
                   );
            
            $c_id = $this->Tax_Model->add_tax($params);
            redirect('Tax/index');
        }
        else
        {            
            $data['_view'] = 'Tax/add';
            $this->load->view('layouts/main',$data);
        }
    }  
    /*end add function*/ 

}
?>