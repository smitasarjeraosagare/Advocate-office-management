<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Department extends Base_Controller{
    function __construct()
    {
        parent::__construct();
         $this->authenticate();

       
        $this->load->model('Department_Model');
        $this->load->model('Star_Model');
    } 
/*index function starts*/

    function index()
    {
        $data['department'] = $this->Department_Model->get_all_Department();
        $data['_view'] = 'Department/index';
        $this->load->view('layouts/main',$data);
  }

 
 
    /*end of index function*/
    function add()
    {   

       
        $this->load->library('form_validation');

       
        $this->form_validation->set_rules('dname','department','required|max_length[100]');
          $this->form_validation->set_rules('des','description','required|max_length[100]');
       /* $this->form_validation->set_rules('design','department','required|max_length[100]');*/
        
        if($this->form_validation->run())     
        {   
            $params = array(
                    'dname' => $this->input->post('dname'),
                    'des' => $this->input->post('des'),
                   /* 'design' => $this->input->post('design')*/
                    );
            
            $d_id = $this->Department_Model->add_Department($params);
            redirect('Department/index');
        }
        else
        {            
            $data['_view'] = 'Department/add';
            $this->load->view('layouts/main',$data);
        }
    }  
    /*end add function*/
     function edit($dp_id)
    {   
        
        // check if the customer exists before trying to edit it
        $data['department'] = $this->Department_Model->get_Departments($dp_id);
        
        if(isset($data['department']['dp_id']))
        {
            $this->load->library('form_validation');
                

        $this->form_validation->set_rules('dname','department','required|max_length[100]');
          $this->form_validation->set_rules('des','description','required|max_length[100]');
        $this->form_validation->set_rules('design','department','required|max_length[100]');
        
            if($this->form_validation->run())     
            {   
                $params = array(
                     
                    'dname' => $this->input->post('dname'),
                    'des' => $this->input->post('des'),
                    'design' => $this->input->post('design')
                );

                $this->Department_Model->update_Department($dp_id,$params);            
                redirect('Department/index');
            }
            else
            {
                $data['_view'] = 'Department/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The department you are trying to edit does not exist.');
    }  
      function remove($dp_id)
    {
        $department = $this->department_Model->get_departments($dp_id);

        // check if the customer exists before trying to delete it
        if(isset($department['dp_id']))
        {
            $this->department_Model->delete_department($dp_id);
            redirect('department/index');
        }
        else
            show_error('The department you are trying to delete does not exist.');
    }
    function view($dp_id)
    {   
         
        $data['department'] = $this->department_Model->get_departments($dp_id);
        if(isset($data['department']['dp_id']))
        {
            $data['_view'] = 'department/view';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The department does not exist.');
    } 
}

?>