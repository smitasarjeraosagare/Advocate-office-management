<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cases extends Base_Controller{
    function __construct()
    {
        parent::__construct();
               /*$this->authenticate()*/;
 
        $this->load->model('Cases_Model');
         $this->load->model('Clients_Model');
         $this->load->model('Employees_Model');
        $this->load->model('Fees_Model');
         $this->load->model('Act_Model');
         $this->load->model('Casecategory_Model');
         $this->load->model('Courtcategory_Model');
         $this->load->model('Court_Model');
         $this->load->model('Casestage_Model');
         $this->load->model('Payment_Model');
         $this->load->model('Tax_Model');
         $this->load->model('Location_Model');
        
    } 
/*index function starts*/

    function index()
    {
       $data['cases'] = $this->Cases_Model->get_all_Case();
         $data['all_clients'] = $this->Clients_Model->get_all_Clients();
         $data['all_location'] = $this->Location_Model->get_all_Locations();
        $data['all_casecategory'] = $this->Casecategory_Model->get_all_Casecategory();
         $data['all_casestage'] = $this->Casestage_Model->get_all_Casestage();
        $data['all_act'] = $this->Act_Model->get_all_Act();
        $data['all_court'] = $this->Court_Model->get_all_Court();
        $data['all_courtcat'] = $this->Courtcategory_Model->get_all_Courtcategory();
        $data['all_employees'] = $this->Employees_Model->get_all_Employees();
        $data['cases'] = $this->Cases_Model->get_all_Case();
        
        $data['_view'] = 'Cases/index';
        
        $this->load->view('layouts/main',$data);
         
       
  }
   function invoice()
    {
          $data['cases'] = $this->Cases_Model->get_all_Case();
          
      
        $data['_view'] = 'Cases/invoice';
        
        $this->load->view('layouts/main',$data);
         
       
  }

    function add()
    {   
        $data['cases'] = $this->Cases_Model->get_all_Case();
         $data['all_clients'] = $this->Clients_Model->get_all_Clients();
         $data['all_location'] = $this->Location_Model->get_all_Locations();
        $data['all_casecategory'] = $this->Casecategory_Model->get_all_Casecategory();
         $data['all_casestage'] = $this->Casestage_Model->get_all_Casestage();
        $data['all_act'] = $this->Act_Model->get_all_Act();
        $data['all_court'] = $this->Court_Model->get_all_Court();
        $data['all_courtcat'] = $this->Courtcategory_Model->get_all_Courtcategory();
        $data['all_employees'] = $this->Employees_Model->get_all_Employees();
        $this->load->library('form_validation');
        $this->form_validation->set_rules('ctitle','Case Title');
        $this->form_validation->set_rules('cno','Case No.');
        $this->form_validation->set_rules('name','Name');
        $this->form_validation->set_rules('lname','Location');
        $this->form_validation->set_rules('courtname','courtname','max_length[100]');
        $this->form_validation->set_rules('court','Court','max_length[100]');
        $this->form_validation->set_rules('catname','catname','max_length[100]');
        $this->form_validation->set_rules('stage','Case Stage','max_length[100]');
        $this->form_validation->set_rules('act_name','Act','max_length[100]');
        $this->form_validation->set_rules('des','desitination','max_length[100]');
        $this->form_validation->set_rules('fdate','Filling Date','max_length[100]');
        $this->form_validation->set_rules('hdate','Hearing Date','max_length[100]');
          $this->form_validation->set_rules('ename','Opposite To','max_length[100]');
        $this->form_validation->set_rules('tfees','Total Fees','max_length[100]');
        $this->form_validation->set_rules('ename','Assign To','max_length[100]');
        
        if($this->form_validation->run())     
        {   
            $params = array(
                                

                    'ctitle' => $this->input->post('ctitle'),
                    'cno' => $this->input->post('cno'),
                    /*'cname' => $this->input->post('cname'),*/
                   'cl_id' => $this->input->post('name'),
                    'l_id' => $this->input->post('lname'),
                    'coucat_id' => $this->input->post('courtname'),
                    'court_id' => $this->input->post('court'),
                    'cc_id' => $this->input->post('catname'),
                    'cs_id' => $this->input->post('stage'),
                    'act_id' => $this->input->post('act_name'),
                    'des' => $this->input->post('des'),
                    'fdate' => date('Y-m-d', strtotime($this->input->post('fdate'))),
                    'hdate' => date('Y-m-d', strtotime($this->input->post('hdate'))),
                    /*'opp' => $this->input->post('opp'),*/
                    'e_id' => $this->input->post('ename'),
                    'tfees' => $this->input->post('tfees'),
                   /* 'assign' => $this->input->post('assign'),*/
                   'e_id' => $this->input->post('ename')
                     
          
            );
            
            $c_id = $this->Cases_Model->add_Cases($params);
            redirect('Cases/index');
        }
        else
        {            
            $data['_view'] = 'Cases/add';
            $this->load->view('layouts/main',$data);
        }
    }  
    /*end add function*/ 
    function edit($c_id)
    {   
        
        $data['cases'] = $this->Cases_Model->get_Cases($c_id);
        
        if(isset($data['cases']['c_id']))
        {
           
          /*$data['cases'] = $this->Cases_Model->get_all_Case();*/
         $data['all_clients'] = $this->Clients_Model->get_all_Clients();
         $data['all_location'] = $this->Location_Model->get_all_Locations();
        $data['all_casecategory'] = $this->Casecategory_Model->get_all_Casecategory();
         $data['all_casestage'] = $this->Casestage_Model->get_all_Casestage();
        $data['all_act'] = $this->Act_Model->get_all_Act();
        $data['all_court'] = $this->Court_Model->get_all_Court();
        $data['all_courtcat'] = $this->Courtcategory_Model->get_all_Courtcategory();
         
           $data['all_employees'] = $this->Employees_Model->get_all_Employees();

        $this->load->library('form_validation');

        $this->form_validation->set_rules('ctitle','Case Title');
        $this->form_validation->set_rules('cno','Case No.');
     /*   $this->form_validation->set_rules('cname','Cases Name');*/
        $this->form_validation->set_rules('name','Name');
        $this->form_validation->set_rules('lname','Location');
        $this->form_validation->set_rules('courtname','courtname','max_length[100]');
        $this->form_validation->set_rules('court','Court','max_length[100]');
        $this->form_validation->set_rules('catname','catname','max_length[100]');
        $this->form_validation->set_rules('stage','Case Stage','max_length[100]');
        $this->form_validation->set_rules('act_name','Act','max_length[100]');
        $this->form_validation->set_rules('des','desitination','max_length[100]');
        $this->form_validation->set_rules('fdate','Filling Date','max_length[100]');
        $this->form_validation->set_rules('hdate','Hearing Date','max_length[100]');
        $this->form_validation->set_rules('opp','Opposite To','max_length[100]');
        $this->form_validation->set_rules('tfees','Total Fees','max_length[100]');
        $this->form_validation->set_rules('ename','Assign To','max_length[100]');

       
        
            if($this->form_validation->run())     
            {   
                  $params = array(
                                

                   'ctitle' => $this->input->post('ctitle'),
                    'cno' => $this->input->post('cno'),
                    /*'cname' => $this->input->post('cname'),*/
                   'cl_id' => $this->input->post('name'),
                    'l_id' => $this->input->post('lname'),
                    'coucat_id' => $this->input->post('courtname'),
                    'court_id' => $this->input->post('court'),
                    'cc_id' => $this->input->post('catname'),
                    'cs_id' => $this->input->post('stage'),
                    'act_id' => $this->input->post('act_name'),
                    'des' => $this->input->post('des'),
                    'fdate' => date('Y-m-d', strtotime($this->input->post('fdate'))),
                    'hdate' => date('Y-m-d', strtotime($this->input->post('hdate'))),
                    'opp' => $this->input->post('opp'),
                    'tfees' => $this->input->post('tfees'),
                   /* 'assign' => $this->input->post('assign'),*/
                   'e_id' => $this->input->post('ename')
          
            );

                $this->Cases_Model->update_Cases($c_id,$params);            
                redirect('cases/index');
            }
            else
            {
                $data['_view'] = 'cases/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The cases you are trying to edit does not exist.');
    }  
    function remove($c_id)
    {
        $cases = $this->Cases_Model->get_Cases($c_id);

        // check if the customer exists before trying to delete it
        if(isset($cases['c_id']))
        {
            $this->Cases_Model->delete_cases($c_id);
            redirect('cases/index');
        }
        else
            show_error('The cases you are trying to delete does not exist.');
    }
    function view($c_id)
    {   
         
        $data['cases'] = $this->Cases_Model->get_Cases($c_id);
        if(isset($data['cases']['c_id']))
        {
            $data['_view'] = 'cases/view';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The cases does not exist.');
    } 
     function print($c_id)
    {   
         
        $data['cases'] = $this->Cases_Model->get_Cases($c_id);
        if(isset($data['cases']['c_id']))
        {
            $data['_view'] = 'cases/print';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The cases does not exist.');
    } 
     function star($c_id)
    {
        $cases = $this->Cases_Model->get_Cases($c_id);
        if(isset($cases['c_id']))
        {
            $this->Cases_Model->addStar()($c_id);
            redirect('cases/index');
        }
        else
            show_error('The cases you are trying to delete does not exist.');
    }
    function archived($c_id)
    {   
        
        $data['cases'] = $this->Cases_Model->get_Cases($c_id);
        
        if(isset($data['cases']['c_id']))
        {

        $this->load->library('form_validation');

         $this->form_validation->set_rules('note','Notes','max_length[100]');
        $this->form_validation->set_rules('cdate','Closing Date','required|max_length[100]');
        
            if($this->form_validation->run())     
            {   
                  $params = array(
                                

                   'note' => $this->input->post('note'),
                    'cdate' => date('Y-m-d', strtotime($this->input->post('cdate'))),
                     
          
            );

               $this->Cases_Model->update_Cases($c_id,$params);            
                redirect('Archived/index');
            }
            else
            {
               $data['_view'] = 'archived/add';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The cases you are trying to edit does not exist.');
    }
   
    //fees
      function fees($c_id)
    {   
        
        $data['cases'] = $this->Cases_Model->get_Cases($c_id);
        
        if(isset($data['cases']['c_id']))
        {
            
          $data['all_payment'] = $this->Payment_Model->get_all_Payment();
         $data['all_tax'] = $this->Tax_Model->get_all_tax();
          $data['all_taxm'] = $this->Tax_Model->get_all_tax();


          $this->load->library('form_validation');
        $this->form_validation->set_rules('pay','payment','max_length[100]');
        $this->form_validation->set_rules('tax_name','Tax','max_length[100]');
        $this->form_validation->set_rules('tax','Tax','max_length[100]');
        $this->form_validation->set_rules('tfees','Amount','max_length[100]');
        $this->form_validation->set_rules('total','Total ','max_length[100]');
       
            if($this->form_validation->run())     
            {   
                  $params = array(
                    'p_id' => $this->input->post('pay'),

                    'tax_id' => $this->input->post('tax_name'),
                     'tax_id' => $this->input->post('tax'),
                    'date' => date('Y-m-d', strtotime($this->input->post('date'))),
                    'tfees' => $this->input->post('tfees'),
                    'total' => $this->input->post('total')
            );

                $this->Cases_Model->update_Cases($c_id,$params);            
                redirect('cases/index');
            }
            else
            {
                $data['_view'] = 'cases/fees';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The cases you are trying to edit does not exist.');
    }  
    function hear($c_id)
    {   
        
       $data['cases'] = $this->Cases_Model->get_Cases($c_id);
        
        if(isset($data['cases']['c_id']))
        {

        $this->load->library('form_validation');

         $this->form_validation->set_rules('ndate','Next Date','required|max_length[100]');
        $this->form_validation->set_rules('ldate','Last Date','required|max_length[100]');
         $this->form_validation->set_rules('hnote','Note','required|max_length[100]');
       
        
           if($this->form_validation->run())     
        {   

  $config['upload_path']          = './image/';
                $config['allowed_types']        = 'gif|jpg|png|pdf|doc';
                $config['max_size']             = 10000;
                $config['max_width']            = 100024;
                $config['max_height']           = 768000;
                $this->load->library('upload', $config);
      if ( ! $this->upload->do_upload('attach')){

 echo '<script language="javascript">';
                    echo 'alert("fail")';
                    echo '</script>';

        }else{
         
        $upload_data = $this->upload->data();
       echo '<script language="javascript">';
                    echo 'alert("successfull")';
                    echo '</script>';
                  $params = array(
                                
                                 'ndate' => date('Y-m-d', strtotime($this->input->post('ndate'))),
                                 'ldate' => date('Y-m-d', strtotime($this->input->post('ldate'))),
                                 'hnote' => $this->input->post('hnote'),
                    

                    );


                      $params['attach']=$upload_data['file_name'];


           $this->Cases_Model->update_Cases($c_id,$params); 
            redirect('Cases/index');
        }
    }
            else
            {
               $data['_view'] = 'Cases/Hear';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The cases you are trying to edit does not exist.');
    }
    
}
?>