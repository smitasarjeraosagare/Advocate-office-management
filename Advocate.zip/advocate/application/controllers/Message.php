
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Message extends Base_Controller{
    function __construct()
    {
        parent::__construct();
        $this->authenticate();

        $this->load->model('Message_Model');
         $this->load->model('Employees_Model');
        $this->load->model('Clients_Model');
    } 
/*index function starts*/

    function index()
    {
        $data['message'] = $this->Message_Model->get_all_Messages();
        $data['_view'] = 'Message/index';
        $this->load->view('layouts/main',$data);
  }
 
    /*end of index function*/
    function add()
    { 
   
        /* $data['all_employees'] = $this->Employees_Model->get_all_Employees();
        $data['all_client'] = $this->Clients_Model->get_all_Clients();*/       
       
$this->form_validation->set_rules('name','Name','required|max_length[100]');
$this->form_validation->set_rules('email','email','required|max_length[100]');
$this->form_validation->set_rules('number','number','required|max_length[100]');
$this->form_validation->set_rules('message','Message','required|max_length[100]');
        
        if($this->form_validation->run())     
        {   
          /*  $params = array( 
        'name'= $this->input->post('name'),
        'email' = $this->input->post('email'),
        'number' = $this->input->post('number')
       
            );*/
            $data['name'] = $this->input->post('name');
        $data['email'] = $this->input->post('email');
        $data['number'] = $this->input->post('number');
         $data['message'] = $this->input->post('message');
            $this->load->library('email');

           
 
        $this->email->from('addmin@admin.com', '12345678')
            ->to($data['email'])
            ->subject('Welcome')
            ->message($this->load->view('Message/index', $data, true));
 
        $this->email->send(); 
      
       /* $arr = array('msg' => 'Something went wrong try again later', 'success' =>false);
 
        if($this->email->send()){*/
         $arr = array('msg' => 'Mail has been sent successfully', 'success' =>true);
        
        echo json_encode($arr);
            
             $m_id = $this->Message_Model->add_Message($data);
            redirect('dashboard');
        
        }
        else
        {            
           $data['_view'] = 'Message/index';
            $this->load->view('layouts/main',$data);
        }
        
        
     } 
    /*end add function*/ 
     function edit($m_id)
    {   
        
        // check if the customer exists before trying to edit it
        $data['Message'] = $this->Message_Model->get_Message($m_id);
        
        if(isset($data['Message']['m_id']))
        {
            $this->load->library('form_validation');
                

        $this->form_validation->set_rules('leav','Message','required|max_length[100]');
          $this->form_validation->set_rules('rea','reacription','required|max_length[100]');
       
        
            if($this->form_validation->run())     
            {   
                $params = array(
                     
                    'leav' => $this->input->post('leav'),
                    'rea' => $this->input->post('rea')
                );

                $this->Message_Model->update_Message($m_id,$params);            
                redirect('Message/index');
            }
            else
            {
                $data['_view'] = 'Message/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The Message you are trying to edit does not exist.');
    }  
      function remove($m_id)
    {
        $Message = $this->Message_Model->get_Messages($m_id);

        // check if the customer exists before trying to delete it
        if(isset($Message['m_id']))
        {
            $this->Message_Model->delete_Messages($m_id);
            redirect('Message/index');
        }
        else
            show_error('The Message you are trying to delete does not exist.');
    }
    function view($m_id)
    {   
         
        $data['Message'] = $this->Message_Model->get_Messages($m_id);
        if(isset($data['Message']['m_id']))
        {
            $data['_view'] = 'Message/view';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The Message does not exist.');
    } 


}
?>