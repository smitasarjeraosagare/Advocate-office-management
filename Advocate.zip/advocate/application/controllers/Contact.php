<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contact extends Base_Controller{
    function __construct()
    {
        parent::__construct();
        $this->authenticate();

        $this->load->model('Contact_Model');
        /* $this->load->model('Star_Model');*/
    } 
/*index function starts*/
	function index()
    {
        $data['contact'] = $this->Contact_Model->get_all_Contacts();
        
        $data['_view'] = 'Contact/index'; 
        
        $this->load->view('layouts/main',$data);
         

 }/*end of index function*/
    function add()
    {   

       
        $this->load->library('form_validation');

        $this->form_validation->set_rules('name','Case Title','required|max_length[100]');
        $this->form_validation->set_rules('phone','Case No.','required|max_length[100]');
        $this->form_validation->set_rules('email','Contact Name','required|max_length[100]');
        $this->form_validation->set_rules('addr','addration','required|max_length[100]');
        $this->form_validation->set_rules('card','Court Category','required|max_length[100]');
        
        
        if($this->form_validation->run())     
        {   
            $params = array(
                                

                    'name' => $this->input->post('name'),
                   /* 'sid' => $this->input->post('sid'),*/
                    'phone' => $this->input->post('phone'),
                    'email' => $this->input->post('email'),
                    'addr' => $this->input->post('addr'),
                    'card' => $this->input->post('card'),
                    
                     
          
            );
            
            $ct_id = $this->Contact_Model->add_Contact($params);
            redirect('Contact/index');
        }
        else
        {            
            $data['_view'] = 'Contact/add';
            $this->load->view('layouts/main',$data);
        }
    }  
    /*end add function*/ 
 function edit($ct_id)
    {   
        
        // check if the customer exists before trying to edit it
        $data['contact'] = $this->Contact_Model->get_Contact($ct_id);
        
        if(isset($data['contact']['ct_id']))
        {
              $this->load->library('form_validation');

        $this->form_validation->set_rules('name','Nameme','required|max_length[100]');
        $this->form_validation->set_rules('phone','phone','required|max_length[100]');
        $this->form_validation->set_rules('email','Email','required|max_length[100]');
        $this->form_validation->set_rules('addr','Address','required|max_length[100]');
        $this->form_validation->set_rules('card','Id card No','required|max_length[100]');
        
            
       
        
            if($this->form_validation->run())     
            {   
               $params = array(
                   'name' => $this->input->post('name'),
                    'phone' => $this->input->post('phone'),
                    'email' => $this->input->post('email'),
                    'addr' => $this->input->post('addr'),
                    'card' => $this->input->post('card'),
                     

                );

                $this->Contact_Model->update_Contact($ct_id,$params);            
                redirect('Contact/index');
            }
            else
            {
                $data['_view'] = 'contact/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The Contact you are trying to edit does not exist.');
    } 


    function view($ct_id)
    {   
         
        $data['Contact'] = $this->Contact_Model->get_Contact($ct_id);
        if(isset($data['Contact']['ct_id']))
        {
            $data['_view'] = 'Contact/view';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The Contact does not exist.');
    } 

    /*
     * Deleting Contact
     */
    function remove($ct_id)
    {
        $Contact = $this->Contact_Model->get_Contact($ct_id);

        // check if the customer exists before trying to delete it
        if(isset($Contact['ct_id']))
        {
            $this->Contact_Model->delete_Contact($ct_id);
            redirect('Contact/index');
        }
        else
            show_error('The Contact you are trying to delete does not exist.');
    }
    
/*
            function archived($ct_id)
            {   
        
        // check if the customer exists before trying to edit it
        $data['Contact'] = $this->Contact_Model->get_Contact($ct_id);
        
        if(isset($data['Contact']['ct_id']))
        {
             $this->load->library('form_validation');
        $this->form_validation->set_rules('notes','Company Name','required|max_length[100]');
        $this->form_validation->set_rules('cdate','Closing Date','required|max_length[100]');
           if($this->form_validation->run())     
            {   
               $params = array(
                    'note' => $this->input->post('note'),
                    'cdate' => date('Y-m-d', strtotime($this->input->post('cdate'))),  );

                $this->Contact_Model->add_archive($ct_id,$params);            
                redirect('Contact/index');
            }
            else
            {
                $data['_view'] = 'Contact/archived';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The Contact you are trying to edit does not exist.');
    } 
*/

   
}
?>