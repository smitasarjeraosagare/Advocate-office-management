<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Appointment extends Base_Controller{
    function __construct()
    {
        parent::__construct();
        $this->authenticate();
        $this->load->model('Appointment_Model');
         $this->load->model('Contact_Model');
          $this->load->model('Cases_Model');
         $this->load->model('Clients_Model');
         $this->load->model('Employees_Model');
        $this->load->model('Fees_Model');
         $this->load->model('Act_Model');
         $this->load->model('Casecategory_Model');
         $this->load->model('Courtcategory_Model');
         $this->load->model('Court_Model');
         $this->load->model('Casestage_Model');
         $this->load->model('Payment_Model');
         $this->load->model('Tax_Model');
         $this->load->model('Location_Model');
    } 
/*index function starts*/
	function index()
    {
        $data['cases'] = $this->Cases_Model->get_all_Case();
         $data['all_clients'] = $this->Clients_Model->get_all_Clients();
         $data['all_location'] = $this->Location_Model->get_all_Locations();
        $data['all_casecategory'] = $this->Casecategory_Model->get_all_Casecategory();
         $data['all_casestage'] = $this->Casestage_Model->get_all_Casestage();
        $data['all_act'] = $this->Act_Model->get_all_Act();
        $data['all_court'] = $this->Court_Model->get_all_Court();
        $data['all_courtcat'] = $this->Courtcategory_Model->get_all_Courtcategory();
        $data['all_employees'] = $this->Employees_Model->get_all_Employees();
        $data['cases'] = $this->Cases_Model->get_all_Case();
        $data['appointment'] = $this->Appointment_Model->get_all_appointment();
        
        $data['_view'] = 'Appointment/index'; 
        
        $this->load->view('layouts/main',$data);
         


         
 
 }/*end of index function*/
    function add()
    {    $data['all_contact'] = $this->Contact_Model->get_all_Contacts();
       /* $data['all_appointment'] = $this->Appointment_Model->get_all_Appointments();*/
            
        $this->form_validation->set_rules('atitle','atitle','required|max_length[100]');
         $this->form_validation->set_rules('name','Contact','required|max_length[100]');
        $this->form_validation->set_rules('motive','motive','required|max_length[100]');
        $this->form_validation->set_rules('note','note','required|max_length[100]');
         $this->form_validation->set_rules('adate','Appointment Date','required|max_length[100]');
        
        if($this->form_validation->run())     
        {   
            $params = array( 
                                'atitle' => $this->input->post('atitle'),
                                'ct_id' => $this->input->post('name'),
                                'motive' => $this->input->post('motive'),
                                   'note' => $this->input->post('note'),
                    'adate' => date('Y-m-d', strtotime($this->input->post('adate')))

            );
            
            $ap_id = $this->Appointment_Model->add_Appointment($params);
            redirect('Appointment/index');
        }
        else
        {            
            $data['_view'] = 'Appointment/add';
            $this->load->view('layouts/main',$data);
        }
    }  
    /*end add function*/ 
 function edit($ap_id)
    {   
        
        // check if the customer exists before trying to edit it
        $data['appointment'] = $this->Appointment_Model->get_Appointment($ap_id);
        
        if(isset($data['appointment']['ap_id']))
        {
              $data['all_contact'] = $this->Contact_Model->get_all_Contacts();
       /* $data['all_appointment'] = $this->Appointment_Model->get_all_Appointments();*/
            
        $this->form_validation->set_rules('atitle','atitle','max_length[100]');
         $this->form_validation->set_rules('name','Contact','max_length[100]');
        $this->form_validation->set_rules('motive','motive','max_length[100]');
        $this->form_validation->set_rules('note','note','max_length[100]');
         $this->form_validation->set_rules('adate','Appointment Date','required|max_length[100]');
       
        
            if($this->form_validation->run())     
            {   
              
                                
                     $params = array( 
                                'atitle' => $this->input->post('atitle'),
                                'ct_id' => $this->input->post('name'),
                                'motive' => $this->input->post('motive'),
                                   'note' => $this->input->post('note'),
                    'adate' => date('Y-m-d', strtotime($this->input->post('adate')))
                     

                );

                $this->Appointment_Model->update_Appointment($ap_id,$params);            
                redirect('Appointment/index');
            }
            else
            {
                $data['_view'] = 'Appointment/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The Appointment you are trying to edit does not exist.');
    } 


    function view($ap_id)
    {   
         
        $data['appointment'] = $this->Appointment_Model->get_Appointment($ap_id);
        if(isset($data['appointment']['ap_id']))
        {
            $data['_view'] = 'Appointment/view';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The Appointment does not exist.');
    } 

    /*
     * Deleting Appointment
     */
    function remove($ap_id)
    {
        $Appointment = $this->Appointment_Model->get_Appointment($ap_id);

        // check if the customer exists before trying to delete it
        if(isset($appointment['ap_id']))
        {
            $this->Appointment_Model->delete_Appointment($ap_id);
            redirect('Appointment/index');
        }
        else
            show_error('The Appointment you are trying to delete does not exist.');
    }
    
/*
            function archived($ap_id)
            {   
        
        // check if the customer exists before trying to edit it
        $data['Appointment'] = $this->Appointment_Model->get_Appointment($ap_id);
        
        if(isset($data['Appointment']['ap_id']))
        {
             $this->load->library('form_validation');
        $this->form_validation->set_rules('notes','Company Name','required|max_length[100]');
        $this->form_validation->set_rules('cdate','Closing Date','required|max_length[100]');
           if($this->form_validation->run())     
            {   
               $params = array(
                    'note' => $this->input->post('note'),
                    'cdate' => date('Y-m-d', strtotime($this->input->post('cdate'))),  );

                $this->Appointment_Model->add_archive($ap_id,$params);            
                redirect('Appointment/index');
            }
            else
            {
                $data['_view'] = 'Appointment/archived';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The Appointment you are trying to edit does not exist.');
    } 
*/

   
}
?>