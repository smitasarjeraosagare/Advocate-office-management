<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Task extends Base_Controller{
    function __construct()
    {
        parent::__construct();
        $this->authenticate();
       
        $this->load->model('Task_Model');
        $this->load->model('Star_Model');
         $this->load->model('Act_Model');
         $this->load->model('Cases_Model');
         $this->load->model('Employees_Model');
        
        /* $this->load->model('Tasktage_Model');*//*
     */    /*$this->load->model('Casecategory_Model');
         $this->load->model('Casecategory_Model');
         $this->load->model('Casecategory_Model');*/
    } 
/*index function starts*/

    function index()
    {
        $data['task'] = $this->Task_Model->get_all_Tasks();
        
        $data['_view'] = 'Task/index';
        $this->load->view('layouts/main',$data);
         
        /*$query['star'] = $this->Star_Model->getstar();
        $query['star'] = null;
        if($query){
        $data['star'] =  $query;*/
  }

 
 
    /*end of index function*/
    function add()
    {   
        $data['all_employee'] = $this->Employees_Model->get_all_Employees();
        $data['all_cases'] = $this->Cases_Model->get_all_Case();
        $this->load->library('form_validation');

        $this->form_validation->set_rules('task','Title','max_length[100]');
       /* $this->form_validation->set_rules('too','Task For: ','required|max_length[100]');*/

        $this->form_validation->set_rules('ctitle',' Category','max_length[100]');
        $this->form_validation->set_rules('ename','ename','max_length[100]');
        $this->form_validation->set_rules('priority','Case Category','max_length[100]');
        $this->form_validation->set_rules('progress','Case progress','max_length[100]');
       
        $this->form_validation->set_rules('des','desitination','max_length[100]');
        $this->form_validation->set_rules('due','Filling Date','max_length[100]');
      
        
        if($this->form_validation->run())     
        {   
            $params = array(
                    'task' => $this->input->post('task'),
                /*    'too'=>$this->input->post('too'),*/
                    'c_id' => $this->input->post('ctitle'),
                    'e_id' => $this->input->post('ename'),
                    'priority' => $this->input->post('priority'),
                    'progress' => $this->input->post('progress'),
                    
                    'des' => $this->input->post('des'),
                    'due' => date('Y-m-d', strtotime($this->input->post('due')))
                    
                     
          
            );
            
            $task_id = $this->Task_Model->add_Task($params);
            redirect('Task/index');
        }
        else
        {            
            $data['_view'] = 'Task/add';
            $this->load->view('layouts/main',$data);
        }
    }  
    /*end add function*/ 
    function edit($task_id)
    {   
        
        // check if the customer exists before trying to edit it
        $data['task'] = $this->Task_Model->get_Task($task_id);
        
        if(isset($data['task']['task_id']))
        {
           
           $data['all_employee'] = $this->Employees_Model->get_all_Employees();
        $data['all_cases'] = $this->Cases_Model->get_all_Case();
        $this->load->library('form_validation');

        $this->form_validation->set_rules('task','Title','max_length[100]');
       /* $this->form_validation->set_rules('too','Task For: ','required|max_length[100]');*/

        $this->form_validation->set_rules('ctitle',' Category','max_length[100]');
        $this->form_validation->set_rules('ename','ename','max_length[100]');
        $this->form_validation->set_rules('priority','Case Category','max_length[100]');
        $this->form_validation->set_rules('progress','Case progress','max_length[100]');
       
        $this->form_validation->set_rules('des','desitination','max_length[100]');
        $this->form_validation->set_rules('due','Filling Date','max_length[100]');
      
        
        if($this->form_validation->run())     
        {   
            $params = array(
                    'task' => $this->input->post('task'),
                   /* 'too'=>$this->input->post('too'),*/
                    'c_id' => $this->input->post('ctitle'),
                    'e_id' => $this->input->post('ename'),
                    'priority' => $this->input->post('priority'),
                    'progress' => $this->input->post('progress'),
                    
                    'des' => $this->input->post('des'),
                    'due' => date('Y-m-d', strtotime($this->input->post('due')))
                    
                     
          
            );
                $this->Task_Model->update_Task($task_id,$params);            
                redirect('Task/index');
            }
            else
            {
                $data['_view'] = 'Task/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The Task you are trying to edit does not exist.');
    }  
    function remove($task_id)
    {
        $Task = $this->Task_Model->get_Task($task_id);

        // check if the customer exists before trying to delete it
        if(isset($Task['task_id']))
        {
            $this->Task_Model->delete_Task($task_id);
            redirect('Task/index');
        }
        else
            show_error('The Task you are trying to delete does not exist.');
    }
    function view($task_id)
    {   
         
        $data['task'] = $this->Task_Model->get_Task($task_id);
        if(isset($data['task']['task_id']))
        {
            $data['_view'] = 'Task/view';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The Task does not exist.');
    } 
     function star($task_id)
    {
        $Task = $this->Task_Model->get_Task($task_id);
        if(isset($Task['task_id']))
        {
            $this->Task_Model->addStar()($task_id);
            redirect('Task/index');
        }
        else
            show_error('The Task you are trying to delete does not exist.');
    }
     
}

?>