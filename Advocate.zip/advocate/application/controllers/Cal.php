<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Cal extends CI_Controller {
public function index($year = NULL , $month = NULL)
  {
    $this->load->model('Calendar_Model');
    $data['calender'] = $this->Calendar_Model->getcalender($year , $month);
    $this->load->view('Calendar/index', $data);
    
  }}
