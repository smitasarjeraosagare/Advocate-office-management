<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class customfield extends Base_Controller{
    function __construct()
    {
        parent::__construct();
        $this->authenticate();

        $this->load->model('Customfield_model');
        /* $this->load->model('Star_Model');*/
    } 
/*index function starts*/
	function index()
    {
        $data['customfield'] = $this->Customfield_model->get_all_Customfields();
       /* $data['customfield']  = $this->Customfield_model->add_customfield($params);*/
         $data['_view'] = 'Customfield/add'; 
        $data['_view'] = 'Customfield/index'; 
        
        $this->load->view('layouts/main',$data);
         
 
 
 }/*end of index function*/
    function add()
    {   


       
        $this->load->library('form_validation');

        $this->form_validation->set_rules('form','Case Title','required|max_length[100]');

        $this->form_validation->set_rules('ftype','Case No.','required|max_length[100]');
        $this->form_validation->set_rules('fname','customfield Name','required|max_length[100]');
        $this->form_validation->set_rules('value','valueation','required|max_length[100]');
        
        
        if($this->form_validation->run())     
        {   
            $params = array(
                                

                    'form' => $this->input->post('form'),
                    'ftype' => $this->input->post('ftype'),
                    'fname' => $this->input->post('fname'),
                    'value' => $this->input->post('value'),
                    
            );
            
            $cf_id = $this->Customfield_model->add_customfield($params);
           /* redirect('Customfield/index');*/
        }
        else
        {            
            $data['_view'] = 'Customfield/add';
            $this->load->view('layouts/main',$data);
        }
    }  
    /*end add function*/ 



    function view($cf_id)
    {   
         
        $data['customfield'] = $this->Customfield_model->get_Customfield($cf_id);
        if(isset($data['customfield']['cf_id']))
        {
            $data['_view'] = 'customfield/view';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The customfield does not exist.');
    } 

    /*
     * Deleting customfield
     */
    function remove($cf_id)
    {
        $customfield = $this->Customfield_model->get_Customfield($cf_id);

        // check if the customer exists before trying to delete it
        if(isset($customfield['cf_id']))
        {
            $this->Customfield_model->delete_Customfield($cf_id);
            redirect('customfield/index');
        }
        else
            show_error('The customfield you are trying to delete does not exist.');
    }
    
/*
            function archived($cf_id)
            {   
        
        // check if the customer exists before trying to edit it
        $data['customfield'] = $this->Customfield_model->get_Customfield($cf_id);
        
        if(isset($data['customfield']['cf_id']))
        {
             $this->load->library('form_validation');
        $this->form_validation->set_rules('notes','Company Name','required|max_length[100]');
        $this->form_validation->set_rules('cdate','Closing Date','required|max_length[100]');
           if($this->form_validation->run())     
            {   
               $params = array(
                    'note' => $this->input->post('note'),
                    'cdate' => date('Y-m-d', strtotime($this->input->post('cdate'))),  );

                $this->Customfield_model->add_archive($cf_id,$params);            
                redirect('customfield/index');
            }
            else
            {
                $data['_view'] = 'customfield/archived';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The customfield you are trying to edit does not exist.');
    } 
*/

   
}
?>