<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mytask extends Base_Controller{
    function __construct()
    {
        parent::__construct();
        $this->authenticate();

        $this->load->model('Task_Model');
       
        
        /* $this->load->model('Tasktage_Model');*//*
     */    /*$this->load->model('Casecategory_Model');
         $this->load->model('Casecategory_Model');
         $this->load->model('Casecategory_Model');*/
    } 
/*index function starts*/

    function index()
    {
        $data['task'] = $this->Task_Model->get_mytask();
        
        $data['_view'] = 'Task/index';
        $this->load->view('layouts/main',$data);
         
        /*$query['star'] = $this->Star_Model->getstar();
        $query['star'] = null;
        if($query){
        $data['star'] =  $query;*/
  }

 
 
    /*end of index function*/
    /*function add()
    {   
        $data['all_employee'] = $this->Employees_Model->get_all_Employees();
        $data['all_cases'] = $this->Cases_Model->get_all_Cases();
        $this->load->library('form_validation');

        $this->form_validation->set_rules('task','Title','max_length[100]');
        $this->form_validation->set_rules('ctitle',' Category','max_length[100]');
        $this->form_validation->set_rules('ename','ename','max_length[100]');
        $this->form_validation->set_rules('priority','Case Category','max_length[100]');
        $this->form_validation->set_rules('progress','Case progress','max_length[100]');
       
        $this->form_validation->set_rules('des','desitination','max_length[100]');
        $this->form_validation->set_rules('due','Filling Date','max_length[100]');
      
        
        if($this->form_validation->run())     
        {   
            $params = array(
                                

                    'task' => $this->input->post('task'),
                    'task_id' => $this->input->post('ctitle'),
                    'e_id' => $this->input->post('ename'),
                    'priority' => $this->input->post('priority'),
                    'progress' => $this->input->post('progress'),
                    
                    'des' => $this->input->post('des'),
                    'due' => date('Y-m-d', strtotime($this->input->post('due')))
                    
                     
          
            );
            
            $task_id = $this->Task_Model->add_Task($params);
            redirect('Task/index');
        }
        else
        {            
            $data['_view'] = 'Task/add';
            $this->load->view('layouts/main',$data);
        }
    } */ 
    /*end add function*/ 
    function edit($task_id)
    {   
        
        // check if the customer exists before trying to edit it
        $data['Task'] = $this->Task_Model->get_Task($task_id);
        
        if(isset($data['Task']['task_id']))
        {
           
          $data['$all_casecategory'] = $this->Casecategory_Model->get_all_Casecategory();
         $data['$all_Tasktage'] = $this->Tasktage_Model->get_all_Tasktage();
          $data['all_act'] = $this->Act_Model->get_all_Act();
           $data['all_ename'] = $this->ename_Model->get_all_ename();
        $data['$all_enamecat'] = $this->enamecategory_Model->get_all_enamecategory();

        $this->load->library('form_validation');

        $this->form_validation->set_rules('task','Case Title');
        $this->form_validation->set_rules('cno','Case No.');
        $this->form_validation->set_rules('cname','Task Name');
        $this->form_validation->set_rules('loc','Location');
        $this->form_validation->set_rules('ctitle','ename Category','max_length[100]');
        $this->form_validation->set_rules('ename','ename','max_length[100]');
        $this->form_validation->set_rules('priority','Case Category','max_length[100]');
        $this->form_validation->set_rules('progress','Case progress','max_length[100]');
        $this->form_validation->set_rules('act_name','Act','max_length[100]');
        $this->form_validation->set_rules('des','Destination','max_length[100]');
        $this->form_validation->set_rules('due','Filling Date','max_length[100]');
        $this->form_validation->set_rules('hdate','Hearing Date','max_length[100]');
        $this->form_validation->set_rules('opp','Opposite To','max_length[100]');
        $this->form_validation->set_rules('tfees','Total Fees','max_length[100]');
        $this->form_validation->set_rules('assign','Assign To','max_length[100]');

       
        
            if($this->form_validation->run())     
            {   
                  $params = array(
                                

                    'task' => $this->input->post('task'),
                    'cno' => $this->input->post('cno'),
                    'cname' => $this->input->post('cname'),
                    'loc' => $this->input->post('loc'),
                    'coucat_id' => $this->input->post('ctitle'),
                    'ename_id' => $this->input->post('ename'),
                    'ctask_id' => $this->input->post('priority'),
                    'cs_id' => $this->input->post('progress'),
                    'act_id' => $this->input->post('act_name'),
                    'des' => $this->input->post('des'),
                    'due' => date('Y-m-d', strtotime($this->input->post('due'))),
                    'hdate' => date('Y-m-d', strtotime($this->input->post('hdate'))),
                    'opp' => $this->input->post('opp'),
                    'tfees' => $this->input->post('tfees'),
                    'assign' => $this->input->post('assign'),
                     
          
            );

                $this->Task_Model->update_Task($task_id,$params);            
                redirect('Task/index');
            }
            else
            {
                $data['_view'] = 'Task/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The Task you are trying to edit does not exist.');
    }  
    function remove($task_id)
    {
        $Task = $this->Task_Model->get_Task($task_id);

        // check if the customer exists before trying to delete it
        if(isset($Task['task_id']))
        {
            $this->Task_Model->delete_Task($task_id);
            redirect('Task/index');
        }
        else
            show_error('The Task you are trying to delete does not exist.');
    }
    function view($task_id)
    {   
         
        $data['Task'] = $this->Task_Model->get_Task($task_id);
        if(isset($data['Task']['task_id']))
        {
            $data['_view'] = 'Task/view';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The Task does not exist.');
    } 
     function star($task_id)
    {
        $Task = $this->Task_Model->get_Task($task_id);
        if(isset($Task['task_id']))
        {
            $this->Task_Model->addStar()($task_id);
            redirect('Task/index');
        }
        else
            show_error('The Task you are trying to delete does not exist.');
    }
     
}

?>