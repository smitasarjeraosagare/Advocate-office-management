<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Courtcategory extends Base_Controller{
    function __construct()
    {
        parent::__construct();
        $this->authenticate();

        $this->load->model('Courtcategory_Model');
       /* $this->load->model('Star_Model');*/
    } 
/*index function starts*/

    function index()
    {
        $data['courtcat'] = $this->Courtcategory_Model->get_all_Courtcategory();
        
        $data['_view'] = 'Courtcategory/index';
        $this->load->view('layouts/main',$data);
         
        
  }

    /*end of index function*/
    function add()
    {   

       
        $this->load->library('form_validation');

        $this->form_validation->set_rules('courtname','Name','required|max_length[100]');
        
        if($this->form_validation->run())     
        {   
            $params = array(

                    'courtname' => $this->input->post('courtname')
            );
            
            $coucat_id	 = $this->Courtcategory_Model->add_Courtcategory($params);
            redirect('courtcategory/index');
        }
        else
        {            
            $data['_view'] = 'Courtcategory/add';
            $this->load->view('layouts/main',$data);
        }
    }  
    /*end add function*/ 
 function edit($coucat_id)
    {   
        
        // check if the customer exists before trying to edit it
        $data['courtcategory'] = $this->courtcategory_Model->get_courtcategorys($coucat_id);
        
        if(isset($data['courtcategory']['coucat_id']))
        {
            $this->load->library('form_validation');
                

        $this->form_validation->set_rules('leav','courtcategory','required|max_length[100]');
          $this->form_validation->set_rules('des','description','required|max_length[100]');
       
        
            if($this->form_validation->run())     
            {   
                $params = array(
                     
                    'leav' => $this->input->post('leav'),
                    'des' => $this->input->post('des')
                );

                $this->courtcategory_Model->update_courtcategory($coucat_id,$params);            
                redirect('courtcategory/index');
            }
            else
            {
                $data['_view'] = 'courtcategory/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The courtcategory you are trying to edit does not exist.');
    }  
      function remove($coucat_id)
    {
        $courtcategory = $this->courtcategory_Model->get_courtcategorys($coucat_id);

        // check if the customer exists before trying to delete it
        if(isset($courtcategory['coucat_id']))
        {
            $this->courtcategory_Model->delete_courtcategory($coucat_id);
            redirect('courtcategory/index');
        }
        else
            show_error('The courtcategory you are trying to delete does not exist.');
    }
    function view($coucat_id)
    {   
         
        $data['courtcategory'] = $this->courtcategory_Model->get_courtcategorys($coucat_id);
        if(isset($data['courtcategory']['coucat_id']))
        {
            $data['_view'] = 'courtcategory/view';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The courtcategory does not exist.');
    } 
}

?>