<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Clients extends Base_Controller{
    function __construct()
    {
        parent::__construct();
        $this->authenticate();
        $this->load->model('Clients_Model');
        $this->load->model('Star_Model');
    } 
/*index function starts*/

    function index()
    {
   
        $data['client'] = $this->Clients_Model->get_all_Clients();
        $data['_view'] = 'Clients/index';
        $this->load->view('layouts/main',$data);
         /* if($this->session->userdata('user_id')) {
            redirect('dashboard');
        }
        else {
            redirect('Clients/login');
        }*/
  }
    /*end of index function*/
        function add()
    {  
  

        $this->load->library('form_validation');

          
 $this->form_validation->set_rules('name','Name','required|max_length[100]');
        $this->form_validation->set_rules('phone','Phone','required|max_length[100]');
        
        $this->form_validation->set_rules('gender','Gender','required|max_length[100]');
         $this->form_validation->set_rules('dob','Date of birth','required|max_length[100]');
    $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[client.email]');
     $this->form_validation->set_rules('username','username','required|max_length[100]');
       $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
        $this->form_validation->set_rules('passconf', 'Confirm Password', 'required|matches[password]');
      $this->form_validation->set_rules('address','Address','required|max_length[100]');
      $this->form_validation->set_rules('m','m','required|max_length[100]');
      $this->form_validation->set_rules('test','Test','required|max_length[100]');
      $this->form_validation->set_rules('ctype','client Type','required|max_length[100]');

        
      if($this->form_validation->run())     
        {   

  $config['upload_path']          = './image';
                $config['allowed_types']        = 'gif|jpg|png|pdf|doc';
                $config['max_size']             = 100;
                $config['max_width']            = 1024;
                $config['max_height']           = 768;
                $this->load->library('upload', $config);
      if ( ! $this->upload->do_upload('photo')){

 echo '<script language="javascript">';
                    echo 'alert("fail")';
                    echo '</script>';

        }
        else{
         
        $upload_data = $this->upload->data();
       echo '<script language="javascript">';
                    echo 'alert("fail")';
                    echo '</script>';
            $params = array(
                                

                     'name' => $this->input->post('name'),
                    'phone' => $this->input->post('phone'),
                    'gender' => $this->input->post('gender'),
                    'dob' => date('Y-m-d', strtotime($this->input->post('dob'))),
                    'email' => $this->input->post('email'),
                   'username' => $this->input->post('username'),
                   'password' => md5($this->input->post('password')),
                    'address' => $this->input->post('address'),
                    'm' => $this->input->post('m'),
                    'test' => $this->input->post('test'),
                    'ctype' => $this->input->post('ctype')

                    );
                      $params['photo']=$upload_data['file_name'];




            $cl_id = $this->Clients_Model->add_Clients($params);
            redirect('Clients/index');
        }
    }
        else
        {            
            
            $data['_view'] = 'Clients/add';
            $this->load->view('layouts/main',$data);
        }
    }  
  
    /*end add function*/ 
     
      function remove($cl_id)
    {
        $client = $this->Clients_Model->get_Clients($cl_id);

        // check if the customer exists before trying to delete it
        if(isset($client['cl_id']))
        {
            $this->Clients_Model->delete_Clients($cl_id);
            redirect('Clients/index');
        }
        else
            show_error('The client you are trying to delete does not exist.');
    }
    function view($cl_id)
    {   
         
        $data['client'] = $this->Clients_Model->get_Clients($cl_id);
        if(isset($data['client']['cl_id']))
        {
            $data['_view'] = 'client/view';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The client does not exist.');
    } 
     function edit($cl_id)
    {   
        
        // check if the customer exists before trying to edit it
        $data['client'] = $this->Clients_Model->get_Clients($cl_id);
        
        if(isset($data['client']['cl_id']))
        {
           
        $this->load->library('form_validation');

        $this->form_validation->set_rules('name','Name','required|max_length[100]');
        $this->form_validation->set_rules('phone','Phone','required|max_length[100]');
        $this->form_validation->set_rules('pic','Photo','required|max_length[100]');
        $this->form_validation->set_rules('gender','Gender','required|max_length[100]');
         $this->form_validation->set_rules('dob','Date of birth','required|max_length[100]');
    $this->form_validation->set_rules('email','email','required|max_length[100]');
     $this->form_validation->set_rules('username','username','required|max_length[100]');
      $this->form_validation->set_rules('pass','Password','required|max_length[100]');
      $this->form_validation->set_rules('cpass','confirm Password','required','matches[pass]');
      $this->form_validation->set_rules('address','Address','required|max_length[100]');
      $this->form_validation->set_rules('m','m','required|max_length[100]');
      $this->form_validation->set_rules('test','Test','required|max_length[100]');
      $this->form_validation->set_rules('ctype','client Type','required|max_length[100]');
        

       
        
            if($this->form_validation->run())     
            {   
                $params = array(
                                

                    'name' => $this->input->post('name'),
                    'phone' => $this->input->post('phone'),
                    'pic' => $this->input->post('pic'),
                    'gender' => $this->input->post('gender'),
                    'dob' => date('Y-m-d', strtotime($this->input->post('dob'))),
                    'email' => $this->input->post('email'),
                   'username' => $this->input->post('username'),
                    'pass' => $this->input->post('pass'),
                    /*'cpass' => $this->input->post('cpass'),*/
                    'address' => $this->input->post('address'),
                    'm' => $this->input->post('m'),
                    'test' => $this->input->post('test'),
                    'ctype' => $this->input->post('ctype')

                    );

                $this->client_Model->update_client($cl_id,$params);            
                redirect('client/index');
            }
            else
            {
                $data['_view'] = 'client/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The client you are trying to edit does not exist.');
    }  
          /*  function login1() {
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|trim');
        $this->form_validation->set_rules('password', 'Password', 'required|trim');

        if($this->form_validation->run()) {
            $client = $this->Clients_Model->login($this->input->post('email'), $this->input->post('password'));

            if($client['rc']) {
                $user_data = array(
                    "user_id" => $client['data']['cl_id'],
                    "username" => $client['data']['username']
                  
                );
                $this->session->set_userdata($user_data);

                redirect('dashboard');
            }
            else {
                $this->session->set_flashdata("error", "Email or password is wrong");
                redirect('Clients/login1');
            }
        }
        else {
            $data = array();
            $this->load->view('Clients/login', $data);
        }
    }

    function logout() {
        $this->session->unset_userdata('user_id');
        $this->session->unset_userdata('username');

    
    unset($_SESSION['role']);

        redirect('Clients/login');
    }*/
      

}
?>