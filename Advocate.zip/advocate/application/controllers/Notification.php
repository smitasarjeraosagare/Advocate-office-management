<?php
defined('BASEPATH') OR exit('No appointect script access allowed');

class Notification extends Base_Controller{
    function __construct()
    {
        parent::__construct();
        $this->authenticate();

        $this->load->model('Notification_Model');
        /* $this->load->model('Star_Model');*/
    } 
/*index function starts*/
     function index()
    {
        $data['notification'] = $this->Notification_Model->get_all_Notification();
       
        $data['_view'] = 'Notification/add'; 
        
        $this->load->view('layouts/main',$data);
         
 
 
 }/*end of index function*/
         function add()
    {   
         $this->load->library('form_validation');

        $this->form_validation->set_rules('cas','Case Alert Days','required|max_length[100]');
        $this->form_validation->set_rules('todo','To Do Alert Days','required|max_length[100]');
        $this->form_validation->set_rules('appoint','Appointment Alert days','required|max_length[100]');
        
        if($this->form_validation->run())     
        {   
            $params = array(
                    'cas' => $this->input->post('cas'),
                    'todo' => $this->input->post('todo'),
                    'appoint' => $this->input->post('appoint')
                    
            );

            $note_id = $this->Notification_Model->add_Notification($params);
            redirect('Notification/add');
        }
            
          
        else
        {            
            $data['_view'] = 'Notification/add';
            $this->load->view('layouts/main',$data);
        }
    }  
 
 
 }/*end of index function*/
   /*
    /*end add function*/ 



    function view($note_id)
    {   
         
        $data['Notification'] = $this->Notification_model->get_Notification($note_id);
        if(isset($data['Notification']['note_id']))
        {
            $data['_view'] = 'Notification/view';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The Notification does not exist.');
    } 

    /*
     * Deleting Notification
     */
    function remove($note_id)
    {
        $Notification = $this->Notification_model->get_Notification($note_id);

        // check if the customer exists before trying to delete it
        if(isset($Notification['note_id']))
        {
            $this->Notification_model->delete_Notification($note_id);
            reappointect('Notification/index');
        }
        else
            show_error('The Notification you are trying to delete does not exist.');
    }
    
/*
            function archived($note_id)
            {   
        
        // check if the customer exists before trying to edit it
        $data['Notification'] = $this->Notification_model->get_Notification($note_id);
        
        if(isset($data['Notification']['note_id']))
        {
             $this->load->library('form_validation');
        $this->form_validation->set_rules('notes','Company cas','required|max_length[100]');
        $this->form_validation->set_rules('cdate','Closing Date','required|max_length[100]');
           if($this->form_validation->run())     
            {   
               $params = array(
                    'note' => $this->input->post('note'),
                    'cdate' => date('Y-m-d', strtotime($this->input->post('cdate'))),  );

                $this->Notification_model->add_archive($note_id,$params);            
                reappointect('Notification/index');
            }
            else
            {
                $data['_view'] = 'Notification/archived';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The Notification you are trying to edit does not exist.');
    } 
*/

   

?>