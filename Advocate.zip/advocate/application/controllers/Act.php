<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Act extends Base_Controller{
    function __construct()
    {
        parent::__construct();        
        $this->authenticate();
        $this->load->model('Act_Model');
        $this->load->model('Star_Model');
         $this->load->model('Cases_Model');
         $this->load->model('Clients_Model');
         $this->load->model('Employees_Model');
        $this->load->model('Fees_Model');
         $this->load->model('Act_Model');
         $this->load->model('Casecategory_Model');
         $this->load->model('Courtcategory_Model');
         $this->load->model('Court_Model');
         $this->load->model('Casestage_Model');
         $this->load->model('Payment_Model');
         $this->load->model('Tax_Model');
         $this->load->model('Location_Model');
    } 
/*index function starts*/

    function index()
    {
         $data['cases'] = $this->Cases_Model->get_all_Case();
         $data['all_clients'] = $this->Clients_Model->get_all_Clients();
         $data['all_location'] = $this->Location_Model->get_all_Locations();
        $data['all_casecategory'] = $this->Casecategory_Model->get_all_Casecategory();
         $data['all_casestage'] = $this->Casestage_Model->get_all_Casestage();
        $data['all_act'] = $this->Act_Model->get_all_Act();
        $data['all_court'] = $this->Court_Model->get_all_Court();
        $data['all_courtcat'] = $this->Courtcategory_Model->get_all_Courtcategory();
        $data['all_employees'] = $this->Employees_Model->get_all_Employees();
        $data['cases'] = $this->Cases_Model->get_all_Case();
        $data['act'] = $this->Act_Model->get_all_Act();
        $data['_view'] = 'Act/index';
        $this->load->view('layouts/main',$data);
  }

 
 
    /*end of index function*/
    function add()
    {   

       
        $this->load->library('form_validation');

        $this->form_validation->set_rules('act_name','Act','required|max_length[100]');
        
        if($this->form_validation->run())     
        {   
            $params = array(
                                

                    'act_name' => $this->input->post('act_name')
                    );
            
            $act_id = $this->Act_Model->add_Act($params);
            redirect('Act/index');
        }
        else
        {            
            $data['_view'] = 'Act/add';
            $this->load->view('layouts/main',$data);
        }
    }  
    /*end add function*/ 
     function edit($act_id)
    {   
        
        // check if the customer exists before trying to edit it
        $data['act'] = $this->Act_Model->get_acts($act_id);
        
        if(isset($data['act']['act_id']))
        {
            $this->load->library('form_validation');
                

        $this->form_validation->set_rules('leav','act','required|max_length[100]');
          $this->form_validation->set_rules('des','description','required|max_length[100]');
       
        
            if($this->form_validation->run())     
            {   
                $params = array(
                     
                    'leav' => $this->input->post('leav'),
                    'des' => $this->input->post('des')
                );

                $this->Act_Model->update_act($act_id,$params);            
                redirect('act/index');
            }
            else
            {
                $data['_view'] = 'act/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The act you are trying to edit does not exist.');
    }  
      function remove($act_id)
    {
        $act = $this->Act_Model->get_acts($act_id);

        // check if the customer exists before trying to delete it
        if(isset($act['act_id']))
        {
            $this->Act_Model->delete_act($act_id);
            redirect('act/index');
        }
        else
            show_error('The act you are trying to delete does not exist.');
    }
    function view($act_id)
    {   
         
        $data['act'] = $this->Act_Model->get_acts($act_id);
        if(isset($data['act']['act_id']))
        {
            $data['_view'] = 'act/view';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The act does not exist.');
    } 
}


?>