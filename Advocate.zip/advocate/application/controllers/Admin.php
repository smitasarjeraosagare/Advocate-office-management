<?php

class Admin extends Base_Controller{
    function __construct()
    {
        parent::__construct();
      //  $this->authorize(ADMIN_ROLE);
       
       
        $this->load->model('User_model');
    }

    /*
     * Listing of users
     */
    function index()
    {
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('admin/index?');
        $params['role!='] = ADMIN_ROLE;
        $config['total_rows'] = $this->User_model->get_all_users_count($params);
         $config['total_rows'] = $this->User_model->get_all_users_count();

        $this->pagination->initialize($config);

        $params['limit']['limit'] = RECORDS_PER_PAGE;
        $params['limit']['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        $data['users'] = $this->User_model->get_all_users($params);

       /* $data['_view'] = 'admin/index';*/
        $this->load->view('admin/index');
    }

    /*
     * Adding a new admin
     */
    function register()
    {
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[8]');
        $this->form_validation->set_rules('passconf', 'Confirm Password', 'required|matches[password]');

        if($this->form_validation->run())
        {
            $params = array(
                'name' => $this->input->post('name'),
                'email' => $this->input->post('email'),
                'password' => md5($this->input->post('password')),
                'role' => USER_ROLE,
                'created_at' => date('Y-m-d H:i:s'),
            );

            $user_id = $this->User_Model->add_user($params);


            redirect('admin/index');
        }
        else
        {
            $this->load->view('admin/register');
        }
    }

    /*
     * Editing a admin
     */
    function edit($id)
    {
        // check if the admin exists before trying to edit it
        $data['admin'] = $this->User_Model->get_user($id);

        if(isset($data['admin']['id']))
        {
            $this->form_validation->set_rules('name', 'Name', 'required');

            $valid_email = $data['admin']['email'] != $this->input->post('email') ? '|is_unique[users.email]' : '';

            $this->form_validation->set_rules('email', 'Email', 'required|valid_email'.$valid_email);
            $this->form_validation->set_rules('password', 'Password', 'min_length[8]');
            $this->form_validation->set_rules('passconf', 'Confirm Password', 'matches[password]');

            if($this->form_validation->run())
            {
                $params = array(
                    'name' => $this->input->post('name'),
                    'email' => $this->input->post('email'),
                    'updated_at' =>  date('Y-m-d H:i:s'),
                );

               // if ($params['password'] != '') {
               //     $params['password'] =  md5($this->input->post('password'));
              //  }

               

                 if ($this->input->post('password')){

                    $a = $this->input->post('password'); 
                    if ($a != '') {
                    $a =  md5($this->input->post('password'));
                     }
                }

                $this->User_Model->update_user($id,$params,$a);
                redirect('admin/index');
            }
            else
            {
                $data['_view'] = 'admin/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The admin you are trying to edit does not exist.');
    }

    /*
     * Deleting admin
     */
    function remove($id)
    {
        $admin = $this->User_Model->get_user($id);

        // check if the admin exists before trying to delete it
        if(isset($admin['id']))
        {
            $this->User_model->delete_user($id);
            redirect('admin/index');
        }
        else
            show_error('The admin you are trying to delete does not exist.');
    }


}
