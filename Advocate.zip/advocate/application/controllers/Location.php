<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Location extends Base_Controller{
    function __construct()
    {
        parent::__construct();
       $this->authenticate();
        $this->load->model('Location_Model');
        $this->load->model('Star_Model');
    } 
/*index function starts*/

    function index()
    {
        $data['location'] = $this->Location_Model->get_all_Locations();
        
        $data['_view'] = 'Location/index';
        $this->load->view('layouts/main',$data);
  }

 
 
    /*end of index function*/
    function add()
    {   

       
       
        $this->form_validation->set_rules('lname','Location Name','required|max_length[100]');
       
        
        if($this->form_validation->run())     
        {   
            $params = array(
                                

                    
                    'lname' => $this->input->post('lname'),
                    );
            
            $l_id = $this->Location_Model->add_Location($params);
            redirect('Location/index');
        }
        else
        {            
            $data['_view'] = 'Location/add';
            $this->load->view('layouts/main',$data);
        }
    }  
    /*end add function*/ 
 function edit($l_id)
    {   
        
        // check if the customer exists before trying to edit it
        $data['location'] = $this->Location_Model->get_Location($l_id);
        
        if(isset($data['location']['l_id']))
        {
            $this->load->library('form_validation');
                

        $this->form_validation->set_rules('leav','location','required|max_length[100]');
          $this->form_validation->set_rules('des','description','required|max_length[100]');
       
        
            if($this->form_validation->run())     
            {   
                $params = array(
                     
                    'leav' => $this->input->post('leav'),
                    'des' => $this->input->post('des')
                );

                $this->Location_Model->update_Location($l_id,$params);            
                redirect('location/index');
            }
            else
            {
                $data['_view'] = 'location/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The location you are trying to edit does not exist.');
    }  
      function remove($l_id)
    {
        $location = $this->Location_Model->get_Location($l_id);

        // check if the customer exists before trying to delete it
        if(isset($location['l_id']))
        {
            $this->Location_Model->delete_Location($l_id);
            redirect('location/index');
        }
        else
            show_error('The location you are trying to delete does not exist.');
    }
    function view($l_id)
    {   
         
        $data['location'] = $this->Location_Model->get_Locations($l_id);
        if(isset($data['location']['l_id']))
        {
            $data['_view'] = 'location/view';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The location does not exist.');
    } 

}
?>