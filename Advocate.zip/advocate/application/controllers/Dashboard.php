<?php


class Dashboard extends Base_Controller{
  public function __construct()
    {
        parent::__construct();
       $this->authenticate();
        $this->load->model('Notice_Model');
         $this->load->model('Todolist_Model');
           $this->load->model('Calendar_Model');
   
    }
    public function index($year = NULL , $month = NULL)
 {
  $this->load->model('Calendar_Model');
      /*  $data['events'] = $this->Calendar_Model->getcalender($year , $month);*/
       $this->load->library('calendar');
        $data['_view'] = 'dashboard';
         $data['notice'] = $this->Notice_Model->get_all_Notice();
      
        $this->load->view('layouts/main',$data);
        }
        public function admin()
    {
      
  /*  $data['total_bank'] = $this->get_all_bank_count();*/
            $data['notice'] = $this->Notice_Model->get_all_Notice();
 
        $data['_view'] = 'Dashboard/admin';
        $this->load->view('layouts/main',$data);
          
     }
     public function client()
    {
      
  /*  $data['total_bank'] = $this->get_all_bank_count();*/
           
  $data['notice'] = $this->Notice_Model->get_all_Notice();
        $data['_view'] = 'Dashboard/client';
        $this->load->view('layouts/client',$data);
          
     }public function employee()
    {
       
    /*$data['total_bank'] = $this->get_all_bank_count();
           */
  $data['notice'] = $this->Notice_Model->get_all_Notice();
        $data['_view'] = 'Dashboard/employee';
        $this->load->view('layouts/employee',$data);
          
     }
     
     
  function load()
 {
  $event_data = $this->calender_model->fetch_all_event();
  foreach($event_data->result_array() as $row)
  {
   $data[] = array(
    'id' => $row['id'],
    'title' => $row['title'],
    'start' => $row['start_event'],
    'end' => $row['end_event']
   );
  }
  echo json_encode($data);
 }

 function insert()
 {
  if($this->input->post('title'))
  {
   $data = array(
    'title'  => $this->input->post('title'),
    'start_event'=> $this->input->post('start'),
    'end_event' => $this->input->post('end')
   );
   $this->calender_model->insert_event($data);
  }
 }

 function update()
 {
  if($this->input->post('id'))
  {
   $data = array(
    'title'   => $this->input->post('title'),
    'start_event' => $this->input->post('start'),
    'end_event'  => $this->input->post('end')
   );

   $this->calender_model->update_event($data, $this->input->post('id'));
  }
 }

 function delete()
 {
  if($this->input->post('id'))
  {
   $this->calender_model->delete_event($this->input->post('id'));
  }
 }

}

?>