<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employees extends Base_Controller{
    function __construct()
    {
        parent::__construct();
         $this->authenticate();

       $this->load->model('Userrole_Model');
        $this->load->model('Employees_Model');
        $this->load->model('Department_Model');
    } 
/*index function starts*/

    function index()
    {
       /* $data['employee'] = $this->Employees_Model->get_all_Employees();
        
        $data['_view'] = 'Employees/index';*/
        
        $data['employee'] = $this->Employees_Model->get_all_Employees();
        $data['_view'] = 'Employees/index';
        $this->load->view('layouts/main',$data);
  }

 
 
    /*end of index function*/
     function add()
    {  
         $data['all_role'] = $this->Userrole_Model->get_all_Userrole();
 $data['all_department'] = $this->Department_Model->get_all_Department();

  $this->load->library('form_validation');
        $this->form_validation->set_rules('ename',' Title');
        /*$this->form_validation->set_rules('profile','profile');*/
        $this->form_validation->set_rules('gen','gender ');
          $this->form_validation->set_rules('edob','Date of Birth');
        $this->form_validation->set_rules('jsalary','joining salary','max_length[100]');
        $this->form_validation->set_rules('uename','Role','required|max_length[100]');
         $this->form_validation->set_rules('dname','Department','required|max_length[100]');
        $this->form_validation->set_rules('email','Email','max_length[100]');
        $this->form_validation->set_rules('username',' user','max_length[100]');
         $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
        $this->form_validation->set_rules('passconf', 'Confirm Password', 'required|matches[password]');
        $this->form_validation->set_rules('ephone','phone','max_length[100]');
        $this->form_validation->set_rules('eadd','address','max_length[100]');
        $this->form_validation->set_rules('status','status ','max_length[100]');
        
        if($this->form_validation->run())     
        {   

  $config['upload_path']          = 'image/';
                $config['allowed_types']        = 'gif|jpg|png|pdf|doc';
                $config['max_size']             = 100;
                $config['max_width']            = 1024;
                $config['max_height']           = 768;
                $this->load->library('upload', $config);
      if ( ! $this->upload->do_upload('photo')){

 echo '<script language="javascript">';
                    echo 'alert("fail")';
                    echo '</script>';

        }else{
         
        $upload_data = $this->upload->data();
       echo '<script language="javascript">';
                    echo 'alert("fail")';
                    echo '</script>';

  $params = array(
                                

                    'ename' => $this->input->post('ename'),
                   /* 'profile' => $this->input->post('profile'),*/
                    'gen' => $this->input->post('gen'),
                    'edob' => date('Y-m-d', strtotime($this->input->post('edob'))),
                    'jsalary' => $this->input->post('jsalary'),
                    'ur_id' => $this->input->post('uename'),
                    'dp_id' => $this->input->post('dname'),
                    'email' => $this->input->post('email'),
                    'username' => $this->input->post('username'),
                    'password' => md5($this->input->post('password')),
                    'ephone' => $this->input->post('ephone'),
                    'eadd' => $this->input->post('eadd'),
                    'status' => $this->input->post('status'),
                     
          
            );

                      $params['photo']=$upload_data['file_name'];
$e_id = $this->Employees_Model->add_Employees($params);
            redirect('Employees/index');
        }
    }
    
        else
        {            
            $data['_view'] = 'Employees/add';
            $this->load->view('layouts/main',$data);
        }
    }  
    /*end add function*/ 
 function edit($e_id)
    {   
        
        // check if the customer exists before trying to edit it
        $data['employee'] = $this->employee_Model->get_employees($e_id);
        
        if(isset($data['employee']['e_id']))
        {
            $this->load->library('form_validation');
                

        $this->form_validation->set_rules('leav','employee','required|max_length[100]');
          $this->form_validation->set_rules('ecpass','ecpasscription','required|max_length[100]');
       
        
            if($this->form_validation->run())     
            {   
                $params = array(
                     
                    'leav' => $this->input->post('leav'),
                    'ecpass' => $this->input->post('ecpass')
                );

                $this->employee_Model->update_employee($e_id,$params);            
                redirect('employee/index');
            }
            else
            {
                $data['_view'] = 'employee/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The employee you are trying to edit does not exist.');
    }  
      function remove($e_id)
    {
        $employee = $this->employee_Model->get_employees($e_id);

        // check if the customer exists before trying to delete it
        if(isset($employee['e_id']))
        {
            $this->employee_Model->delete_employee($e_id);
            redirect('employee/index');
        }
        else
            show_error('The employee you are trying to delete does not exist.');
    }
    function view($e_id)
    {   
         
        $data['employee'] = $this->employee_Model->get_employees($e_id);
        if(isset($data['employee']['e_id']))
        {
            $data['_view'] = 'employee/view';
            $this->load->view('layouts/main',$data);
        }
        else
            show_error('The employee does not exist.');
    } 
/*function login2() {
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|trim');
        $this->form_validation->set_rules('password', 'Password', 'required|trim');

        if($this->form_validation->run()) {
            $employee = $this->Employees_Model->login($this->input->post('email'), $this->input->post('password'));

            if($employee['rc']) {
                $user_data = array(
                    "user_id" => $employee['data']['e_id'],
                    "username" => $employee['data']['username']
                  
                );
                $this->session->set_userdata($user_data);

                redirect('dashboard');
            }
            else {
                $this->session->set_flashdata("error", "Email or password is wrong");
                redirect('Employees/login2');
            }
        }
        else {
            $data = array();
            $this->load->view('Employees/login', $data);
        }
    }

    function logout() {
        $this->session->unset_userdata('user_id');
        $this->session->unset_userdata('username');

    
    unset($_SESSION['role']);

        redirect('Employees/login2');
    }*/
}

?>