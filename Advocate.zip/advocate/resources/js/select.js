

 $(document).ready(function () {
  
    
  $("#button2").click(function(){

    function show_selected() {

        var id = $("barcode").val();
       alert(id);

        $.ajax({
            type:"POST",
            url:"./load_product_data.php",
               data: {action: id },
               success: function (data) {
                $("#content").html(data);
              
            }
        });
    }
    show_selected();

   });
    });