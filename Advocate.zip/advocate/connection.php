<?php


//$con=mysqli_connect('localhost','gstuser', 'gstpassword2019*', 'gst') or die ("Sorry ! It cannot connect to database");



$con=mysqli_connect('localhost','root', '', 'advocate') or die ("Sorry !  Cannot connect to database");


?>	