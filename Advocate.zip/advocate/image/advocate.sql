-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 24, 2020 at 07:41 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `advocate`
--

-- --------------------------------------------------------

--
-- Table structure for table `act`
--

CREATE TABLE `act` (
  `act_id` int(100) NOT NULL,
  `act_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `act`
--

INSERT INTO `act` (`act_id`, `act_name`) VALUES
(1, 'trival'),
(2, 'running'),
(3, 'running');

-- --------------------------------------------------------

--
-- Table structure for table `aleave`
--

CREATE TABLE `aleave` (
  `al_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `le_id` varchar(100) NOT NULL,
  `rea` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aleave`
--

INSERT INTO `aleave` (`al_id`, `date`, `le_id`, `rea`) VALUES
(1, '1970-01-01', '', 'sick'),
(3, '2020-02-16', '', 'vaction'),
(4, '1970-01-01', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `ap_id` int(100) NOT NULL,
  `atitle` varchar(100) NOT NULL,
  `ct_id` int(100) NOT NULL,
  `motive` varchar(100) NOT NULL,
  `adate` date NOT NULL,
  `note` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`ap_id`, `atitle`, `ct_id`, `motive`, `adate`, `note`) VALUES
(1, 'Other', 1, 'vcx', '2020-02-29', 'hello'),
(2, 'Own', 1, 'vcx', '2020-02-14', 'note');

-- --------------------------------------------------------

--
-- Table structure for table `archived`
--

CREATE TABLE `archived` (
  `a_id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `note` int(11) NOT NULL,
  `cdate` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `archived`
--

INSERT INTO `archived` (`a_id`, `c_id`, `note`, `cdate`) VALUES
(0, 0, 0, 2020);

-- --------------------------------------------------------

--
-- Table structure for table `attendence`
--

CREATE TABLE `attendence` (
  `at_id` int(11) NOT NULL,
  `datefrom` date NOT NULL,
  `dateto` date NOT NULL,
  `e_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendence`
--

INSERT INTO `attendence` (`at_id`, `datefrom`, `dateto`, `e_id`) VALUES
(1, '2020-02-22', '2020-02-29', 0);

-- --------------------------------------------------------

--
-- Table structure for table `casecategory`
--

CREATE TABLE `casecategory` (
  `cc_id` int(100) NOT NULL,
  `catname` varchar(100) NOT NULL,
  `patcat` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `casecategory`
--

INSERT INTO `casecategory` (`cc_id`, `catname`, `patcat`) VALUES
(1, 'drug', 'sringyr');

-- --------------------------------------------------------

--
-- Table structure for table `cases`
--

CREATE TABLE `cases` (
  `c_id` int(11) NOT NULL,
  `ctitle` varchar(100) NOT NULL,
  `cno` varchar(100) NOT NULL,
  `cname` varchar(100) NOT NULL,
  `loc` varchar(100) NOT NULL,
  `coucat_id` int(100) NOT NULL,
  `court_id` int(100) NOT NULL,
  `cs_id` int(100) NOT NULL,
  `act_id` int(100) NOT NULL,
  `des` varchar(100) NOT NULL,
  `fdate` date NOT NULL,
  `hdate` date NOT NULL,
  `opp` varchar(100) NOT NULL,
  `tfees` int(100) NOT NULL,
  `assign` varchar(100) NOT NULL,
  `note` varchar(100) NOT NULL,
  `cdate` date NOT NULL,
  `cc_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cases`
--

INSERT INTO `cases` (`c_id`, `ctitle`, `cno`, `cname`, `loc`, `coucat_id`, `court_id`, `cs_id`, `act_id`, `des`, `fdate`, `hdate`, `opp`, `tfees`, `assign`, `note`, `cdate`, `cc_id`) VALUES
(3, 'Onlie fraud', '03', 'swapnali', '0', 0, 0, 0, 0, 'on hearing', '2020-01-10', '2020-02-23', 'pooja', 5000, 'khalid', '', '0000-00-00', 0),
(4, 'birla ', '1', 'dev birla', '0', 0, 0, 0, 0, 'by partner', '2020-02-27', '2020-02-27', 'pooja', 5000, 'khalid', '', '0000-00-00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `casestage`
--

CREATE TABLE `casestage` (
  `cs_id` int(11) NOT NULL,
  `stage` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `casestage`
--

INSERT INTO `casestage` (`cs_id`, `stage`) VALUES
(1, 'running'),
(2, 'running');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `cl_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `pic` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `cpass` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `m` varchar(100) NOT NULL,
  `test` varchar(100) NOT NULL,
  `ctype` varchar(100) NOT NULL,
  `dob` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`cl_id`, `name`, `phone`, `pic`, `gender`, `email`, `username`, `pass`, `cpass`, `address`, `m`, `test`, `ctype`, `dob`) VALUES
(1, 'mahi', '9784512', 'beta.php', 'Female', 'admin@admin.com', 'admin@admin.com', '4565', '', 'hia', 'dsaS', 'ds', 'vcfd', '2020-02-07');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `ct_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `card` int(100) NOT NULL,
  `file` varchar(100) NOT NULL,
  `addr` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`ct_id`, `name`, `phone`, `email`, `card`, `file`, `addr`) VALUES
(1, 'rani', '987452121', 'sagaresmita@gmail.com', 23, '', '2020,');

-- --------------------------------------------------------

--
-- Table structure for table `court`
--

CREATE TABLE `court` (
  `court_id` int(100) NOT NULL,
  `court` varchar(100) NOT NULL,
  `l_id` int(100) NOT NULL,
  `des` varchar(100) NOT NULL,
  `coucat_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `court`
--

INSERT INTO `court` (`court_id`, `court`, `l_id`, `des`, `coucat_id`) VALUES
(1, 'delhi', 1, 'by partner', 1);

-- --------------------------------------------------------

--
-- Table structure for table `courtcat`
--

CREATE TABLE `courtcat` (
  `coucat_id` int(100) NOT NULL,
  `courtname` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courtcat`
--

INSERT INTO `courtcat` (`coucat_id`, `courtname`) VALUES
(1, 'high');

-- --------------------------------------------------------

--
-- Table structure for table `customfield`
--

CREATE TABLE `customfield` (
  `cf_id` int(100) NOT NULL,
  `form` varchar(100) NOT NULL,
  `ftype` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `value` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customfield`
--

INSERT INTO `customfield` (`cf_id`, `form`, `ftype`, `fname`, `value`) VALUES
(1, 'case', 'Dropdown', 'vcx', 'grvdcsx'),
(2, 'Clients', 'Radio', 'vcx', 'grvdcsx');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `dp_id` int(100) NOT NULL,
  `dname` varchar(100) NOT NULL,
  `des` varchar(100) NOT NULL,
  `design` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`dp_id`, `dname`, `des`, `design`) VALUES
(1, 'fdjcnvdc v', 'vvv', '');

-- --------------------------------------------------------

--
-- Table structure for table `doc`
--

CREATE TABLE `doc` (
  `d_id` int(100) NOT NULL,
  `c_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `doc` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doc`
--

INSERT INTO `doc` (`d_id`, `c_id`, `name`, `type`, `doc`, `title`) VALUES
(1, 3, 'mahi', 'Own', '', ''),
(2, 3, 'pjm', 'Other', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `e_id` int(11) NOT NULL,
  `ename` varchar(11) NOT NULL,
  `profile` varchar(100) NOT NULL,
  `gen` varchar(100) NOT NULL,
  `edob` date NOT NULL,
  `ur_id` int(11) NOT NULL,
  `dp_id` int(11) NOT NULL,
  `design` varchar(100) NOT NULL,
  `jsalary` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `euser` varchar(100) NOT NULL,
  `epass` varchar(100) NOT NULL,
  `ecpass` varchar(100) NOT NULL,
  `ephone` varchar(10) NOT NULL,
  `eadd` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`e_id`, `ename`, `profile`, `gen`, `edob`, `ur_id`, `dp_id`, `design`, `jsalary`, `email`, `euser`, `epass`, `ecpass`, `ephone`, `eadd`, `status`) VALUES
(1, 'raj', 'Duplicate_Certificate_Form_V4_05032016.pdf', 'Male', '2020-02-22', 0, 0, '', '15000', 'piu@gmail.com', 'admin@admin.com', '12345678', '12345678', '894561', 'thane', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `hear`
--

CREATE TABLE `hear` (
  `h_id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `ndate` date NOT NULL,
  `ldate` date NOT NULL,
  `note` varchar(100) NOT NULL,
  `doc` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `holiday`
--

CREATE TABLE `holiday` (
  `ho_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `holiday`
--

INSERT INTO `holiday` (`ho_id`, `name`, `date`) VALUES
(1, 'm ', '2020-02-28');

-- --------------------------------------------------------

--
-- Table structure for table `leavetype`
--

CREATE TABLE `leavetype` (
  `le_id` int(11) NOT NULL,
  `leav` varchar(100) NOT NULL,
  `des` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leavetype`
--

INSERT INTO `leavetype` (`le_id`, `leav`, `des`) VALUES
(1, 'sick', '5days max');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `l_id` int(100) NOT NULL,
  `lname` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`l_id`, `lname`) VALUES
(1, 'bandra'),
(2, 'pune');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `m_id` int(11) NOT NULL,
  `message` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `myattendence`
--

CREATE TABLE `myattendence` (
  `ma_id` int(11) NOT NULL,
  `notes` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE `notice` (
  `n_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `des` varchar(100) NOT NULL,
  `nodate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `p_id` int(11) NOT NULL,
  `pay` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`p_id`, `pay`) VALUES
(1, 'paytm');

-- --------------------------------------------------------

--
-- Table structure for table `star`
--

CREATE TABLE `star` (
  `sid` int(100) NOT NULL,
  `star` int(11) NOT NULL,
  `c_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `study`
--

CREATE TABLE `study` (
  `st_id` int(100) NOT NULL,
  `stitle` varchar(100) NOT NULL,
  `c_id` int(100) NOT NULL,
  `note` varchar(100) NOT NULL,
  `res` varchar(100) NOT NULL,
  `cscat` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `study`
--

INSERT INTO `study` (`st_id`, `stitle`, `c_id`, `note`, `res`, `cscat`) VALUES
(1, 'gfvcd', 0, 'note', 'bye', 'Bankrupt'),
(2, 'market', 0, 'hello', 'bye', 'Criminal');

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `task_id` int(11) NOT NULL,
  `e_id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `priority` varchar(100) NOT NULL,
  `due` date NOT NULL,
  `progress` varchar(100) NOT NULL,
  `des` varchar(10) NOT NULL,
  `task` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `task`
--

INSERT INTO `task` (`task_id`, `e_id`, `c_id`, `priority`, `due`, `progress`, `des`, `task`) VALUES
(2, 0, 0, '', '2020-02-21', '50', 'vccx', 'helo'),
(3, 0, 0, 'High', '2020-02-23', '32', 'x', 'helo');

-- --------------------------------------------------------

--
-- Table structure for table `tax`
--

CREATE TABLE `tax` (
  `tax_id` int(100) NOT NULL,
  `tax_name` varchar(100) NOT NULL,
  `tax` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tax`
--

INSERT INTO `tax` (`tax_id`, `tax_name`, `tax`) VALUES
(1, 'gst', '18');

-- --------------------------------------------------------

--
-- Table structure for table `todolist`
--

CREATE TABLE `todolist` (
  `t_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `des` varchar(100) NOT NULL,
  `ndat` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `todolist`
--

INSERT INTO `todolist` (`t_id`, `name`, `des`, `ndat`) VALUES
(0, 'mahi', 'on hearing', '2020-01-30');

-- --------------------------------------------------------

--
-- Table structure for table `userrole`
--

CREATE TABLE `userrole` (
  `ur_id` int(100) NOT NULL,
  `uename` varchar(100) NOT NULL,
  `des` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userrole`
--

INSERT INTO `userrole` (`ur_id`, `uename`, `des`) VALUES
(1, 'dx', 'hjbmn  ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `act`
--
ALTER TABLE `act`
  ADD PRIMARY KEY (`act_id`);

--
-- Indexes for table `aleave`
--
ALTER TABLE `aleave`
  ADD PRIMARY KEY (`al_id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`ap_id`);

--
-- Indexes for table `attendence`
--
ALTER TABLE `attendence`
  ADD PRIMARY KEY (`at_id`);

--
-- Indexes for table `casecategory`
--
ALTER TABLE `casecategory`
  ADD PRIMARY KEY (`cc_id`);

--
-- Indexes for table `cases`
--
ALTER TABLE `cases`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `casestage`
--
ALTER TABLE `casestage`
  ADD PRIMARY KEY (`cs_id`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`cl_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`ct_id`);

--
-- Indexes for table `court`
--
ALTER TABLE `court`
  ADD PRIMARY KEY (`court_id`);

--
-- Indexes for table `courtcat`
--
ALTER TABLE `courtcat`
  ADD PRIMARY KEY (`coucat_id`);

--
-- Indexes for table `customfield`
--
ALTER TABLE `customfield`
  ADD PRIMARY KEY (`cf_id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`dp_id`);

--
-- Indexes for table `doc`
--
ALTER TABLE `doc`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`e_id`);

--
-- Indexes for table `hear`
--
ALTER TABLE `hear`
  ADD PRIMARY KEY (`h_id`);

--
-- Indexes for table `holiday`
--
ALTER TABLE `holiday`
  ADD PRIMARY KEY (`ho_id`);

--
-- Indexes for table `leavetype`
--
ALTER TABLE `leavetype`
  ADD PRIMARY KEY (`le_id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`l_id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`m_id`);

--
-- Indexes for table `myattendence`
--
ALTER TABLE `myattendence`
  ADD PRIMARY KEY (`ma_id`);

--
-- Indexes for table `notice`
--
ALTER TABLE `notice`
  ADD PRIMARY KEY (`n_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `star`
--
ALTER TABLE `star`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `study`
--
ALTER TABLE `study`
  ADD PRIMARY KEY (`st_id`);

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`task_id`);

--
-- Indexes for table `tax`
--
ALTER TABLE `tax`
  ADD PRIMARY KEY (`tax_id`);

--
-- Indexes for table `userrole`
--
ALTER TABLE `userrole`
  ADD PRIMARY KEY (`ur_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `act`
--
ALTER TABLE `act`
  MODIFY `act_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `aleave`
--
ALTER TABLE `aleave`
  MODIFY `al_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `ap_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `attendence`
--
ALTER TABLE `attendence`
  MODIFY `at_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `casecategory`
--
ALTER TABLE `casecategory`
  MODIFY `cc_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cases`
--
ALTER TABLE `cases`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `casestage`
--
ALTER TABLE `casestage`
  MODIFY `cs_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `cl_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `ct_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `court`
--
ALTER TABLE `court`
  MODIFY `court_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `courtcat`
--
ALTER TABLE `courtcat`
  MODIFY `coucat_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customfield`
--
ALTER TABLE `customfield`
  MODIFY `cf_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `dp_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `doc`
--
ALTER TABLE `doc`
  MODIFY `d_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `e_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `hear`
--
ALTER TABLE `hear`
  MODIFY `h_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `holiday`
--
ALTER TABLE `holiday`
  MODIFY `ho_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `leavetype`
--
ALTER TABLE `leavetype`
  MODIFY `le_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `l_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `m_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `myattendence`
--
ALTER TABLE `myattendence`
  MODIFY `ma_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notice`
--
ALTER TABLE `notice`
  MODIFY `n_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `star`
--
ALTER TABLE `star`
  MODIFY `sid` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `study`
--
ALTER TABLE `study`
  MODIFY `st_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `task`
--
ALTER TABLE `task`
  MODIFY `task_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tax`
--
ALTER TABLE `tax`
  MODIFY `tax_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `userrole`
--
ALTER TABLE `userrole`
  MODIFY `ur_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
