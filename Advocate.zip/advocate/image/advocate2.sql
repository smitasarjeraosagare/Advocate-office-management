-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 24, 2020 at 07:38 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `advocate2`
--

-- --------------------------------------------------------

--
-- Table structure for table `act`
--

CREATE TABLE `act` (
  `act_id` int(100) NOT NULL,
  `act_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `act`
--

INSERT INTO `act` (`act_id`, `act_name`) VALUES
(1, 'trival'),
(2, 'running'),
(3, 'running');

-- --------------------------------------------------------

--
-- Table structure for table `aleave`
--

CREATE TABLE `aleave` (
  `al_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `le_id` varchar(100) NOT NULL,
  `rea` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aleave`
--

INSERT INTO `aleave` (`al_id`, `date`, `le_id`, `rea`) VALUES
(1, '1970-01-01', '', 'sick'),
(3, '2020-02-16', '', 'vaction'),
(4, '1970-01-01', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `ap_id` int(100) NOT NULL,
  `atitle` varchar(100) NOT NULL,
  `ct_id` int(100) NOT NULL,
  `motive` varchar(100) NOT NULL,
  `adate` date NOT NULL,
  `note` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`ap_id`, `atitle`, `ct_id`, `motive`, `adate`, `note`) VALUES
(1, 'Other', 1, 'vcx', '2020-02-29', 'hello'),
(2, 'Own', 1, 'vcx', '2020-02-14', 'note');

-- --------------------------------------------------------

--
-- Table structure for table `archived`
--

CREATE TABLE `archived` (
  `a_id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `note` int(11) NOT NULL,
  `cdate` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `archived`
--

INSERT INTO `archived` (`a_id`, `c_id`, `note`, `cdate`) VALUES
(0, 0, 0, 2020);

-- --------------------------------------------------------

--
-- Table structure for table `attendence`
--

CREATE TABLE `attendence` (
  `at_id` int(11) NOT NULL,
  `datefrom` date NOT NULL,
  `dateto` date NOT NULL,
  `e_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendence`
--

INSERT INTO `attendence` (`at_id`, `datefrom`, `dateto`, `e_id`) VALUES
(1, '2020-02-22', '2020-02-29', 0);

-- --------------------------------------------------------

--
-- Table structure for table `casecategory`
--

CREATE TABLE `casecategory` (
  `cc_id` int(100) NOT NULL,
  `catname` varchar(100) NOT NULL,
  `patcat` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `casecategory`
--

INSERT INTO `casecategory` (`cc_id`, `catname`, `patcat`) VALUES
(1, 'drug', 'sringyr');

-- --------------------------------------------------------

--
-- Table structure for table `cases`
--

CREATE TABLE `cases` (
  `c_id` int(11) NOT NULL,
  `ctitle` varchar(100) NOT NULL,
  `cno` varchar(100) NOT NULL,
  `cname` varchar(100) NOT NULL,
  `loc` varchar(100) NOT NULL,
  `coucat_id` int(100) NOT NULL,
  `court_id` int(100) NOT NULL,
  `cs_id` int(100) NOT NULL,
  `act_id` int(100) NOT NULL,
  `des` varchar(100) NOT NULL,
  `fdate` date NOT NULL,
  `hdate` date NOT NULL,
  `opp` varchar(100) NOT NULL,
  `tfees` int(100) NOT NULL,
  `assign` varchar(100) NOT NULL,
  `note` varchar(100) NOT NULL,
  `cdate` date NOT NULL,
  `cc_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cases`
--

INSERT INTO `cases` (`c_id`, `ctitle`, `cno`, `cname`, `loc`, `coucat_id`, `court_id`, `cs_id`, `act_id`, `des`, `fdate`, `hdate`, `opp`, `tfees`, `assign`, `note`, `cdate`, `cc_id`) VALUES
(3, 'Onlie fraud', '03', 'swapnali', '0', 0, 0, 0, 0, 'on hearing', '2020-01-10', '2020-02-23', 'pooja', 5000, 'khalid', '', '0000-00-00', 0),
(4, 'birla ', '1', 'dev birla', '0', 0, 0, 0, 0, 'by partner', '2020-02-27', '2020-02-27', 'pooja', 5000, 'khalid', '', '0000-00-00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `casestage`
--

CREATE TABLE `casestage` (
  `cs_id` int(11) NOT NULL,
  `stage` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `casestage`
--

INSERT INTO `casestage` (`cs_id`, `stage`) VALUES
(1, 'running'),
(2, 'running');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `cl_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `pic` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `cpass` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `m` varchar(100) NOT NULL,
  `test` varchar(100) NOT NULL,
  `ctype` varchar(100) NOT NULL,
  `dob` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `act`
--
ALTER TABLE `act`
  ADD PRIMARY KEY (`act_id`);

--
-- Indexes for table `aleave`
--
ALTER TABLE `aleave`
  ADD PRIMARY KEY (`al_id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`ap_id`);

--
-- Indexes for table `attendence`
--
ALTER TABLE `attendence`
  ADD PRIMARY KEY (`at_id`);

--
-- Indexes for table `casecategory`
--
ALTER TABLE `casecategory`
  ADD PRIMARY KEY (`cc_id`);

--
-- Indexes for table `cases`
--
ALTER TABLE `cases`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `casestage`
--
ALTER TABLE `casestage`
  ADD PRIMARY KEY (`cs_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `act`
--
ALTER TABLE `act`
  MODIFY `act_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `aleave`
--
ALTER TABLE `aleave`
  MODIFY `al_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `ap_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `attendence`
--
ALTER TABLE `attendence`
  MODIFY `at_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `casecategory`
--
ALTER TABLE `casecategory`
  MODIFY `cc_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cases`
--
ALTER TABLE `cases`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `casestage`
--
ALTER TABLE `casestage`
  MODIFY `cs_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
